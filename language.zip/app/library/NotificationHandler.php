<?php

use Phalcon\Mvc\User\Component;

class NotificationHandler extends Component
{

    private function periodeToTime($datum, $periode)
    {
        $opzegtermijn = explode(' ', $periode);
        switch ($opzegtermijn[1]) {
            case 'week':
                $unit = $opzegtermijn[0] . ' week';
                break;
            case 'dag':
                $unit = $opzegtermijn[0] . ' day';
                break;
            case 'maand':
                $unit = $opzegtermijn[0] . ' month';
                break;
            case 'jaar':
                $unit = $opzegtermijn[0] . ' year';
                break;
            default:
                $unit = $opzegtermijn[0];
                break;
        }
        return strtotime('-' . $unit);
    }

    public function listOfDueTasks()
    {
        //taken
        $prioritytasks = [];
        $tasklist = [];
        /*
        foreach (Taak::find() as $taak) {
            if (strtotime($taak->Einddatum) > strtotime("-1 week")) {

            }
            if (strlen($taak->Notificatiedatum) > 5 && strtotime($taak->Notificatiedatum) > $this->periodeToTime($contract->Einddatum, $taak->Notificatiedatum)) {

            }
        }
        */

    }

    public function listOfDueContracts()
    {
        //contracten
        $aflopendecontracten = [];
        $contractbuitenopzegtermijn = [];

        foreach (Contract::find() as $contract) {

            if (strtotime($contract->Einddatum) > strtotime("-1 week")) {
                }
            //opzegtermijn
            if (strlen($contract->Opzegtermijn) > 5 && strtotime($contract->Einddatum) > $this->periodeToTime($contract->Einddatum, $contract->Opzegtermijn)) {

            }

        }
    }
}