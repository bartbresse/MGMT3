<?php

use Phalcon\Mvc\User\Component;

class EntityCreationHandler extends Component implements LogicHandler
{
    public function __construct($entity, $entityInfo)
    {
        if ($entityInfo->entityname == 'Contract') {
            $this->ContractCreation($entity, $entityInfo);
        } else if ($entityInfo->entityname == 'Taak') {
            $this->TaakCreation($entity, $entityInfo);
        }
    }

    private function HerhaalElkeToTime($herhaalelke)
    {
        $str = explode(' ', $herhaalelke);

        switch ($str[1]) {
            case 'dag':
                $unit = (3600 * 24);
                break;
            case 'week':
                $unit = (3600 * 24 * 7);
                break;
            case 'maand':
                $unit = (3600 * 24 * 30.42);
                break;
            case 'jaar':
                $unit = (3600 * 24 * 365);
                break;
            default:
                die('not a format');
                break;
        }

        return ($unit * $str[0]);
    }

    /**
     * Create tasks for repeating tasks
     *
     * @param $entity
     * @param EntityInfo $entityInfo
     */
    private function TaakCreation($entity, EntityInfo $entityInfo)
    {
        //TODO: create master taak id relation to itself
        $taak = Taak::findFirst('idTaak = ' . $entityInfo->entityrowid);
        if ($taak->Herhaald == 1) {

            $datum = $taak->Einddatum;
            $einddatum = $taak->Eindatumherhaal;
            $notificatiedatum = $taak->Notificatiedatum;


            $herhalen = true;
            while ($herhalen == true) {
                $datum = date('Y-m-d H:i:s', (strtotime($datum) + $this->HerhaalElkeToTime($taak->Herhaalelke)));

                echo $datum.'
                ';
               
                if(strtotime($datum) <= strtotime($einddatum) && strtotime($datum) > 0 && strtotime($einddatum) > 0)
                {
                    $rtaak = new Taak();
                    $rtaak->Naam = $taak->Naam;
                    $rtaak->Einddatum = $datum;

                    $notificatiedatum = date('Y-m-d H:i:s', (strtotime($notificatiedatum) + $this->HerhaalElkeToTime($taak->Herhaalelke)));
                    $rtaak->Notificatiedatum = $notificatiedatum;

                    if($taak->Contract_idContract > 0) {
                        $rtaak->Contract_idContract = $taak->Contract_idContract;
                    }

                    if($taak->Onderwerp_idOnderwerp > 0) {
                        $rtaak->Onderwerp_idOnderwerp = $taak->Onderwerp_idOnderwerp;
                    }

                    if(!$taak->save())
                    {
                        print_r($taak->getMesssages());
                        die();
                    }

                }else{
                    $herhalen = false;
                }
            }
        }
        die();
    }

    /**
     * Create notification for end of life contract
     *
     * @param $entity
     * @param EntityInfo $entityInfo
     */
    private function ContractCreation($entity, EntityInfo $entityInfo)
    {
        $contract = Contract::findFirst('idContract = "' . $entityInfo->entityrowid . '"');

        $taak = new Taak();
        $taak->Contract_idContract = $contract->idContract;
        $taak->Naam = 'Herinnering einddatum';
        $taak->Beschrijving = 'Herinnering einddatum';
        if (strlen($contract->Begindatum) > 0) {
            $taak->Einddatum = $contract->Einddatum;
            $taak->Notificatiedatum = '2 week';
            $taak->einddatumtaak = date('Y-m-d H:i:s');
        }
        $taak->Taakstatus_idTaakstatus = 1;
        $taak->Prioriteit_idPrioriteit = 2;
        $taak->Eigenaar_idEigenaar = $contract->Eigenaar_idEigenaar;
        // $taak->Onderwerp_idOnderwerp = '';
        if (!$taak->save()) {
            print_r($taak->getMessages());
            die();
        } else if (strlen($contract->Einddatum) > 0) {

            $acl = new Acl();
            $acl->Eigenaar_idEigenaar = $contract->Eigenaar_idEigenaar;
            $acl->Structuurtable_idStructuurtable = 21;
            $acl->Create = 1;
            $acl->Read = 1;
            $acl->Update = 1;
            $acl->Delete = 1;
            $acl->Entityid = $taak->idTaak;
            if (!$acl->save()) {
                print_r($acl->getMessages());
                die();
            }
        }
    }

}