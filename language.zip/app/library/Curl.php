<?php
/**
 * Created by PhpStorm.
 * User: bart
 * Date: 3-11-2017
 * Time: 12:56
 */

class Curl
{
    public function __construct()
    {

    }


    /**
     * @param $url
     * @param $vars
     * @param bool $headers
     * @return mixed
     */
    public function post($url, $vars, $headers = false)
    {
        if(!$headers)
        {
            $headers = array(
                'Content-Type: application/x-www-form-urlencoded',
                'Connection: Keep-Alive',
              //  'Authorization: Bearer '.$this->bearer,
              //  'Ocp-Apim-Subscription-Key: '.$this->key
            );
        }

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($vars));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $raw = curl_exec($curl);

        echo $raw;
        print_r($raw);

        $html = json_decode($raw);

        if (curl_errno($curl)) {
            $this->errors = [curl_error($curl)];

            print_r($this->errors);
        }


        curl_close($curl);
        return $html;
    }

    public function get($url, $vars, $headers = false)
    {
        if(!$headers)
        {
            $headers = array(
                'Content-Type: application/x-www-form-urlencoded',
                'Connection: Keep-Alive',
                'Authorization: Bearer '.$this->bearer,
                'Ocp-Apim-Subscription-Key: '.$this->key
            );
        }

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'GET' );
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($vars));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $html = curl_exec($curl);
        if (curl_errno($curl)) {
            $this->errors = [curl_error($curl)];
        }

        print_r($this->errors);

        curl_close($curl);
        return $html;
    }

    public function connect()
    {

    }
}