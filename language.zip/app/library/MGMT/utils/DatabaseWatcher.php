<?php

use Phalcon\Mvc\User\Component;

class DatabaseWatcher extends Component
{
    private $mysqlqueries;
    private $logging;

    public function __construct()
    {
        $this->mysqlqueries = new MySQLQueries();
    }

    public function lookForChanges()
    {
        $systemtables = ['acl', 'action', 'audit', 'document', 'documentsoort', 'eigenaar', 'eigenaarstatus', 'language', 'rol', 'structuur', 'structuurtable', 'taal', 'usersession', 'navigation'];
        foreach ($this->mysqlqueries->select('SHOW TABLES') as $table) {
            if (!in_array($table[0], $systemtables)) {
                $this->logging['general'][] = 'table: ' . $table[0];
                $structuurtable = Structuurtable::findFirst('sqltable = "' . $table[0] . '"');
                if ($structuurtable) {
                    //table exists in MGMT check for changes
                    $this->logging['general'][] = 'checking for changed fields';
                    $this->checkForCHangedFields($table[0]);

                } else {
                    // create table in MGMT
                    $manytomany = explode('has', $table[0]);
                    if (!isset($manytomany[1])) {
                        $this->logging['general'][] = 'create table: ' . $table[0];
                        $this->createStructuurtable($table[0]);
                    }
                }
            }
        }

        $tables = [];
        foreach ($this->mysqlqueries->select('SHOW TABLES') as $table) {
            $tables[] = $table[0];
        }

        foreach (Structuurtable::find() as $table) {
            if (!in_array($table->sqltable, $tables) && strlen($table->sqltable) > 0) {
                $sqltable = $table->sqltable;
                if ($table->delete()) {
                    foreach (Structuur::find('tabel = "' . $sqltable . '"') as $structuur) {
                        $structuur->delete();
                    }
                    $this->logging['general'][] = 'table ' . $sqltable . ' has been deleted.';
                }
            }
        }
        print_r($this->logging);
    }

    private function checkForCHangedFields($sqltable)
    {
        $structuurfields = [];
        $ostructuurfields = [];
        $structuur = Structuur::find('tabel = "' . $sqltable . '"');
        foreach ($structuur as $structuurfield) {
            $structuurfields[$structuurfield->field] = $structuurfield->toArray();
            $ostructuurfields[$structuurfield->field] = $structuurfield;
        }

        $fields = $this->mysqlqueries->select('DESCRIBE `' . $sqltable . '`');

        foreach ($fields as $index => $field) {
            if ($field['Field'] != 'id' . ucfirst($sqltable)) {
                if (!isset($structuurfields[$field['Field']])) {
                    $this->logging['general'][] = 'create field: ' . $field['Field'] . ' by table: ' . $sqltable;
                    $this->createStructuurField($field, $sqltable);
                }
                unset($structuurfields[$field['Field']]);
            }
        }

        //remove fields that are no longer in the database
        foreach ($structuurfields as $index => $field) {
            $ostructuurfields[$index]->delete();
        }
    }

    private function createStructuurtable($table)
    {
        $structuurtable = Structuurtable::findFirst('sqltable = "' . $table . '"');
        if (!$structuurtable) {
            $structuurtable = new Structuurtable();
            $structuurtable->sqltable = $table;
            $structuurtable->fieldsinform = json_encode([]);
            if (!$structuurtable->save()) {
                print_r($structuurtable->getMessages());
            } else {
                $this->logging['general'][] = 'mgmt table created: ' . $table;
            }
        }
    }

    private function createStructuurField($field, $table)
    {
        $structuur = new Structuur();
        $structuur->name = ucfirst($field['Field']);
        $structuur->title = ucfirst($field['Field']);
        $structuur->description = '';
        $structuur->placeholder = ucfirst($field['Field']);
        $structuur->type = '';
        $structuur->field = $field['Field'];
        $structuur->tabel = $table;
        $structuur->sel = '';
        $structuur->visibleindetail = 1;
        $structuur->visibleintable = 1;
        $structuur->istablefield = 1;
        if (!$structuur->save()) {
            print_r($structuur->getMessages());
        } else {
            $this->logging['general'][] = 'field created: ' . $field['Field'];
        }
    }

    public
    function changedTable()
    {

    }
}