<?php

use Phalcon\Mvc\User\Component;

class SnippetGenerator extends Component
{
    private $mysqlqueries;

    public function __construct()
    {
        $this->mysqlqueries = new MySQLQueries();
    }

    public function addEntity($entity)
    {
        $structuurtable = Structuurtable::findFirst('sqltable = "'.$entity.'"');
        $txt  = '$'.$entity.' = new '.ucfirst($structuurtable->sqltable).'(); <br />';
        foreach(Structuur::find('tabel = "'.$entity.'"') as $index => $field)
        {
            $txt .= '$'.$entity.'->'.$field->field.' = ""; <br />';
        }
        $txt .= 'if(!$'.$entity.'->save()){ <br />';
        $txt .= '&nbsp;&nbsp;print_r($'.$entity.'->getMessages()); <br />';
        $txt .= '} <br />';
        return $txt;
    }

    public function getEntity($entity)
    {
        $txt  = '$'.$entity.' = '.ucfirst($entity).'::find(); <br />';
        $txt  .= 'foreach($'.$entity.'s as $'.$entity.'){ <br />';
        $txt  .= '$'.$entity.'-> <br />';
        $txt  .= '} <br />';
        return $txt;
    }

    public function deleteEntity($entity)
    {
        $txt  = '$'.$entity.' = '.ucfirst($entity).'::findFirst(); <br />';
        $txt  .= 'if($'.$entity.'->delete()){ <br />';
        $txt  .= '$'.$entity.'->getMessages(); <br />';
        $txt  .= '} <br />';
        return $txt;
    }
}