<?php

use Phalcon\Mvc\User\Component;

class OpenapiJsonGenerator extends Component
{
    public function generateFromModel()
    {
        
    }
}