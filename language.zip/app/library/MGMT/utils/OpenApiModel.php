<?php

class OpenApiModel
{
    public function ModelString()
    {
        return [
            'swagger' => '2.0',
            'host' => (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}",
            'basePath' => '/json',
            'info' => [
                'description' => 'This is the description.',
                'version' => '1.0.0',
                'title' => 'This is the title',
                'termsOfService' => 'http://www.apache.org/licenses/LICENSE-2.0.html',
                'contact' => ['email' => 'b.breunesse@barnworks.nl'],
                'license' => [
                    'name' => 'apache 2.0',
                    'url' => 'http://www.apache.org/licenses/LICENSE-2.0.html',
                    'externalDocs' => [
                        'description' => 'Find out more',
                        'url' => 'http://'
                        ]
                ]
            ],
            'tags' => [
                ['name' => '', 'description' => '', ''],
            ]
        ];
    }

    public function getYaml()
    {
        return preg_replace('/^(  +)/m', '$1$1', yaml_emit($this->ModelString()));
    }

    public function getJson()
    {
        return json_encode($this->ModelString());
    }
}

?>