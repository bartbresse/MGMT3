<?php

use Phalcon\Mvc\User\Component;


class TableJsonHandler extends Component
{
    private $tablejson;
    private $language;

    protected $entityInfo;
    protected $tableRowId;
    protected $filters;
    protected $appData;

    public function __construct(EntityInfo $entityInfo, $tableRowid = false)
    {
        $this->selectedRows = false;
        $this->entityInfo = $entityInfo;
        //TODO: integrate entityinfo
        //TODO: tableRowId not used in renderRow
        $this->tableRowId = $tableRowid;
        $this->filters = [];
    }

    public function setFilters($filters)
    {
        $this->filters = $filters;
    }

    public function setSelectedRows($ids)
    {
        $this->selectedRows = $ids;
    }


    public function setAppData($appdata)
    {
        $this->appData = $appdata;
    }

    public function setFormJson($formjson)
    {
        $this->formjson = $formjson;
    }

    public function setLanguageHandler($languageHandler)
    {
        $this->language = $languageHandler;
    }

    public function setRightsPerRow($rights)
    {
        $this->rightsPerRow = $rights;
    }

    private function isColumnVisible($index)
    {
        if (isset($this->formjson['properties'][$index])) {

            //TODO: $this->formjson['properties'][$index] always empty in table view
            if ($this->formjson['properties'][$index]['visibleindetail'] == 1) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function getTableRow(EntityInfo $ei)
    {
        $ea = [];
        $rights = [];

        foreach ($ei->data->toArray() as $index => $field) {

            //TODO:figure out if this works
            //detail view needs to be configured in database, no fields are showing without config!
            if ($this->entityInfo->detailview == false || $this->isColumnVisible($index)) {

                // set row rights
                if ($index == 'id' . $ei->entityname) {
                    if (isset($this->rightsPerRow[$field])) {
                        $rights = $this->rightsPerRow[$field];
                    } else {
                        $rights = $this->rightsPerRow[0];
                    }
                }

                $ex = explode('_id', $index);
                $exx = explode('xid', $index);

                //TODO: remove this, index needs to be identical to
                $originalindex = $index;
                if (isset($ei->names[$index])) {
                    $index = $ei->names[$index];
                }
                $translatedindex = $this->language->translate($index);

                if (isset($ex[1])) {
                    $entityname = ucfirst($ex[0]);
                    $data = false;
                    //check first of relation column has a value, 2 check if the relation exists.
                    if (strlen($ei->data->$originalindex) > 0 && isset($ei->data->$entityname)) {
                        $data = $ei->data->$entityname;
                    } else {
                        $data = $entityname::findFirst('id' . $entityname . ' = "' . $field . '"');
                    }

                    if ($data) {
                        $data = $data->toArray();

                        if (isset($data['Naam'])) {
                            $id = 'id' . ucfirst($entityname);
                            $ea[$translatedindex]['url'] = '/#/view/' . $entityname . '/' . $data[$id] . '/' . $this->appData->generate();
                            $ea[$translatedindex]['value'] = '' . $data['Naam'] . '';
                            if (isset($data['Path'])) {
                                $ea[$translatedindex]['path'] = $this->globalconfig->domain.'/'.$data['Path'];
                            }
                        } else {
                            //reference table values based on multiple fields
                            $str = '';
                            if (isset($ei->tablestructuur[$entityname])) {
                                $structuur = $ei->tablestructuur[$entityname];
                                foreach ($structuur as $index2 => $val) {
                                    if ($index2 > 0) {
                                        $str .= ' ';
                                    }
                                    $str .= $data[$val['name']];
                                }
                            }
                            $ea[$translatedindex]['url'] = false;
                            $ea[$translatedindex]['value'] = $str;
                        }
                    } else {
                        $ea[$translatedindex]['url'] = false;
                        $ea[$translatedindex]['value'] = ' ';
                    }

                } else if(isset($exx[1])){ //TODO: comma seperated relationships
                    $entityname = ucfirst($exx[0]);

                    $explode = explode(',',$field);
                    $str = 'id'.$entityname.' = "'.implode('" OR id'.$entityname.' = "',$explode).'" ';
                    $value = '';
                    foreach ($entityname::find($str) as $index2 => $val)
                    {
                        if($index2 > 0){$value .= ','; }
                        $value .= $val->Name;
                    }

                    $ea[$translatedindex]['url'] = false;
                    $ea[$translatedindex]['value'] = $value;

                } else {
                    $ea[$translatedindex]['url'] = false;
                    if ($field == '<p>&nbsp;</p>') {
                        $field = '';
                    }

                    $ea[$translatedindex]['value'] = $field;
                    if (isset($this->formjson['properties'][$originalindex])) {
                        $ea[$translatedindex]['value'] = $this->processDataFilters($this->formjson['properties'][$originalindex], $field, $index);
                    }
                }

                //TODO: figure this out, needs to be sanitized with other things
                if ($ea[$translatedindex]['value'] == 'NULL') {
                    $ea[$translatedindex]['value'] = '';
                }
            }
        }

        $cc = 0;
        foreach ($this->formjson['allconnectedproperties'] as $property) {
            if (strpos($property['field'], '_has_') !== false) {

                $local = $this->formjson['table'];
                $tables = explode('_has_', $property['field']);
                $foreign = $tables[1];
                if ($tables[1] == $local) {
                    $foreign = $tables[0];
                }

                $classname = '';
                foreach (explode('_', $property['field']) as $f) {
                    $classname .= ucfirst($f);
                }

                $fieldvalues = '';
                if (isset($ei->data->$classname)) {
                    $cc2 = 0;
                    foreach ($ei->data->$classname as $item) {
                        $cc++;
                        if (isset($item->$foreign) && $item->$foreign) {
                            $fieldarray = $item->$foreign->toArray();
                            //TODO add value if there is no NAAM column
                            if (isset($fieldarray['Naam'])) {
                                $url = '/#/view/' . $foreign . '/' . $fieldarray['id' . ucfirst($foreign)] . '/' . $this->appData->generate();
                                if ($cc2 > 1) {
                                    $fieldvalues .= ' ,';
                                }
                                $fieldvalues .= '<a href="' . $url . '">' . $fieldarray['Naam'] . '</a>';
                                $cc2++;
                            }
                        }
                    }
                    $ea[$property['name']] = ['url' => '', 'value' => $fieldvalues];
                }
            }
        }

        //ORDER

        if (isset($data['Path'])) {
            $ea[$translatedindex]['path'] = $data['Path'];
        }


        if (!$ei->detailview) {
            $id = array_keys($ei->data->toArray())[0];

            $ea['uri'] = '/#/detail/' . array_values($ei->names)[0] . '/' . $this->appData->generate();

            //TODO: fix this bullshit also
            if ($ei->tablename == 'document') {

                $ea['downloaduri'] = $this->globalconfig->domain . $ea['Path']['value'] . '/' . $this->appData->generate();
            }

            if ($rights['read'] == 1) {
                $ea['viewuri'] = '/#/view/' . $ei->tablename . '/' . $ei->data->$id . '/' . $this->appData->generate();
            } else {
                $ea['viewuri'] = false;
            }

            if ($rights['update'] == 1) {
                $ea['edituri'] = '/#/edit/' . $ei->tablename . '/' . $ei->data->$id . '/' . $this->appData->generate();
            } else {
                $ea['edituri'] = false;
            }

            $ea['id'] = $ei->data->$id;

            //TODO: check if you can delete
            if ($cc > 0 && $ei->tablename == 'document') {
                $ea['deleteuri'] = false;
            } else if ($rights['delete'] == 0) {
                $ea['deleteuri'] = false;
            } else {
                $ea['deleteuri'] = 'delete/' . $ei->tablename . '/' . $ei->data->$id;
            }

            if ($rights['delete'] == 1) {
                $ea['deletedetailuri'] = 'delete/' . $ei->tablename . '/' . $ei->data->$id . '/' . $this->appData->generate();
            } else {
                $ea['deletedetailuri'] = false;
            }
        }

        return $ea;
    }

    /**
     * @param $en
     * @return array
     *
     * get structure of a multivalue field. For example first AND last name.
     */
    private function getFieldStructuur($en)
    {
        $structuur = [];
        foreach ($en->toArray() as $index => $field) {

            $ex = explode('_id', $index);
            if (isset($ex[1])) {
                $entityname = ucfirst($ex[0]);
                $data = $entityname::findFirst('id' . $entityname . ' = "' . $field . '"');

                //if relation data is present
                if ($data) {
                    $struc = Structuur::find('tabel = "' . strtolower($entityname) . '" AND sel > 0');
                    $structuur[$entityname] = $struc->toArray();
                }
            }
        }
        return $structuur;
    }

    private $structuur;

    private function getTableNames($ei)
    {
        $names = [];
        $structuur = [];

        foreach (Structuur::find('tabel = "' . $ei->tablename . '"') as $structure) {
            $names[$structure->field] = $structure->name;
            $structuur[$structure->field] = $structure->toArray();
        }
        $this->structuur = $structuur;
        return $names;
    }

    public function renderRow()
    {
        $this->entityInfo->names = $this->getTableNames($this->entityInfo);
        $this->entityInfo->setTableRelationsStructuur($this->getFieldStructuur($this->entityInfo->data));
        return $this->getTableRow($this->entityInfo);
    }


    public function render()
    {
        $ei = $this->entityInfo;
        $e = [];

        foreach ($ei->data as $index => $en) {
            if ($index == 0) {
                $structuur = $this->getFieldStructuur($en);
                $ei->setTableRelationsStructuur($structuur);
                $ei->names = $this->getTableNames($ei);
            }

            $ei->data = $en;
            $row = $this->getTableRow($ei);

            if ($index == 0) {
                $keys = array_keys($row);
                $idkey = $keys[0];
            }

            if (is_array($this->selectedRows)) {
                $selectedrows = $this->selectedRows;
                if (in_array($row[$idkey], $selectedrows)) {
                    $row = false;
                } else {
                    $e[] = $row;
                }
            } else {
                $e[] = $row;
            }
        }

        $obj = [];
        $obj['columns'] = [];
        foreach (Structuur::find(['conditions' => 'tabel = "' . $ei->tablename . '" AND visibleintable > 0', 'order' => 'Entityorder ASC']) as $structure) {
            $obj['columns'][] = $this->language->translate($structure->name);
            $attr = ['width' => '', 'minwidth' => '', 'subform' => true];
            if (!$attr) {
                $attr = json_decode($structure->attr, true);
            }
            $obj['columnData'][$this->language->translate($structure->name)]['attr'] = $attr;
        }

        $obj['database'] = $this->globalconfig->database;
        if (isset($ei->structuurtable) && is_object($ei->structuurtable)) {
            $obj['structuurtable'] = $ei->structuurtable->toArray();
        }
        $obj['data'] = $e;
        $obj['appdata'] = $this->appData->generate();
        $obj['backend'] = $this->globalconfig->domain;

        $filterhandler = new FilterHandler();
        if (count($this->filters) > 0) {
            $obj['filters'] = $this->filters;
        } else {
            $obj['filters'] = $filterhandler->render($ei);
        }
        return $obj;
    }

    public function processDataFilters($field, $value, $names)
    {
        //TODO: create filter system, this is shite.
        switch ($field['type']) {
            case 'date':
                $date = date('d-m-Y', strtotime($value));
                //TODO: bij null datum 01-01-1970
                if (strtotime($date) == -3600 || strtotime($date) < 10000) {
                    $date = 'geen';
                }
                return $date;
                break;
            case 'switch':
                if ($value == 1) {
                    $value = 'nee';
                } else if ($value == 0) {
                    $value = 'ja';
                }
                return $value;
                break;
            default:
                return $value;
                break;
        }
    }
}

?>