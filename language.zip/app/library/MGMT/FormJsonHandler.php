<?php

use Phalcon\Mvc\User\Component;

class FormJsonHandler extends Component
{
    protected $tableRowId;
    protected $table;
    protected $appdata;

    private $language;

    public function __construct(EntityInfo $entityInfo)
    {
        //TODO: integrate entityinfo
        $this->table = $entityInfo->tablename;
        $this->tableRowId = $entityInfo->entityrowid;
    }

    public function setLanguageHandler($languageHandler)
    {
        $this->language = $languageHandler;
    }

    public function setAppData($appdata)
    {
        $this->appdata = $appdata;
    }

    private function getBaseUrl()
    {
        $hostName = $_SERVER['HTTP_HOST'];
        $protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"], 0, 5)) == 'https' ? 'https' : 'http';
        return $protocol . '://' . $hostName;
    }

    private function getSelectFileList($key, $id)
    {
        $mysql = new MySQLQueries();
        $enum = [];

        if ($key == 'Document') {
            $result = Document::findFirst('idDocument = "' . $id . '"');
            $lv = new labelfilevalue();
            $lv->url = $this->getBaseUrl() . $result->Path;
            $lv->name = $result->Naam;
            $enum[] = $lv;

        } else if ($key == 'product_has_document') {

            $results = ProductHasDocument::find('Product_idProduct = "' . $id . '"');
            foreach ($results as $naam) {
                $naam = $naam->Document->toArray();
                $lv = new labelfilevalue();
                $lv->url = $this->getBaseUrl() . $naam['Path'];
                $lv->name = $naam['Naam'];
                $enum[] = $lv;
            }

        } else if ($key == 'document_has_contract') {

            $results = DocumentHasContract::find('Contract_idContract = "' . $id . '"');
            foreach ($results as $naam) {
                $naam = $naam->Document->toArray();
                $lv = new labelfilevalue();
                $lv->url = $this->getBaseUrl() . $naam['Path'];
                $lv->name = $naam['Naam'];
                $enum[] = $lv;
            }
        } else if ($key == 'taak_has_document') {

            $results = TaakHasDocument::find('Taak_idTaak = "' . $id . '"');
            foreach ($results as $naam) {
                $naam = $naam->Document->toArray();

                $lv = new labelfilevalue();
                $lv->url = $this->getBaseUrl() . $naam['Path'];
                $lv->name = $naam['Naam'];
                $enum[] = $lv;
            }
        }
        return $enum;
    }

    private function getEntityColumns($key)
    {
        $mysql = new MySQLQueries();
        $columns = [];
        $model = new $key();
        $schema = $model->getSchema();
        if (strlen($schema) > 0) {
            $dbname = "`" . $schema . "`.";
        } else {
            $dbname = '';
        }
        $query = "DESCRIBE " . $dbname . "`" . strtolower($key) . "`";

        foreach ($mysql->select($query) as $fieldx) {
            $columns[] = $fieldx['Field'];
        }
        return $columns;
    }

    private function getSelectList($key)
    {
        $columns = $this->getEntityColumns($key);
        $enum = [];
        $args = [];
        $structuur = Structuur::find('tabel = "' . strtolower($key) . '" AND sel > 0');

        //ORDER SELECT BY NAME
        if (in_array('Naam', $columns)) {
            $args['order'] = 'Naam ASC';
        } else {
            $order = '';
            foreach ($structuur->toArray() as $index => $str) {
                if ($index > 0) {
                    $order .= ',';
                }
                $order .= $str['field'] . ' ASC';
            }
            if (strlen($order) > 0) {
                $args['order'] = $order;
            }
        }

        $results = $key::find($args);
        foreach ($results as $naam) {
            $label = '';
            $columnname = $key . '_id' . $key;
            if (count($structuur) > 0 || !isset($naam->Naam)) {

                if (in_array($columnname, $columns) && $naam->$columnname > 0) {
                    $str = '';
                    foreach ($structuur as $index => $val) {
                        if ($index > 0) {
                            $str .= ' ';
                        }
                        $n = $val->name;
                        if (isset($naam->$key)) {
                            $str .= $naam->$key->$n;
                        }
                    }
                    $label .= $str . ' - ';
                }

                $lv = new labelvalue();
                $col = $columns[0];
                $lv->value = $naam->$col;
                $str = '';
                foreach ($structuur as $index => $val) {
                    if ($index > 0) {
                        $str .= ' ';
                    }
                    $n = $val->name;
                    $str .= $naam->$n;
                }
                $label .= $str;

            } else {
                if (in_array($columnname, $columns) && $naam->$columnname > 0) {
                    $label .= $naam->$key->Naam . ' - ';
                }

                $lv = new labelvalue();
                $col = $columns[0];
                $lv->value = $naam->$col;
                $label .= $naam->Naam;
            }
            $lv->label = $label;

            $enum[$lv->label . uniqid()] = $lv;
        }
        ksort($enum);
        return $enum;
    }

    private
    function getStructuurDatabaseVariable($field, $table)
    {
        $structuur = Structuur::findFirst('field = "' . $field['Field'] . '" AND tabel = "' . $table . '"');
        if (!$structuur) {
            $structuur = new Structuur();
            if (!isset($field['isTableField'])) {
                $field['isTableField'] = true;
            }
            $structuur->istablefield = $field['isTableField'];
            $structuur->field = $field['Field'];
            $structuur->name = $field['Field'];
            $structuur->title = $field['Field'];

            $structuur->placeholder = $field['Field'];
            $structuur->tabel = $table;

            if (!$structuur->save() && $this->globalconfig->status == 'dev') {
                //   print_r($structuur->getMessages());
            }
        }

        if (strlen($structuur->title) == 0) {
            $structuur->title = $structuur->name;
        }
        if (strlen($structuur->placeholder) == 0) {
            $structuur->placeholder = $structuur->name;
        }

        return $structuur;
    }


    /*
    private function getStructuurDatabaseVariable($field, $table)
    {
        $structuur = Structuur::findFirst('field = "' . $field['Field'] . '" AND tabel = "' . $table . '"');
        if (!$structuur) {
            $structuur = new Structuur();
            if (!isset($field['isTableField'])) {
                $field['isTableField'] = true;
            }
            $structuur->istablefield = $field['isTableField'];
            $structuur->field = $field['Field'];
            $structuur->name = $field['Field'];
            $structuur->title = ''; //inputting these is not nescessary unless a form has a different label
            $structuur->placeholder = ''; //inputting these is not nescessary unless a form has a different description
            $structuur->tabel = $table;
            if (!$structuur->save()) {
                //   print_r($structuur->getMessages());
            }
        }
        return $structuur;
    }*/

    private function generateRelationalField($table, $orm, $id, $row)
    {
        //TODO: this is only used for the structuur->cssclass field
        $structuur = $this->getStructuurDatabaseVariable(['Field' => $orm->foreign_structuurname, 'isTableField' => false], $table);
        $f = $structuur->toArray();
        $f['attr'] = json_decode($f['attr'], true);
        $f['name'] = $orm->foreign_classname;

        //TODO remove tight coupling language class
        if (isset($this->language)) {
            $f['title'] = $this->language->translate($orm->foreign_classname);
        } else {
            $f['title'] = $orm->foreign_classname;
        }
        $f['field'] = $orm->tablename;
        $f['tabel'] = $orm->tablename;
        $f['description'] = ' ';
        $f['visible'] = true;
        $f['message'] = '';
        $f['placeholder'] = $orm->foreign_classname;
        if ($orm->isMany()) { //manyToMany
            //TODO: figure out how to do this better
            if ($orm->foreign == 'document') {
                $f['filelist'] = $this->getSelectFileList($orm->tablename, $id);
                $f['type'] = 'files';
            } else {
                $f['enum'] = $this->getSelectList($orm->foreign_classname);
                $f['entity'] = strtolower($orm->foreign_classname);
                $f['type'] = 'multiselect';


            }
            //TODO: make multiple select option values possible with front end
            if (is_object($row)) {
                $class = $orm->classname;
                $foreignid = $orm->foreign_id;
                foreach ($row->$class as $sub) {
                    $f['value'] = [$sub->$foreignid];
                }
            }


        } else { //oneToMany
            if ($orm->tablename == 'document') {
                $f['filelist'] = $this->getSelectFileList($orm->tablename, $id);
                $f['type'] = 'files';
            } else {
                $f['enum'] = $this->getSelectList($orm->classname);
                $f['entity'] = strtolower($orm->classname);
                $f['type'] = 'multiselect';
            }
        }
        if (!isset($f['value'])) {
            $f['value'] = '';
        }
        return $f;
    }

    public function getForeignRelationsDefinedInCode($table, $id, $row)
    {
        $fields = [];
        $classname = ucfirst($table);
        $array = $this->modelsManager->getRelations($classname);
        $array1 = $this->modelsManager->getBelongsTo(new $classname());
        $array2 = $this->modelsManager->getHasOneAndHasMany(new $classname());
        foreach ([$array1, $array2, $array] as $relations) {
            foreach ($relations as $relation) {

                $orm = new OrmEntity();
                $ex = explode('Has', stripslashes($relation->getReferencedModel()));
                if (isset($ex[1])) {
                    $tablename = strtolower($ex[0]) . '_has_' . strtolower($ex[1]);
                    $orm->setTableName($tablename);
                    $orm->setLocalEntity($table);
                    $fields[$orm->tablename] = $this->generateRelationalField($table, $orm, $id, $row);
                } else {
                    $tablename = strtolower($ex[0]);
                    $orm->setTableName($tablename);
                    $orm->setLocalEntity($table);
                    $fields[$orm->tablename] = $this->generateRelationalField($table, $orm, $id, $row);
                }
            }
        }
        return $fields;
    }


    public function getForeignRelations($table, $id, $row)
    {
        //  echo $table;

        $fields = [];
        $mysql = new MySQLQueries();
        foreach ($mysql->getTables($table) as $table2) {
            $orm = new OrmEntity();
            $orm->setTableName($table2['TABLE_NAME']);
            $orm->setLocalEntity($table);

            //TODO: this is only used for the structuur->cssclass field
            $structuur = $this->getStructuurDatabaseVariable(['Field' => $orm->foreign_classname, 'isTableField' => false], $table);
            $f = $structuur->toArray();

            $attr = json_decode($f['attr'], true);
            $f['attr'] = ['subform' => false];
            if (is_array($attr)) {
                foreach ($attr as $index => $value) {
                    $f['attr'][$index] = $value;
                }
            }

            //   $f['name'] = $orm->foreign_classname;
            //   $f['title'] = $this->language->translate($orm->foreign_classname);

            $f['field'] = $orm->tablename;
            $f['tabel'] = $orm->tablename;
            $f['description'] = ' ';
            $f['visible'] = true;
            $f['message'] = '';

            //  $f['placeholder'] = $orm->foreign_classname;

            if ($orm->isMany()) { //manyToMany

                //TODO: figure out how to do this better
                if ($orm->foreign == 'document') {
                    $f['filelist'] = $this->getSelectFileList($orm->tablename, $id);
                    $f['type'] = 'files';
                } else {
                    $f['enum'] = $this->getSelectList($orm->foreign_classname);
                    $f['entity'] = strtolower($orm->foreign_classname);
                    $f['type'] = 'multiselect';
                }


                //TODO: make multiple select option values possible with front end
                if (is_object($row)) {
                    $class = $orm->classname;
                    $foreignid = $orm->foreign_id;

                    /*
                    $f['value'] = [];
                    foreach ($row->$class as $sub) {
                        $f['value'][] = $sub->$foreignid;
                    } */
                }
            } else { //oneToMany
                if ($orm->tablename == 'document') {
                    $f['filelist'] = $this->getSelectFileList($orm->tablename, $id);
                    $f['type'] = 'files';
                } else {
                    $f['enum'] = $this->getSelectList($orm->classname);
                    $f['entity'] = strtolower($orm->classname);
                    $f['type'] = 'multiselect';
                }
            }
            if (!isset($f['value'])) {
                $f['value'] = '';
            }

            $fields[$orm->tablename] = $f;
        }
        return $fields;
    }

    public static function getBetween($str, $left = "(", $right = ")")
    {
        $st = explode($left, $str);
        $fst = explode($right, $st[1]);
        return $fst[0];
    }

    public function render()
    {
        //TODO: fix everywhere
        $mysql = new MySQLQueries();

        $fields = [];
        $count = 0;

        $objectrow = [];
        if ($this->tableRowId) {
            $entity = ucfirst($this->table);

            // echo $entity.'='.'id' . $entity . ' = ' . $this->tableRowId;

            $row = $entity::findFirst('id' . $entity . ' = ' . $this->tableRowId);
            $objectrow = $row;
            $row = $row->toArray();
        }

        //TODO: not always defined
        $structuur = [];

        $structuurtable = Structuurtable::findFirst('sqltable = "' . $this->table . '"');
        if (!$structuurtable) {
            $structuurtable = new Structuurtable();
            $structuurtable->sqltable = $this->table;
            if (!$structuurtable->save()) {
                print_r($structuurtable->getMessages());
            }
        }

        $tags = $mysql->select("DESCRIBE `" . strtolower($this->table) . "`");
        foreach ($tags as $index => $field) {
            if ($count > 0) {

                $structuur = $this->getStructuurDatabaseVariable($field, $this->table);
                if ($field['Field'] != 'id' . $this->table && $field['Field'] != 'Verlenging') {
                    $f = $structuur->toArray();

                    if (strlen($f['title']) == 0) {
                        $f['title'] = $f['name'];
                    }
                    if (strlen($f['placeholder']) == 0) {
                        $f['placeholder'] = $f['name'];
                    }

                    $attr = json_decode($f['attr'], true);
                    $f['attr'] = ['subform' => false];
                    if (is_array($attr)) {
                        foreach ($attr as $index => $value) {
                            $f['attr'][$index] = $value;
                        }
                    }

                    $f['visible'] = true;
                    $f['message'] = '';

                    if ($f['description'] == 'NULL' || $f['description'] == 'null' || $f['description'] == null) {
                        $f['description'] = '';
                    }

                    $f['title'] = $this->language->translate($f['title']);

                    if ($field['Null'] == 'NO') {
                        $f['required'] = true;
                    } else {
                        $f['required'] = false;
                    }

                    if ($this->tableRowId) {
                        if ($row[$field['Field']] == 'NULL' || $row[$field['Field']] == 'null' || $row[$field['Field']] == null) {
                            $row[$field['Field']] = '';
                        }
                        $f['value'] = $row[$field['Field']];
                    } else if (strlen($f['defaultvalue']) > 0) {
                        $f['value'] = $f['defaultvalue'];
                    }

                    $dont = false;
                    if (strpos($field['Field'], '_id') !== false) {
                        $foreign = explode('_id', $field['Field']);
                        $key = ucfirst($foreign[1]);
                        //TODO should a class always exist? Or is it fine to Name relations te way you want it. Contract > extra document fields
                        //custom relationships go to else
                        $key = preg_replace('/[0-9]+/', '', $key);
                        if (class_exists($key)) {
                            if ($key == 'Document') {
                                //THIS IS AN EXCEPTION FOR FILES THAT ARE NOT LINKED BY MANY-TO-MANY
                                $f['type'] = 'file';
                                if (isset($f['value']) && $f['value'] > 0) {
                                    $f['filelist'] = $this->getSelectFileList($key, $f['value']);
                                }
                                $f['entity'] = strtolower($key);
                            } else {
                                $f['type'] = 'select';
                                $f['enum'] = $this->getSelectList($key);
                                $f['entity'] = strtolower($key);
                            }
                        } else {
                            $f['type'] = 'file';
                        }
                    } else if (strpos($field['Field'], 'xid') !== false) {
                        $foreign = explode('xid', $field['Field']);
                        $key = ucfirst($foreign[1]);
                        //custom relationships go to else
                        $f['type'] = 'multivalue';
                        if(isset($f['value'])) {
                            $f['value'] = explode(',',$f['value']);
                        }
                        $f['enum'] = $this->getSelectList($key);
                        $f['entity'] = strtolower($key);

                    } else {
                        //TODO: rework this bullshit
                        if (strpos($field['Type'], 'varchar') !== false) {
                            $type = 'string';
                        } else if (strpos($field['Type'], 'tinyint') !== false) {
                            $type = 'switch';
                            if (!isset($f['value'])) {
                                $f['value'] = false;
                            } else if ($f['value'] == 1) {
                                $f['value'] = true;
                            }
                        } else if (strpos($field['Type'], 'decimal') !== false) {
                            $type = 'money';
                        } else if (strpos($field['Type'], 'int') !== false) {
                            $type = 'number';
                            $f['minlength'] = 1;
                            $f['maxlength'] = $this->getBetween($field['Type']);
                        } else if (strpos($field['Type'], 'datetime') !== false) {
                            $type = 'date';
                        } else if (strpos($field['Type'], 'text') !== false) {
                            $type = 'textarea';
                        } else if (strpos($field['Type'], 'double') !== false) {
                            $type = 'number';
                            $f['minlength'] = 1;
                            $f['maxlength'] = 2; // $this->getBetween($field['Type']);
                        } else if ($field['Type'] == 'period') {
                            $type = $field['Type'];
                        } else if ($f['Type'] == 'addselect') {

                        }

                        if (isset($structuur->cssclass) && strlen($structuur->cssclass) > 0) {
                            $f['cssclass'] = $structuur->cssclass;
                        }


                        if ($f['type'] == 'addselect' && isset($f['value'])) {
                            $f['value'] = json_decode($f['value']);
                        }

                        $f['type'] = $type;
                        if (isset($structuur->type) && strlen($structuur->type) > 0) {
                            $f['type'] = $structuur->type;
                        }
                    }


                    if (!isset($f['value'])) {
                        $f['value'] = '';
                    }

                    if (!$dont) {
                        $fields[$field['Field']] = $f;
                    }
                }
            }
            $count++;
        }

        $code = [];
        if ($this->globalconfig->database->consistency == false) {
            $code = $this->getForeignRelationsDefinedInCode($this->table, $this->tableRowId, $objectrow);
        }
        $fields = array_merge($fields, $this->getForeignRelations($this->table, $this->tableRowId, $objectrow), $code);
        $allfields = $fields;

        //show only relevant columns in forms
        if (!isset($structuurtable->fieldsinform) || strlen($structuurtable->fieldsinform) < 5) {

            //  print_r($structuurtable->fieldsinform);
            $fieldsinform = [];
            foreach ($fields as $field) {
                $fieldsinform[] = $field['field'];
            }

            $structuurtable->fieldsinform = json_encode($fieldsinform);
            $structuurtable->save();
        } else {
            $fieldsinform = json_decode($structuurtable->fieldsinform);
            if (!is_array($fieldsinform)) {
                throw new Exception("Faulty table string! Check your structuurtable table!");
            }
            if (is_array($fieldsinform)) {
                $defaultnotvisiblefields = ['Createdat', 'Lastedit', 'Updatedat', 'Deletedat', 'Eigenaar_idEigenaar'];
                foreach ($fields as $index => $field) {
                    if (!in_array($field['field'], $fieldsinform)) {
                        unset($fields[$index]);
                    } else if (in_array($field['field'], $defaultnotvisiblefields)) {
                        unset($fields[$index]);
                    }
                }
            }
        }

        //order fields according to Structuur:Entityorder
        $tempfields = [];
        $cc = 1;
        foreach ($fields as $field) {
            if (!isset($tempfields[$field['Entityorder']])) {
                $tempfields[$field['Entityorder']] = $field;
            } else {
                $tempfields[(100 + $cc)] = $field;
                $cc++;
            }
        }
        ksort($tempfields);
        foreach ($tempfields as $field) {
            $newfields[$field['field']] = $field;
        }
        $json = [];
        $json['$schema'] = 'http://json-schema.org/draft-04/schema#';
        $json['type'] = 'object';
        $json['title'] = $structuurtable->title;
        $json['table'] = $structuurtable->sqltable;
        $json['appdata'] = $this->appdata->generate();
        $json['savebuttontext'] = $structuurtable->savebuttontext;
        $json['cancelbuttontext'] = $structuurtable->cancelbuttontext;
        $json['structuurtable'] = $structuurtable->toArray();

        $json['description'] = $structuurtable->description;
        $json['properties'] = $newfields;

        $json['allconnectedproperties'] = $allfields;
        $json['additionalProperties'] = false;

        return $json;
    }
}

class labelvalue
{
    public $value;
    public $label;
}


class labelfilevalue
{
    public $url;
    public $name;
}