<?php

use Phalcon\Mvc\User\Component;

class FileHandler extends Component
{
    private $payload;
    private $imageUtils;

    public function __construct($security)
    {
        $this->payload = $security;
        $this->imageUtils = new ImageUtils();
    }

    private function is_image($path)
    {
        if (@is_array(getimagesize($path))) {
            return true;
        } else {
            return false;
        }
    }

    public function uploadFile()
    {
        $id = uniqid();
        foreach ($_FILES as $file) {
            $doc = new Document();
            $doc->Versie = 1;
            $info = pathinfo($file['name']);
            if (!is_dir('../public/files/' . $id . '/')) {
                mkdir('../public/files/' . $id . '/');
            }
            $target = '../public/files/' . $id . '/' . $file['name'];

            if (move_uploaded_file($file['tmp_name'], $target)) {

                if ($this->is_image($target)) {

                    foreach ($this->globalconfig->imagesizes as $index => $value) {
                        if (isset($value['x'])) {
                            if (!is_dir('../public/files/' . $id . '/' . $index)) {
                                mkdir('../public/files/' . $id . '/' . $index);
                            }
                            $this->imageUtils->copy_image($target, '../public/files/' . $id . '/' . $index . '/' . $file['name']);
                            $this->imageUtils->resize_image('../public/files/' . $id . '/' . $index . '/' . $file['name'], $value['x'], $value['y'], false);
                        }
                    }

                } else {

                }
                $doc->Naam = $file['name'];
                $doc->Path = '/files/' . $id . '/' . $file['name'];
                $doc->Eigenaar_idEigenaar = $this->payload->idEigenaar;
                if (!$doc->save()) {
                    print_r($doc->getMessages());
                    die();
                } else {
                    $jsondata = $doc->toArray();
                    $jsondata['folder'] = $id;
                }
            }
        }
        return $jsondata;
    }

    public function storeFile($data, $filename, $id = false)
    {
        /*
        $doc = new Document();
        $doc->Versie = 1;
        if (!$id) {
            $id = uniqid();
        }
        $doc->Naam = $filename;
        $doc->Path = '/files/' . $id . '/' . $filename;
        $doc->Eigenaar_idEigenaar = 6; //$this->payload->idEigenaar;
        if (!$doc->save()) {
            print_r($doc->getMessages());
            die();
        } else {
            $jsondata = $doc->toArray();
        }*/

        if ($data == 0) {
            return true;
        }

        $target = '../public/files/' . $id . '/' . $filename;

        if (file_put_contents($target, $data)) {
            return true;
        }
        echo 'false';
        return false;
    }
}