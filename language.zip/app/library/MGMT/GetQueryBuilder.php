<?php

use Phalcon\Mvc\User\Component;

class GetQueryBuilder extends Component
{
    private $eigenaar;

    public function __construct($eigenaar)
    {
        $this->eigenaar = $eigenaar;
    }

    public function getQuery($q, $query, $ei, $order = false, $filters)
    {
        $args = [];
        if ($order) {
            $args['order'] = $order;
        }
        if ($q) {
            if (isset($query) && strlen($query) > 3) {
                $query .= ' AND ';
            }
            $query .= ' ( ';
            $structuur = Structuur::find('tabel = "' . strtolower($ei->tablename) . '" AND istablefield > 0');
            foreach ($structuur as $index => $field) {
                if ($index > 0) {
                    $query .= ' OR ' . $field->field . ' LIKE "%' . $q . '%"';
                } else {
                    $query .= '' . $field->field . ' LIKE "%' . $q . '%"';
                }
            }
            $query .= ' ) ';
            $query = $this->ProcessFilterArrayToQuery($filters, $query, $ei);

            $args['conditions'] = $query;

            return $ei->entityname::find($args);
        } else if ($this->eigenaar->Rol_idRol < 4 || strlen($query) > 5) {
            $args['conditions'] = $this->ProcessFilterArrayToQuery($filters, $query, $ei);

            if (strlen($args['conditions']) > 5) {
                $entity =  $ei->entityname::find($args);
                return $entity;
            } else {
                return $ei->entityname::find($args);
            }
        } else {
            return [];
        }
    }

    private function ProcessFilterArrayToQuery($filterx, $queryx, $ei)
    {
        $mysql = new MySQLQueries();
        $tablefields = [];

        foreach ($mysql->select('DESCRIBE `' . $ei->tablename.'`') as $field) {
            $tablefields[] = $field['Field'];
        }


        $filteredfields = 0;
        if (isset($filterx)) {
            $filters = [];
            foreach ($filterx as $filter) {
                $filters[$filter['field']] = $filter['value'];
            }
        }

        if (count($filters) > 0) {
            if (strlen($queryx) > 0) {
                $query = ' AND (';
            } else {
                $query = ' ( ';
            }
            $cc = 0;
            foreach ($filters as $index => $filter) {

                if (count($filter) > 0) {
                    if ($cc > 0) {
                        $query .= ' AND ';
                    }
                    $query .= ' ( ';

                    if (in_array($index, $tablefields)) {

                        $cc2 = 0;
                        foreach ($filter as $index2 => $value) {
                            if ($cc2 > 0) {
                                $query .= ' OR ';
                            }
                            if (is_numeric($value)) {
                                $query .= $index . ' = ' . $value . '';
                            } else {
                                $query .= $index . ' = "' . $value . '"';
                            }
                            $filteredfields++;
                            $cc2++;
                        }
                    } else {
                        //find relationship table: many-to-many
                        $classname = ucfirst($ei->tablename) . 'Has' . ucfirst($index);
                        if (!class_exists(ucfirst($ei->tablename) . 'Has' . ucfirst($index))) {
                            $classname = ucfirst($index) . 'Has' . ucfirst($ei->tablename);
                        }

                        //get ids of main entity that have this relation
                        $orids = [];
                        $cc2 = 0;
                        foreach ($filter as $index2 => $value) {
                            $rows = $classname::find(ucfirst($index).'_id' . ucfirst($index) . ' = ' .$value);


                            $entityid = ucfirst($ei->tablename).'_id'.ucfirst($ei->tablename);

                            foreach($rows as $row) {
                                if ($cc2 > 0) {
                                    $query .= ' OR ';
                                }
                                $query .= 'id'.ucfirst($ei->tablename).' = '.$row->$entityid;
                                $orids[] = $row->$entityid;
                                $filteredfields++;
                                $cc2++;
                            }

                            //look for child-parent relation
                            $children = $index::find(ucfirst($index).'_id'.ucfirst($index).' = '.$value);
                            foreach($children as $child)
                            {
                                $localid = 'id'.ucfirst($index);
                                $rows = $classname::find(ucfirst($index).'_id' . ucfirst($index).' = '.$child->$localid);
                                foreach($rows as $row)
                                {
                                    if(!in_array($row->$entityid,$orids)){
                                        if ($cc2 > 0) {
                                            $query .= ' OR ';
                                        }
                                        $query .= 'id'.ucfirst($ei->tablename).' = '.$row->$entityid;
                                        $orids[] = $row->$entityid;
                                    }
                                    $cc2++;
                                }
                            }
                        }
                    }

                    $query .= ' ) ';
                    $cc++;
                }
            }
            $query .= ' ) ';
        }

        if ($filteredfields == 0) {
            return $queryx;
        }

        return $queryx . $query;
    }
}