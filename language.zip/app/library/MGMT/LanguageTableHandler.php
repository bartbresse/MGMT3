<?php

class LanguageTableHandler extends LanguageHandler2
{
    public function processColumns($columns)
    {
        $base = $this->settings->base;
        $used = $this->settings->used;
        $words = []; $translated = [];

        foreach ($columns as $column) {
            $words[] = $column['label'];
        }

        foreach (Language::find($this->buildQuery($base, $words)) as $entry) {
            $this->words[$entry->$base] = ucfirst($entry->$used);
        }
    }
}