<?php
use Phalcon\Mvc\User\Component;

class MySQLQueries extends Component
{
    public $result;
    public $errors;

    public function select($query)
    {
        $conn2 = new PDO('mysql:host='.$this->globalconfig->host.';dbname='.$this->globalconfig->dbname, $this->globalconfig->username, $this->globalconfig->password);
        $conn2->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );

        $query3 = $conn2->prepare($query);
        $this->result = $query3->execute();
        $this->errors = $query3->errorInfo();
        if($query3->rowCount() > 0) {
            return $query3->fetchAll();
        }else{
            return false;
        }
    }

    public function getTablesReferencedTables($tablename)
    {
        return $this->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      ( TABLE_NAME = '".$tablename."' )");
    }

    public function getTables($tablename)
    {
        //OR TABLE_NAME = '".$tablename."'
        $rows = $this->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      ( REFERENCED_TABLE_NAME = '" . $tablename . "' )");

        if(is_array($rows) && count($rows) > 0) {
            return $rows;
        }else{
            return [];
        }
    }

    public function getStructuur($tablename){

        /*
        select *,
COALESCE(`sonder_dev76b`.`structuur`.`placeholder`, `sonder_dev76b`.`structuur`.`name`) AS `placeholder`,
COALESCE(`sonder_dev76b`.`structuur`.`title`, `sonder_dev76b`.`structuur`.`name`) AS `title`
from `information_schema`.`columns`
left join `sonder_dev76b`.`structuur` on `sonder_dev76b`.`structuur`.`field` = `information_schema`.`columns`.`COLUMN_NAME`
where `table_schema` = 'sonder_cmx15' and `table_name` = 'contract' and `sonder_dev76b`.`structuur`.`tabel` = 'contract'
ORDER BY `columns`.`ORDINAL_POSITION` ASC
        */

        $rows = $this->select("select *, 
COALESCE(`".$this->globalconfig->centraldbname."`.`structuur`.`placeholder`, `".$this->globalconfig->centraldbname."`.`structuur`.`name`) AS `placeholder`,
COALESCE(`".$this->globalconfig->centraldbname."`.`structuur`.`title`, `".$this->globalconfig->centraldbname."`.`structuur`.`name`) AS `title`
from `information_schema`.`columns`
left join `".$this->globalconfig->centraldbname."`.`structuur` on `".$this->globalconfig->centraldbname."`.`structuur`.`field` = `information_schema`.`columns`.`COLUMN_NAME`
where `table_schema` = '".$this->globalconfig->dbname."' and `table_name` = '".$tablename."' and `".$this->globalconfig->centraldbname."`.`structuur`.`tabel` = '".$tablename."' 
ORDER BY `columns`.`ORDINAL_POSITION` ASC");

        if(is_array($rows) && count($rows) > 0) {
            return $rows;
        }else{
            return [];
        }
    }
}