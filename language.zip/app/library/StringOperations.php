<?php

class StringOperations
{
    public static function getBetween($str,$left = "(",$right = ")")
    {
        $st =explode($left,$str);
        $fst = explode($right,$st[1]);
        return $fst[0];
    }
}