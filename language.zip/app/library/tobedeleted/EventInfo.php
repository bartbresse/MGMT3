<?php

class EventInfo
{
    public $name;
    public $entity;
    public $entityInfo;

    public function __construct($name,$entity,$entityInfo = false)
    {
        $this->entity = $entity;
        $this->name = $name;
        $this->entityInfo = $entityInfo;
    }
}