<?php
use Phalcon\Mvc\User\Component;

class RelatieImport extends Component
{
    public function import()
    {
        $file = 'relaties.csv';
        ini_set('max_execution_time', 600);
        if (($handle = fopen('../public/' . $file, 'r')) !== false) {
            $header = fgetcsv($handle);
            $params = ['body' => []];
            while (($data = fgetcsv($handle, 0, ';')) !== false) {

                // Naam	Bezoekadres	Postcode	Plaats	Provincie	Land	Postadres	Postcode	Plaats	Provincie	Land	Telefoon	Fax	Website

                /*
                [0] => 123Telcom
                [1] => capitol 10
                [2] => 7521 PL
                [3] => Enschede
                [4] => Overijsel
                [5] => Nederland
                [6] => postbus545
                [7] => 7500 AM
                [8] => Enschede
                [9] =>
                [10] => Nederland
                [11] => 0881230123
                [12] =>
                [13] => www.123telcom.nl
                */

                $re = new Relatie();
                $re->Naam = $data[0];
                $re->Bezoekadres = $data[1];
                $re->Postcode = $data[2];
                $re->Plaats = $data[3];
                $re->Provincie = $data[4];
                $re->Land = $data[10];
                $re->Telefoon = $data[11];
                $re->Fax = $data[12];
                $re->Website = $data[13];
          //      if(!$re->save())
                {
            //        print_r($re->getMessages());
                }

            }
        }
    }
}