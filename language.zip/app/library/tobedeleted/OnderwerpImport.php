<?php
use Phalcon\Mvc\User\Component;

class OnderwerpImport extends Component
{
    public function import()
    {
        $file = 'onderwerpen.csv';
        ini_set('max_execution_time', 600);
        if (($handle = fopen('../public/' . $file, 'r')) !== false) {
            $header = fgetcsv($handle, 0, ';');
            print_r($header);

            $params = ['body' => []];
            while (($data = fgetcsv($handle, 0, ';')) !== false) {

             //   print_r($data);

                /*
                [0] => Naam
                [1] => Contract
                [2] => Relatie
                [3] => Beschrijving
                [4] => Opmerkingen
                [5] => Toevoegdatum
                [6] => Eigenaar

                [0] => DFC check - 7-12-2017
                [1] => Simyo - Telefonie - Mobiel - Taalpunt West Maas en Waal
                [2] => Simyo
                [3] =>
                [4] =>
                [5] => 07-12-2017
                [6] => Anne Boelsma
                */

                $on = new Onderwerp();
                $on->Naam = $data[0];
                echo $data[1];
                $contract = Contract::findFirst('Naam LIKE "%'.$data[1].'%"');
                $on->idContract = $contract->idcontract;
                $on->Beschrijving = $data[3];
                $on->Opmerkingen = $data[4];
                $on->Toevoegdatum = date('Y-m-d',strtotime($data[5]));
                $d = array_reverse(explode(' ',$data[6]));
                $eigenaar = Eigenaar::findFirst('Achternaam LIKE "%'.$d[0].'%"');
                $on->idEigenaar = $eigenaar->idEigenaar;
                if(!$on->save())
                {
                    print_r($on->getMessages());
                }
            }
        }
    }
}