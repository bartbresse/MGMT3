<?php
use Phalcon\Mvc\User\Component;

class TakenImport extends Component
{
    public function import()
    {
        $file = 'taken.csv';
        ini_set('max_execution_time', 600);
        if (($handle = fopen('../public/' . $file, 'r')) !== false) {
            $header = fgetcsv($handle, 0, ';');
            print_r($header);

            $params = ['body' => []];
            while (($data = fgetcsv($handle, 0, ';')) !== false) {



                /*
                [0] => Naam
                [1] => Contract
                [2] => Onderwerp
                [3] => Relatie
                [4] => Beschrijving
                [5] => Einddatum
                [6] => Notificatie
                [7] => Prioriteit
                [8] => Status
                [9] => Toevoegdatum
                [10] => Eigenaar

                [0] => Herinnering einddatum
                [1] => Previder - Lijnverbinding - Druten
                [2] =>
                [3] => Previder
                [4] => Bepaal wat er moet gebeuren op de einddatum van het contract.
                [5] => 10-06-2015
                [6] => 12-04-2015
                [7] => Normaal
                [8] => Gereed
                [9] => 07-06-2016
                [10] => Marc de Gans
                */

                $taak = new Taak();

                $contract = Contract::findFirst('Naam LIKE "%'.$data[1].'%"');
                $taak->contract_idcontract = $contract->idContract;

                $taak->Naam = $data[3];
                $taak->Beschrijving = $data[4];
                $taak->Einddatum = date('Y-m-d',strtotime($data[5]));
                $taak->Notificatiedatum = date('Y-m-d',strtotime($data[6]));

                $taakstatus = Taakstatus::findFirst('Naam = "'.$data[8].'"');
                $taak->Taakstatus_idTaakstatus = $taakstatus->idTaakstatus;

                $prioriteit = Prioriteit::findFirst('Naam = "'.$data[7].'"');
                $taak->Prioriteit_idPrioriteit = $prioriteit->idPrioriteit;

                $d = array_reverse(explode(' ',$data[10]));
                $eigenaar = Eigenaar::findFirst('Achternaam LIKE "%'.$d[0].'%"');
                $taak->Eigenaar_idEigenaar = $eigenaar->idEigenaar;

                $taak->einddatumtaak = date('Y-m-d',strtotime($data[9]));

                $onderwerp = Onderwerp::findFirst('Naam = "'.$data[2].'"');
                if($onderwerp) {
                    $taak->Onderwerp_idOnderwerp = $onderwerp->idOnderwerp;
                }


                if(!$taak->save())
                {
                    print_r($taak->toArray());
                    print_r($data);
                    print_r($taak->getMessages());
                }


            }
        }
    }
}