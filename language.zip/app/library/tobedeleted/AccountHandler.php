<?php
use Phalcon\Mvc\User\Component;

class AccountHandler extends Component
{
    public function notifyNewUser()
    {
        $eh = new EmailHandler('U bent uitgenodigd voor de ','','');
        $eh->send();
    }

    public function prepareNewAccount($post)
    {
        if($post && isset($post['Password']) && isset($post['Voornaam']) && isset($post['Achternaam'])) {
            if ($post['Password'] === $post['PasswordAgain']) {
                $post['Password'] = password_hash($post['Password'], PASSWORD_BCRYPT);
                //$post['Rol_idRol'] = 1;
                $post['Eigenaarstatus_idEigenaarstatus'] = 1;
                $post['Activation'] = time() + (24 * 60 * 60) . '_' . md5(time() . $post['Voornaam'] . $post['Achternaam']);

                unset($post['PasswordAgain']);
                unset($post['undefined']);
            }
        }

        return $post;
    }
}