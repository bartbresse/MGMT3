<?php
use Phalcon\Mvc\User\Component;

class ContractImport extends Component
{
    public function import()
    {
        $file = 'contract.csv';
        ini_set('max_execution_time', 600);
        if (($handle = fopen('../public/' . $file, 'r')) !== false) {
            $header = fgetcsv($handle, 0, ';');
           //print_r($header);

           //die();

            $params = ['body' => []];
            while (($data = fgetcsv($handle, 0, ';')) !== false) {

               // print_r($data);

                /*
                [0] => Nummer
                [1] => Naam
                [2] => Relatie
                [3] => Contractsoort
                [4] => Begindatum
                [5] => Einddatum
                [6] => Opzegtermijn
                [7] => Verlengtermijn
                [8] => Maximale verlengingsperiode
                [9] => Toevoegdatum
                [10] => Eigenaar
                [11] => Vestigingen
                [12] => Status
                */

                //

                $contract = new Contract();
                $contract->Nummer = trim($data[0],' ');
                $contract->Naam = trim($data[1],' ');
                $cs = Contractsoort::findFirst('Naam LIKE "%'.$data[3].'%"');

                //print_r($cs->toArray());

                $contract->Contractsoort_idContractsoort = $cs->idContractsoort;
                $contract->Begindatum = date('Y-m-d',strtotime($data['4']));
                $contract->Einddatum = date('Y-m-d',strtotime($data['5']));
                $contract->Opzegtermijn = '';
                $contract->Verlenging = $data[7];

                $d = array_reverse(explode(' ',$data[10]));
                $eigenaar = Eigenaar::findFirst('Achternaam LIKE "%'.$d[0].'%"');
                $contract->Eigenaar_idEigenaar = $eigenaar->idEigenaar;



                $contractstatus = Contractstatus::findFirst('Naam = "'.$data[12].'"');

                //print_r($contractstatus->toArray());

                $contract->contractstatus_idContractstatus = $contractstatus->idcontractstatus;

                $relatie = Relatie::findFirst('Naam = "'.utf8_decode ($data[2]).'"');
                $contract->Relatie_idRelatie = $relatie->idRelatie;

                if(!$contract->save())
                {
                    print_r($data);
                    print_r($contract->toArray());
                    print_r($contract->getMessages());
                }

            }
        }
    }
}