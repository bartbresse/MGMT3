<?php

class EntityInfo
{
    public function __construct($tablename, $entityrowid = false)
    {
        $this->tablename = $tablename;
        $this->entityname = ucfirst($tablename);
        $this->detailview = false;
        $this->entityrowid = $entityrowid;
    }

    public $tablename;
    public $entityname;
    public $detailview;
    public $entityrowid;
    public $structuurtable;

    public function setStructuurtable($structuurtable)
    {
        $this->structuurtable = $structuurtable;
    }

    public function isManyToMany()
    {
        $has = explode('_has_',$this->tablename);
        if(isset($has[1]))
        {
            return true;
        }
        return false;
    }

    public $tablestructuur;

    public function setTableRelationsStructuur($structuur)
    {
        $this->tablestructuur = $structuur;
    }

    public $data;
}