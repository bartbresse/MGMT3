<?php

use Phalcon\Mvc\User\Component;

class NotificationModel extends Component
{

    private $tasks;
    private $contracts;

    public function addUpcomingTask($taak)
    {
        $this->tasks['upcoming'][] = $taak;
    }

    public function addUpcomingNotificationTask($taak)
    {
        $this->tasks['notification'][] = $taak;
    }

    public function addOverdueTask($taak)
    {
        $this->tasks['overdue'][] = $taak;
    }

    public function addUpcomingNotificationContract($contract)
    {
        $this->contracts['notification'][] = $contract;
    }

    public function addEndingContract($contract)
    {
        $this->contracts['ending'][] = $contract;
    }

    public function getTasks()
    {

        /*
        print_r($this->contracts);

        print_r($this->tasks);

        foreach ($this->tasks as $index => $tasks) {
            foreach ($tasks as $task) {

            }

        } */
    }

    public function getEmail()
    {
        $html = '<div>';
        $html .= '<h2>Contracten</h2>';
        foreach ($this->contracts as $index => $contracts) {
            $html .= '<h3>'.$index.'</h3>';
            $html .= '<table>';
            foreach ($contracts as $contract) {
                $html .= '<tr><td>'
                        .'<a href="'.$this->globalconfig->frontend.'/view/contract/'.$contract->idContract.'">'
                        .$contract->Nummer.'&nbsp;'.$contract->Naam.'</a> '.$contract->Einddatum.' '.$contract->Prioriteit->Naam.
                        '</td></tr>';
            }
            $html .= '</table>';
        }

        $html .= '<h2>Taken</h2>';
        foreach ($this->tasks as $index => $tasks) {
            $html .= '<h3>'.$index.'</h3>';
            $html .= '<table>';
            foreach ($tasks as $task) {
                $html .= '<tr><td>'
                    .'<a href="'.$this->globalconfig->frontend.'/view/taak/'.$task->idTaak.'">'
                    .$task->Naam.'</a> '.$task->Einddatum.' '
                    .'</td></tr>';
            }
            $html .= '</table>';
        }

        $html .= '</div>';
        return $html;
    }

    private function getContracts()
    {

    }

    public function formatEmail()
    {

    }
}