<?php

class ContractHasDossier extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Contract_idContract;

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Dossier_idDossier;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->belongsTo('Dossier_idDossier', '\Dossier', 'idDossier', ['alias' => 'Dossier']);
        $this->belongsTo('Contract_idContract', '\Contract', 'idContract', ['alias' => 'Contract']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'contract_has_dossier';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return ContractHasDossier[]|ContractHasDossier
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return ContractHasDossier
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
