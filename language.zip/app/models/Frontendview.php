<?php

class Frontendview extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idFrontendview;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Name;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('idFrontendview', 'LanguageHasFrontendview', 'Frontendview_idFrontendview', ['alias' => 'LanguageHasFrontendview']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'frontendview';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Frontendview[]|Frontendview
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Frontendview
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
