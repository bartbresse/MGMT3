<?php

class Entity extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idEntity;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Name;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Structuurtable_idStructuurtable;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('idEntity', 'LanguageHasEntity', 'Entity_idEntity', ['alias' => 'LanguageHasEntity']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'entity';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Entity[]|Entity
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Entity
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
