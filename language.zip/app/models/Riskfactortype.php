<?php

class Riskfactortype extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idRiskfactortype;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Name;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Subtitle;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->hasMany('idRiskfactortype', 'Riskfactor', 'riskfactortype_idRiskfactortype', ['alias' => 'Riskfactor']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'riskfactortype';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Riskfactortype[]|Riskfactortype
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Riskfactortype
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
