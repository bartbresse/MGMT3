<?php

class Windtunnelincome extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idWindtunnelincome;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Windtunnelrevenues;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Directcostforcustomers;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Costofenergyconsumption;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Consumables;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Sundries;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Costofusageoftariffedequipment;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Maneffortcost;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $reportingtool_idReportingtool;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->belongsTo('reportingtool_idReportingtool', '\Reportingtool', 'idReportingtool', ['alias' => 'Reportingtool']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'windtunnelincome';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Windtunnelincome[]|Windtunnelincome
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Windtunnelincome
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
