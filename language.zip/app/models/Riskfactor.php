<?php

class Riskfactor extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idRiskfactor;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Name;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Subname;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Slider;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Remarks;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Potentialrisks;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $riskfactortype_idRiskfactortype;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Leftslidername;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Rightslidername;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->belongsTo('riskfactortype_idRiskfactortype', '\Riskfactortype', 'idRiskfactortype', ['alias' => 'Riskfactortype']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'riskfactor';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Riskfactor[]|Riskfactor
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Riskfactor
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
