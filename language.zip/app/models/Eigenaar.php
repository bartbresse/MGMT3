<?php

class Eigenaar extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idEigenaar;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Voornaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Achternaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Telefoon;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Email;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Rol_idRol;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Eigenaarstatus_idEigenaarstatus;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    public $Password;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Taal_idTaal;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Token;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idEigenaar', 'Audit', 'Eigenaar_idEigenaar', ['alias' => 'Audit']);
        $this->hasMany('idEigenaar', 'Contract', 'Eigenaar_idEigenaar', ['alias' => 'Contract']);
        $this->hasMany('idEigenaar', 'Document', 'Eigenaar_idEigenaar', ['alias' => 'Document']);
        $this->hasMany('idEigenaar', 'Dossier', 'Eigenaar_idEigenaar', ['alias' => 'Dossier']);
        $this->hasMany('idEigenaar', 'Gegevens', 'Eigenaar_idEigenaar', ['alias' => 'Gegevens']);
        $this->hasMany('idEigenaar', 'Medewerker', 'Eigenaar_idEigenaar', ['alias' => 'Medewerker']);
        $this->hasMany('idEigenaar', 'Onderwerp', 'Eigenaar_idEigenaar', ['alias' => 'Onderwerp']);
        $this->hasMany('idEigenaar', 'Relatie', 'Eigenaar_idEigenaar', ['alias' => 'Relatie']);
        $this->hasMany('idEigenaar', 'Taak', 'Eigenaar_idEigenaar', ['alias' => 'Taak']);
        $this->hasMany('idEigenaar', 'Usersession', 'Eigenaar_idEigenaar', ['alias' => 'Usersession']);
        $this->belongsTo('Eigenaarstatus_idEigenaarstatus', '\Eigenaarstatus', 'idEigenaarstatus', ['alias' => 'Eigenaarstatus']);
        $this->belongsTo('Rol_idRol', '\Rol', 'idRol', ['alias' => 'Rol']);
        $this->belongsTo('Taal_idTaal', '\Taal', 'idTaal', ['alias' => 'Taal']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'eigenaar';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Eigenaar[]|Eigenaar
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Eigenaar
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
