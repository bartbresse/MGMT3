<?php

use Phalcon\Validation;
use Phalcon\Mvc\Model\Validator\Email as EmailValidator;

class User extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $iduser;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $voornaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $achternaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $email;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $password;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $payinguser;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $telefoon;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $company;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $url;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $lastlogin;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $lastlogintry;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $firstlogin;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $verifyurl;

    /**
     *
     * @var string
     * @Column(type="string", length=5, nullable=false)
     */
    public $algemenevoorwaarden;

    /**
     *
     * @var string
     * @Column(type="string", length=5, nullable=false)
     */
    public $marketing;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $verifyadmin;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=false)
     */
    public $adminactivated;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=false)
     */
    public $useractivated;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $versie;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $apploginkey;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $appname;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $subuser;

    /**
     *
     * @var integer
     * @Column(type="integer", length=3, nullable=true)
     */
    public $rights;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $mainuserid;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $language;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $logo;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $passwordresetcode;

    /**
     * Validations and business logic
     *
     * @return boolean
     */
    public function validation()
    {
        $validator = new Validation();

        $validator->add(
            'email',
            new EmailValidator(
                [
                    'model'   => $this,
                    'message' => 'Please enter a correct email address',
                ]
            )
        );

        return $this->validate($validator);
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('iduser', 'UserHasPlanner', 'user_iduser', ['alias' => 'UserHasPlanner']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'user';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return User[]|User
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return User
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
