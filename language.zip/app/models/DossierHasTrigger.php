<?php

class DossierHasTrigger extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Dossier_idDossier;

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Trigger_idTrigger;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->belongsTo('Dossier_idDossier', '\Dossier', 'idDossier', ['alias' => 'Dossier']);
        $this->belongsTo('Trigger_idTrigger', '\Trigger', 'idTrigger', ['alias' => 'Trigger']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'dossier_has_trigger';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return DossierHasTrigger[]|DossierHasTrigger
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return DossierHasTrigger
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
