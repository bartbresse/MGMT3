<?php

class ContractHasContractsoort extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Contract_idContract;

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Contractsoort_idContractsoort;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->belongsTo('Contractsoort_idContractsoort', '\Contractsoort', 'idContractsoort', ['alias' => 'Contractsoort']);
        $this->belongsTo('Contract_idContract', '\Contract', 'idContract', ['alias' => 'Contract']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'contract_has_contractsoort';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return ContractHasContractsoort[]|ContractHasContractsoort
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return ContractHasContractsoort
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
