<?php

class Relatie extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idRelatie;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Bezoekadres;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Postcode;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Plaats;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Telefoon;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Fax;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Website;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Land_idLand;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Inkoopvoorwaarden;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Verkoopvoorwaarden;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Verwerkingsovereenkomst;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idRelatie', 'Contactpersoon', 'Relatie_idRelatie', ['alias' => 'Contactpersoon']);
        $this->hasMany('idRelatie', 'Contract', 'Relatie_idRelatie', ['alias' => 'Contract']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
        $this->belongsTo('Land_idLand', '\Land', 'idLand', ['alias' => 'Land']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'relatie';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Relatie[]|Relatie
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Relatie
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
