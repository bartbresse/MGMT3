<?php

class Invoiceamount extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idInvoiceamount;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Amount;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Planneddate;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Actualdate;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $reportingtool_idReportingtool;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->belongsTo('reportingtool_idReportingtool', '\Reportingtool', 'idReportingtool', ['alias' => 'Reportingtool']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'invoiceamount';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Invoiceamount[]|Invoiceamount
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Invoiceamount
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
