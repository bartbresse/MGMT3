<?php

class Planner extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idplanner;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $versie;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $appname;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $organisatie;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $long;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $lat;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $dbuser;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $dbpass;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $dbname;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $apploginkey;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('idplanner', 'UserHasPlanner', 'planner_idplanner', ['alias' => 'UserHasPlanner']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'planner';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Planner[]|Planner
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Planner
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
