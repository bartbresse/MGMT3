<?php

class Relatiesoort extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idRelatiesoort;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Name;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->hasMany('idRelatiesoort', 'Relatie', 'Relatiesoort_idRelatiesoort', ['alias' => 'Relatie']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'relatiesoort';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Relatiesoort[]|Relatiesoort
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Relatiesoort
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
