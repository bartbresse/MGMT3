<?php

class Reportingtool extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idReportingtool;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Marketsegment;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Customer;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Project;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Facility;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Projectname;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Yearoffirstwindtunnelentry;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Salesitem;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Projectstatus;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Personofcontact;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Customerpersonofcontact;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Projectadministrativestatus;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Comments;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Lastcustomercontact;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Nextdeadlineofcustomercontact;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->hasMany('idReportingtool', 'Invoiceamount', 'reportingtool_idReportingtool', ['alias' => 'Invoiceamount']);
        $this->hasMany('idReportingtool', 'Windtunnelincome', 'reportingtool_idReportingtool', ['alias' => 'Windtunnelincome']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'reportingtool';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Reportingtool[]|Reportingtool
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Reportingtool
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
