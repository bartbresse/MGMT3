<?php

class Document extends \Phalcon\Mvc\Model
{
    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idDocument;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Naam;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Documentsoort_idDocumentsoort;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Versie;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Opmerking;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=false)
     */
    public $Path;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idDocument', 'Contract', 'Document_idDocument2', ['alias' => 'Contract']);
        $this->hasMany('idDocument', 'Contract', 'Document_idDocument1', ['alias' => 'Contract']);
        $this->hasMany('idDocument', 'Contract', 'Document_idDocument3', ['alias' => 'Contract']);
        $this->hasMany('idDocument', 'DocumentHasContract', 'Document_idDocument', ['alias' => 'DocumentHasContract']);
        $this->hasMany('idDocument', 'OnderwerpHasDocument', 'Document_idDocument', ['alias' => 'OnderwerpHasDocument']);
        $this->hasMany('idDocument', 'TaakHasDocument', 'Document_idDocument', ['alias' => 'TaakHasDocument']);
        $this->belongsTo('Documentsoort_idDocumentsoort', '\Documentsoort', 'idDocumentsoort', ['alias' => 'Documentsoort']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'document';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Document[]|Document
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Document
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }
}
