<?php

class LanguageHasFrontendview extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Language_idLanguage;

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Frontendview_idFrontendview;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->belongsTo('Frontendview_idFrontendview', '\Frontendview', 'idFrontendview', ['alias' => 'Frontendview']);
        $this->belongsTo('Language_idLanguage', '\Language', 'idLanguage', ['alias' => 'Language']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'language_has_frontendview';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return LanguageHasFrontendview[]|LanguageHasFrontendview
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return LanguageHasFrontendview
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
