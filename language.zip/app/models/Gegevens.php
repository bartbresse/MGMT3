<?php

class Gegevens extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idGegevens;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Gegevenstype_idGegevenstype;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Waarde;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Maandelijks;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Opmerkingen;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Begindatum;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Einddatum;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Valuta_idValuta;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idGegevens', 'ContractHasGegevens', 'Gegevens_idGegevens', ['alias' => 'ContractHasGegevens']);
        $this->hasMany('idGegevens', 'GegevensHasOnderwerp', 'Gegevens_idGegevens', ['alias' => 'GegevensHasOnderwerp']);
        $this->hasMany('idGegevens', 'TaakHasGegevens', 'Gegevens_idGegevens', ['alias' => 'TaakHasGegevens']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
        $this->belongsTo('Gegevenstype_idGegevenstype', '\Gegevenstype', 'idGegevenstype', ['alias' => 'Gegevenstype']);
        $this->belongsTo('Valuta_idValuta', '\Valuta', 'idValuta', ['alias' => 'Valuta']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'gegevens';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Gegevens[]|Gegevens
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Gegevens
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
