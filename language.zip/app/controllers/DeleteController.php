<?php

class DeleteController extends ControllerBase
{
    public function showAction($entity, $id)
    {
        $returnobject = ['error' => '', 'info' => 'Niets om te verwijderen.'];

        if (strlen($id) > 0) {
            $columns = [];
            $table = $entity;
            $conn = new PDO('mysql:host=localhost;dbname='.$this->globalconfig->dbname, $this->globalconfig->username, $this->globalconfig->password);
            $query2 = $conn->prepare("DESCRIBE `" . strtolower($table) . "`");
            $query2->execute();
            $tags = $query2->fetchAll();

          //  print_r($tags);

            foreach ($tags as $field) {
                $columns[] = $field['Field'];
            }

            if ($entity == 'relatie') {

                $contract = Contract::find('Relatie_idRelatie = "' . $id . '"');
                if (count($contract) > 0) {
                    echo json_encode(['error' => 'Relatie is onderdeel van een of meerdere contracten.']);
                    die();
                }else{
                    $relatie = Relatie::findFirst('idRelatie = "'.$id.'"');
                    if(!$relatie->delete())
                    {
                        print_r($relatie->getMessages());

                        die();
                    }else{
                        echo json_encode(['info' => 'Relatie is verwijderd.']);
                        die();
                    }
                }
            } else if ($entity == 'contract') {

                $chd = ContractHasDossier::find('Contract_idContract = "' . $id . '"');
                if (count($chd) > 0) {
                    echo json_encode(['error' => 'Contract is onderdeel van een Dossier.']);
                    die();
                }

                foreach (Taak::find('Contract_idContract = "' . $id . '"') as $taak) {
                    if (!$taak->delete()) {
                        $returnobject['error'] = 'Taak onder contract kan niet worden verwijderd. ';
                        echo json_encode($returnobject);
                        die();
                    }
                }

                $contract = Contract::findFirst('idContract = "' . $id . '"');
                if (!$contract->delete()) {
                    $returnobject['error'] = 'Contract kan niet worden verwijderd. ';
                    echo json_encode($returnobject);
                    die();
                } else {
                    $returnobject['info'] = 'Contract verwijderd';
                }


            } else {

                //remove connected entities
                $mysql = new MySQLQueries();
                $tables = $mysql->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      REFERENCED_TABLE_NAME = '" . $table . "'");

                foreach ($tables as $table) {
                    $tablename = $table['TABLE_NAME'];

                    $parts = '';
                    foreach (explode('_', $table['TABLE_NAME']) as $part) {
                        $parts .= ucfirst($part);
                    }

                    $referenceentity = $parts::findFirst(ucfirst($entity).'_id'.ucfirst($entity).' = '.$id);
                   if($referenceentity) {
                       $referenceentity->delete();
                   }
                }

                try {
                    $ucentity = ucfirst($entity);
                    $e = $ucentity::findFirst($columns[0] . ' = "' . $id . '"');
                    if ($e) {
                        if (!$e->delete()) {
                            $returnobject['error'] = ucfirst($entity) . ' kan niet worden verwijderd. ';
                        } else {
                            $returnobject['info'] = ucfirst($entity) . ' verwijderd. ';
                        }
                    } else {
                        echo 'ucentity';
                    }
                } catch (Exception $e) {
                    print_r($e->getMessage());
                    die();
                }
            }

            echo json_encode($returnobject);
        }
    }
}
