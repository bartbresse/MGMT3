<?php

class UpdateController extends ControllerBase
{
    public function showAction()
    {
        $updates = [];
        foreach (Softwareupdate::find() as $update) {
            $update = $update->toArray();
            $update['date'] = date('d-m-Y',strtotime($update['Createdat']));
            $updates[] = $update;
        }
        echo json_encode($updates);
    }

    public function helpdeskAction()
    {
        //       <script data-jsd-embedded data-key="7c8773f8-b4c4-4d7b-a726-0ef27b5f07b4" data-base-url="https://jsd-widget.atlassian.com" src="https://jsd-widget.atlassian.com/assets/embed.js"></script>
    }
}