<?php

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{
    protected $urlContainer;

    public function initialize()
    {
        $this->view->disable();
    }

    protected function formatDate($str)
    {
        return date('d-m-Y',strtotime($str));
    }

    public function encodeUrlContainer()
    {

    }
}
