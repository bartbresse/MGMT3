<?php

class DatabaseController extends ControllerBase
{

    /**
     * CREATE NEW DOSSIER
     */
    public function startAction()
    {

        $request_body = json_decode(file_get_contents('php://input'), true);
        $value = $request_body['data']['data']['value'][0];
        $value = Document::findFirst('idDocument = ' . $value);

        if (is_file('../public' . $value->Path)) {

            $database = new DatabaseCli();
            $filename = $database->backupDatabase($this->globalconfig->dbname);

            if (is_file('../public/files/' . $filename)) {

                $filehandler = new FileHandler(false);
                $mysqlqueries = new MySQLQueries();

                $path = explode('/', $value->Path);
                $id = $path[2];

                $results = $database->backupDatabaseTableData();
                foreach ($results as $index => $result) {
                    //store table data
                    if ($filehandler->storeFile($result, $index . '.sql', $id)) {
                        //delete table

                        $query = 'SET FOREIGN_KEY_CHECKS=0; DROP TABLE `' . $index . '`; SET FOREIGN_KEY_CHECKS=1;';
                        $mysqlqueries->select($query);
                    }
                }

                //insert new database structure
                $spath = explode('/files/',$value->Path);
                $result = $database->insertDatabaseStructure($spath[1]);

                foreach ($results as $index => $result) {
                    $query = 'SET FOREIGN_KEY_CHECKS=0; '.$result.' SET FOREIGN_KEY_CHECKS=1;';
                    $rows = $mysqlqueries->select($query);
                    echo $mysqlqueries->result;
                }

                exec("cd /home/sonder/domains/2sonder.com/public_html/dev81/; phalcon all-models",$output);
            } else {
                throw new Exception('Database backup ready.');
            }
        } else {
            throw new Exception($value->Path . ' is not a file.');
        }

        die();


        //$database->backupDatabaseTableData();

        //    foreach ($database->backupDatabaseTableData() as $result)
        {

        }

        $data = [];

        echo json_encode($data, JSON_UNESCAPED_SLASHES);
    }
}