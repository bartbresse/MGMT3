<?php

class ContractstatusController extends ControllerBase
{
    public function indexAction()
    {

    }

    public function showAction()
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        if(!isset($request_body['data']['filters']))
        {
            $request_body['data']['filters'] = [];
        }
        $render = $this->mgmt->getByEntityName('contract', '', '',false,$request_body['data']['filters']);
        $rows = [];
        foreach($render['data'] as $row)
        {
            $cc=0;
            $cc2=0;
            foreach($row as $index => $field)
            {
                if(isset($field['value'])) {
                    if (strlen($field['value']) > 1) {
                        $cc2++;
                    }
                    $cc++;
                }
            }
            $percentage = round((100 * $cc2) / $cc,0);
            $row['percentage']['value'] = $percentage.'%';

            $tc = Triggercache::findFirst('uuid = "'.$row['Triggers']['value'].'"');
            if($tc){ $data = json_decode($tc->data,true); }

            $triggers = [];
            foreach(Trigger::find() as $trigger)
            {
                $atrigger = $trigger->toArray();
                $atrigger['value'] = 'no';
                if($tc)
                {
                    if(isset($data[$trigger->idTrigger])) {
                        if($trigger->Triggertype_idTriggertype == 1) {
                            if ($data[$trigger->idTrigger] == true) {
                                $atrigger['value'] = true;
                            } else {
                                $atrigger['value'] = false;
                            }
                        }else{
                            if (strlen($data[$trigger->idTrigger]) > 0) {
                                $atrigger['value'] = true;
                            } else {
                                $atrigger['value'] = false;
                            }
                        }
                    }
                }
                $triggers[$trigger->Naam] = $atrigger;
            }
            $row['triggers'] = $triggers;
            $rows[] = $row;
        }

        $render['columns'] = ["Nummer","Naam","percentage"];
        $render['columnData']['percentage'] = ['attr' => []];

        $columns = [];
        foreach(Trigger::find() as $trigger){
            $columns[] = $trigger->Naam;
        }
        $render['triggerColumns'] = $columns;
        $render['data'] = $rows;
      //  $render['filters'] = $filters;

        echo json_encode($render, JSON_UNESCAPED_SLASHES);
    }
}