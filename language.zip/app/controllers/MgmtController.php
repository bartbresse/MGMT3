<?php
use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;


class MgmtController extends ControllerBase
{
    public function getAction($entityname)
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        if (isset($request_body['data']['q']) && strlen($request_body['data']['q']) > 2) {
            $q = $request_body['data']['q'];
        } else {
            $q = false;
        }

        if(isset($request_body['data']['isAddTo']) && $request_body['data']['isAddTo'] > 0)
        {
            $idvalues = [];
            $classname = ucfirst($request_body['data']['baseentity']).'Has'.ucfirst($request_body['data']['entityToAdd']);
            if(!class_exists ($classname))
            {
                $classname = ucfirst($request_body['data']['entityToAdd']).'Has'.ucfirst($request_body['data']['baseentity']);
            }

            $rows = $classname::find(ucfirst($request_body['data']['entityToAdd']).'_id'.ucfirst($request_body['data']['entityToAdd'].' = '.$request_body['data']['addToValue']));
            foreach($rows as $row)
            {
                $field = ucfirst($entityname).'_id'.ucfirst($entityname);
                $idvalues[] = $row->$field;
            }
        }else{
            $idvalues = false;
        }

        if(!isset($request_body['data']['filters']))
        {
            $request_body['data']['filters'] = [];
        }

        $sort = false;
        if(isset($request_body['data']['sort']['sortorder'])) {
            if($request_body['data']['sort']['sortorder'] == 'ascending'){
                $request_body['data']['sort']['sortorder'] = 'ASC';
            }else{
                $request_body['data']['sort']['sortorder'] = 'DESC';
            }
            $sort = $request_body['data']['sort']['sortfield'] . ' ' . $request_body['data']['sort']['sortorder'];
        }
        echo json_encode($this->mgmt->getByEntityName($entityname, $q, $idvalues,$sort,$request_body['data']['filters']), JSON_UNESCAPED_SLASHES);
    }

    public function postAction($entity, $id = false)
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        //set owner every save

        $mgmt = $this->mgmt->getEigenaar();
        $request_body['data']['data']['Eigenaar_idEigenaar'] = $mgmt->idEigenaar;

        /*
        if($entity == 'eigenaar')
        {
            $ah = new AccountHandler();
            $request_body['data']['data'] = $ah->prepareNewAccount($request_body['data']['data']);
        } */

        $response = $this->mgmt->storeEntity($entity,$id,$request_body['data']['data']);

        echo json_encode($response, JSON_UNESCAPED_SLASHES);
    }

    public function formAction($entityname, $id = false)
    {
        $data = $this->mgmt->getFormByEntityName($entityname, $id);
        echo json_encode($data->render(), JSON_UNESCAPED_SLASHES);
    }


    public function postauditAction($entity, $id)
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        $log = $this->mgmt->restoreRow($entity,$id,$request_body['data']['id']);
        echo json_encode(['log' => $log], JSON_UNESCAPED_SLASHES);
    }

    public function getauditAction($entity, $id)
    {
        $log = $this->mgmt->listAudit($entity, $id);
        echo json_encode(['log' => $log], JSON_UNESCAPED_SLASHES);
    }

    public function cronAction()
    {
        $this->mgmt->cron();
    }

    public function viewAction($entity, $id = false)
    {
        $tableData = $this->mgmt->getRowByEntityNameAndId($entity, $id);
        $render = [];

        $cc = 0;
        $cc2 = 0;
        $row = [];

        $render['settings'] = ['editurl' => '/#/edit/'.$entity.'/'.$id, 'deleteurl' => 'delete/'.$entity.'/'.$id];

        foreach ($tableData->renderRow() as $index => $field) {
            if($index != 'Path') {
                if ($cc % 6 == 0) {
                    $cc2++;
                }
                if (!isset($row[$cc2])) {
                    $row[$cc2] = [];
                }

                $row[$cc2][$index] = $field;
                $cc++;
            }

            if($entity == 'document' && $index == 'Path')
            {
                $render['settings']['downloaduri'] = $this->globalconfig->domain . $field['value'];
            }
        }

        $render['fields'] = $row;
        $render['actions'] = Action::find('entity = "' . $entity . '"')->toArray();
        $render['rights'] = $this->mgmt->getRights();

        echo json_encode($render, JSON_UNESCAPED_SLASHES);
    }

    public function detailAction($entityname, $entityRowId = false)
    {
        $dataTables = $this->mgmt->getByEntityAndIdName($entityname,$entityRowId);
        echo json_encode($dataTables, JSON_UNESCAPED_SLASHES);
    }

    public function fileAction($token)
    {
        parse_str($token,$url_params);
        $this->mgmt->setSecurityToken($token, false);
        $jsondata = $this->mgmt->uploadFile($url_params['token']);

        echo json_encode($jsondata, JSON_UNESCAPED_SLASHES);
    }

    public function authAction()
    {
        $body = json_decode(file_get_contents('php://input'));
        $secret = '3k?H&Y;(W[39BTqU+<!j!<`m30w|$*';

        $words = ['Dashboard','Financiële gegevens','Dossiers', 'Medewerkers', 'Contracten', 'Onderwerpen', 'Taken', 'Documenten', 'Gegevens', 'Relaties', 'Rapportage'];
        $translations = [];
        foreach ($words as $word) {
            $translations[$word] = $this->mgmt->getTranslation($word);
        }

        $routing = [];
        foreach(Navigation::find() as $item)
        {
            $routing[$item->Name] = ['url' => $item->Url, 'label' => $item->Label];
        }


        if (isset($body->email) && isset($body->password)) {
            $eigenaar = Eigenaar::findFirst("Email = '" . $body->email . "'");

            $passwordCheck = password_verify($body->password, $eigenaar->Password);
            $this->session->set('eigenaar', $eigenaar);
            if ($eigenaar and $passwordCheck) {

                $us = new Usersession();
                $us->Creationtime = date('Y-m-d H:i:s');
                $us->Eigenaar_idEigenaar = $eigenaar->idEigenaar;
                $us->Sessioncode = uniqid();

                if (!$us->save()) {
                    print_r($us->getMessages());
                    die();
                }

                $builder = new TokenBuilder();

                $builder->setSubject('cmt'); // whom the token refers to
                $builder->setAudience('login'); // who or what the token is intended for
                $expiration = time() + (8 * 60 * 60); // + 8 uur
                $issuer = 'Contract management tool'; // who created and signed the token
                $admin = ($eigenaar->rol_idrol = 3) ? true : false; // administrator ?

                $token = $builder->addPayload(['key' => 'name', 'value' => $eigenaar->Voornaam . ' ' . $eigenaar->Achternaam])
                    ->addPayload(['key' => 'admin', 'value' => $admin])
                    ->addPayload(['key' => 'idEigenaar', 'value' => $eigenaar->idEigenaar])
                    ->addPayload(['key' => 'rol', 'value' => $eigenaar->Rol_idRol])
                    ->setSecret($secret)
                    ->setExpiration($expiration)
                    ->setIssuer($issuer)
                    ->build();

                $settings = [];
                foreach(Setting::find() as $setting)
                {
                    $settings[$setting->settingkey] = $setting->toArray();
                }

                echo json_encode(['routing' => $routing, 'auth' => true, 'token' => $token,'settings' => $settings,'appdata' => $this->mgmt->getAppDataUrl()]);
            } else {
                echo json_encode(['auth' => false]);
            }
        } else if (isset($body->token)) {
            $validator = new TokenValidator();

            $token = explode('&',$body->token);
            $token = explode('token=',$token[0]);
            $token = $token[1];

            try {
                $validator->splitToken($token)
                    ->validateExpiration()
                    ->validateSignature($secret);

                $settings = [];
                foreach(Setting::find() as $setting)
                {
                    $settings[$setting->settingkey] = $setting->toArray();
                }

                echo json_encode(['menu' => Structuurtable::find(['conditions' => 'visibleinmenu = 1','order' => 'orderinmenu ASC'])->toArray(), 'routing' => $routing, 'auth' => true, 'payload' => json_decode($validator->getPayload()),'translations' => $translations,'settings' => $settings,'appdata' => $this->mgmt->getAppDataUrl()]);

            } catch (Exception $e) {

                print_r($e->getMessage());

                echo json_encode(['auth' => false]);
            }
        } else {
            echo json_encode(['auth' => false]);
        }
    }

    public function signoutAction()
    {
        $session = Usersession::findFirst();
        $_SESSION = [];
        session_destroy();

        if (isset($_COOKIE['db'])) {
            unset($_COOKIE['db']);
            setcookie('db', null, -1, '/');
            return true;
        }

        if (!$session->delete()) {
            $session->getMessages();
        }

        echo json_encode(['auth' => false]);
    }
}