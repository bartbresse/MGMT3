<?php

class ChartingController extends ControllerBase
{
    public function indexAction()
    {

    }

    private function prepareTaak($taken,$cc)
    {
        $ptaken = [];
        foreach($taken as $taak)
        {
            $einddatum = strtotime($taak->Einddatum);
            if(date('Y',$einddatum) == 2019)
            {
                $day = date('z',$einddatum);
                $left = ($day * (100 / 365));

                $taak->left = $left;
                $taak->Einddatum = date('d-m-Y',$einddatum);
                $taak->Eigenaar_idEigenaar = $taak->Eigenaar->Voornaam.' '.$taak->Eigenaar->Achternaam;
                $taak = $taak->toArray();
                $taak['Eigenaar'] = $taak['Eigenaar_idEigenaar'];
                $taak['left'] = $left;
                $taak['uri'] = '/#/view/taak/'.$taak['idTaak'];
                $ptaken[$cc] = $taak;
            }
            $cc++;
        }
        return $ptaken;
    }

    public function showAction($year = false)
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        if (!$year) {
            $year = date('Y');
        }

        $cc = 0;

        $request_body = json_decode(file_get_contents('php://input'), true);
        if(!isset($request_body['data']['filters']))
        {
            $request_body['data']['filters'] = [];
        }
        $render = $this->mgmt->getByEntityName('contract', '', '',false,$request_body['data']['filters'],'( Begindatum < "'.$year.'-12-31" AND Einddatum > "'.$year.'-01-01" AND Contractstatus_idContractstatus <> 2 )');
        $contracts = [];
        foreach($render['data'] as $row) {

            $tbgd = strtotime($row['Begin']['value']);
            if ($tbgd >= strtotime($year . '-01-01')) {
                $day = date('z', $tbgd);
                $left = ($day * 100 / 365);
            } else if ($tbgd < strtotime($year . '-01-01')) {
                $left = 0;
            }

            $ted = strtotime($row['Einddatum']['value']);

            if ($ted < strtotime($year . '-12-31')) {
                $day = date('z', $ted);
                $right = (100 - ($day * 100 / 365));
            } else if ($ted > strtotime($year . '-12-31')) {
                $right = 0;
            }

         //   $taken = $this->prepareTaak($contract->Taak, $cc);
           // $eigenaar = $contract->Eigenaar->Voornaam . ' ' . $contract->Eigenaar->Achternaam;
            $cc += 10;

            //$contract = $contract->toArray();
            $contract = [];

            $contract['Naam'] = $row['Naam']['value'];
            $contract['Nummer'] = $row['Nummer']['value'];
            $contract['Begin'] = $row['Begin']['value'];
            $contract['Eind'] = $row['Einddatum']['value'];

            $contract['url'] = '/#/view/contract/' . $row['idContract']['value'].'/'. $this->mgmt->getAppDataUrl();
        //    $contract['taken'] = $taken;
            $contract['left'] = round($left, 2);

            $contract['width'] = round(100 - ($left + $right), 1);

            $contract['Einddatum'] = date('d-m-Y', $ted);
            $contract['Eigenaar'] = $row['Eigenaar']['value'];

            $contracts[] = $contract;


        }


/*
        foreach(Contract::find('Begindatum < "'.$year.'-12-31" AND Einddatum > "'.$year.'-01-01" AND Contractstatus_idContractstatus <> 2') as $contract) {

            if(!isset($request_body['data']['soort']) || in_array($contract->idContract,$allowed)) {

                $tbgd = strtotime($contract->Begindatum);
                if ($tbgd >= strtotime($year . '-01-01')) {
                    $day = date('z', $tbgd);
                    $left = ($day * 100 / 365);
                } else if ($tbgd < strtotime($year . '-01-01')) {
                    $left = 0;
                }

                $ted = strtotime($contract->Einddatum);

                if ($ted < strtotime($year . '-12-31')) {
                    $day = date('z', $ted);
                    $right = (100 - ($day * 100 / 365));
                } else if ($ted > strtotime($year . '-12-31')) {
                    $right = 0;
                }

                $taken = $this->prepareTaak($contract->Taak, $cc);
                $eigenaar = $contract->Eigenaar->Voornaam . ' ' . $contract->Eigenaar->Achternaam;
                $cc += 10;

                $contract = $contract->toArray();
                $contract['url'] = '/#/view/contract/' . $contract['idContract'];
                $contract['taken'] = $taken;
                $contract['left'] = round($left, 2);

                $contract['width'] = round(100 - ($left + $right), 1);

                $contract['Einddatum'] = date('d-m-Y', $ted);
                $contract['Eigenaar'] = $eigenaar;

                $contracts[] = $contract;
            }
        }
*/

        if(date('Y') == $year || !$year)
        {
            $today = (date('z') * 100 / 365);
        }else{
            $today = 0;
        }

        echo json_encode(['contracts' => $contracts,'today' => $today,'filters' => $render['filters']], JSON_UNESCAPED_SLASHES);
    }
}