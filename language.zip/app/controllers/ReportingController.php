<?php

class ReportingController extends ControllerBase
{
    public function getAction()
    {
        $rows = $this->mgmt->getByEntityName('reportingtool', '', false,false,false);

        print_r($rows);

        $entity = [];

        echo json_encode($entity, JSON_UNESCAPED_SLASHES);
    }
}