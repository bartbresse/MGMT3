<?php

class RiskassesmentController extends ControllerBase
{
    public function getAction()
    {
        $project = ['project' => 'project','projectmanager' => 'projectmanager','date' => date('d-m-Y'), 'number' => 'NU123','facility' => 'LLF'];
        $types = [];

        foreach(Riskfactortype::find() as $type){
            $riskfactors = [];
            $riskfactors['model'] = $type->toArray();
            foreach($type->Riskfactor as $factor){
                $riskfactors['factors'][] = $factor->toArray();
            }
            $types[] = $riskfactors;
        }
        echo json_encode(['factors' => $types,'project' => $project], JSON_UNESCAPED_SLASHES);
    }
}