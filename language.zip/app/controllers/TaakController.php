<?php

class TaakController extends ControllerBase
{
    public function indexAction()
    {

    }

    public function changestatusAction()
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        $taak = Taak::findFirst('idTaak = "'.$request_body['data']['id'].'"');
        $taak->Taakstatus_idTaakstatus = 3;
        if(!$taak->save())
        {
            print_r($taak->getMessages());
            echo json_encode(['result' => 'failure']);
        }else{
            echo json_encode(['result' => 'succes']);
        }


    }
}