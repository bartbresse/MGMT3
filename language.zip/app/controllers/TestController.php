<?php

use Phalcon\Mvc\Controller;

class TestController extends Controller
{
    public function showAction()
    {
        $settings = [];

        echo json_encode(['subform' => false]);
    }

    public function mgmtutilsAction()
    {
        $this->view->disable();

        $settings = [];

        echo 'UTILS';

        $utils = new MGMTUtils();

        $watcher = $utils->getDatabasewatcher();
        $generator = $utils->getGenerator();


        $watcher->lookForChanges();

        echo json_encode(['settings' => $settings]);
    }

    public function generatorAction($entity)
    {
        $utils = new MGMTUtils();
        $generator = $utils->getGenerator();
        echo $generator->addEntity($entity);

    }

    public function dbupdateAction()
    {
        $database = new DatabaseCli();
        $filehandler = new FileHandler();
        $mysqlqueries = new MySQLQueries();

        $id = '5c73fac4a5afd';
        $results = $database->backupDatabaseTableData();
        foreach ($results as $index => $result) {
            //store table data
            if ($filehandler->storeFile($result, $index . '.sql', $id)) {
                //delete table
                $query = 'SET FOREIGN_KEY_CHECKS=0; DROP TABLE `' . $index . '`; SET FOREIGN_KEY_CHECKS=1;';
                $mysqlqueries->select($query);
            }
        }

        //insert new database structure
        $result = $database->insertDatabaseStructure('');

        /**
         * Database:    sonder_updatetest
         * Host:    localhost
         * Username:    sonder_updatetest
         * Password:    J9LoywP157
         *
         */

        //  $result = $database->insertDatabaseStructure('test.sql');

    }
}