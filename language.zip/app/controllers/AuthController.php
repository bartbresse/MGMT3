<?php

use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class AuthController extends ControllerBase
{
    public function indexAction()
    {
        $body = json_decode(file_get_contents('php://input'));
        $secret = '3k?H&Y;(W[39BTqU+<!j!<`m30w|$*';

        $words = ['Dashboard','Financiële gegevens','Dossiers', 'Medewerkers', 'Contracten', 'Onderwerpen', 'Taken', 'Documenten', 'Gegevens', 'Relaties', 'Rapportage'];
        $translations = [];
        foreach ($words as $word) {
            $translations[$word] = $this->mgmt->getTranslation($word);
        }

        /*
        $routing = [
          //  '' => ['url' => '', 'label' => ''],
            'view' => ['url' => '/view', 'label' => 'Bekijken'],
            'dashboard' => ['url' => '/dashboard', 'label' => $translations['Dashboard']],
            'dossier' => ['url' => '/list/dossier', 'label' => $translations['Dossiers']],
            'medewerker' => ['url' => '/list/medewerker', 'label' => $translations['Medewerkers']],
            'contract' => ['url' => '/list/contract', 'label' => $translations['Contracten']],
            'onderwerp' => ['url' => '/list/onderwerp', 'label' => $translations['Onderwerpen']],
            'taak' => ['url' => '/list/taak', 'label' => $translations['Taken']],
            'document' => ['url' => '/document', 'label' => $translations['Documenten']],
            'gegevens' => ['url' => '/list/gegevens', 'label' => $translations['Financiële gegevens']],
            'relatie' => ['url' => '/list/relatie', 'label' => $translations['Relaties']],
            'rapportage' => ['url' => '/rapportage', 'label' => $translations['Rapportage']],
            'add' => ['url' => '/add', 'label' => 'Toevoegen'],
        ]; */

        $routing = [];
        foreach(Navigation::find() as $item)
        {
            $routing[$item->Name] = ['url' => $item->Url, 'label' => $item->Label];
        }


        if (isset($body->email) && isset($body->password)) {
            $eigenaar = Eigenaar::findFirst("Email = '" . $body->email . "'");

            $passwordCheck = password_verify($body->password, $eigenaar->Password);
            $this->session->set('eigenaar', $eigenaar);
            if ($eigenaar and $passwordCheck) {

                $us = new Usersession();
                $us->Creationtime = date('Y-m-d H:i:s');
                $us->Eigenaar_idEigenaar = $eigenaar->idEigenaar;
                $us->Sessioncode = uniqid();

                if (!$us->save()) {
                    print_r($us->getMessages());
                    die();
                }

                $builder = new TokenBuilder();

                $builder->setSubject('cmt'); // whom the token refers to
                $builder->setAudience('login'); // who or what the token is intended for
                $expiration = time() + (8 * 60 * 60); // + 8 uur
                $issuer = 'Contract management tool'; // who created and signed the token
                $admin = ($eigenaar->rol_idrol = 3) ? true : false; // administrator ?

                $token = $builder->addPayload(['key' => 'name', 'value' => $eigenaar->Voornaam . ' ' . $eigenaar->Achternaam])
                    ->addPayload(['key' => 'admin', 'value' => $admin])
                    ->addPayload(['key' => 'idEigenaar', 'value' => $eigenaar->idEigenaar])
                    ->addPayload(['key' => 'rol', 'value' => $eigenaar->Rol_idRol])
                    ->setSecret($secret)
                    ->setExpiration($expiration)
                    ->setIssuer($issuer)
                    ->build();

                $settings = [];
                foreach(Setting::find() as $setting)
                {
                    $settings[$setting->settingkey] = $setting->toArray();
                }

                echo json_encode(['routing' => $routing, 'auth' => true, 'token' => $token,'settings' => $settings,'appdata' => $this->mgmt->getAppDataUrl()]);
            } else {
                echo json_encode(['auth' => false]);
            }
        } else if (isset($body->token)) {
            $validator = new TokenValidator();

            $token = explode('&',$body->token);
            $token = explode('token=',$token[0]);
            $token = $token[1];

            try {
                $validator->splitToken($token)
                    ->validateExpiration()
                    ->validateSignature($secret);

                $settings = [];
                foreach(Setting::find() as $setting)
                {
                    $settings[$setting->settingkey] = $setting->toArray();
                }

                echo json_encode(['routing' => $routing,'appdata' => $this->mgmt->getAppDataUrl(), 'auth' => true, 'payload' => json_decode($validator->getPayload()),'translations' => $translations,'settings' => $settings]);

            } catch (Exception $e) {

                print_r($e->getMessage());

                echo json_encode(['auth' => false]);
            }
        } else {
            echo json_encode(['auth' => false]);
        }
    }

    public function signoutAction()
    {
        $eigenaar = Eigenaar::findFirst();
        $session = Usersession::findFirst();

        $_SESSION = [];
        session_destroy();

        if (isset($_COOKIE['db'])) {
            unset($_COOKIE['db']);
            setcookie('db', null, -1, '/');
            return true;
        }


        if (!$session->delete()) {
            $session->getMessages();
        }

        echo json_encode(['auth' => false]);
    }

    /*
    public function forgottenAction()
    {
        $body = json_decode(file_get_contents('php://input'));

        $email = $body->email;
        $eigenaar = Eigenaar::findFirst("Email = '" . $body->email . "'");

        if ($eigenaar) {

            $eigenaar->Eigenaarstatus_idEigenaarstatus = 2;
            $eigenaar->Activation = time() + (24 * 60 * 60) . '_' . md5(time() . $eigenaar->Voornaam . $eigenaar->Achternaam);

            if (!$eigenaar->save()) {
                echo 'Error';
                print_r($eigenaar->getMessages());
            }

            $link = $this->globalconfig->domain . '/auth/validate/' . $eigenaar->Activation;
            $template = file_get_contents($this->config->application->emailDir . 'reset.html');

            $to = $eigenaar->Email;
            $subject = 'Vergeten wachtwoord Contact manager';
            $message = $template;

            $headers = 'From: info@2sonder.com' . "\r\n" .
                'Reply-To: info@2sonder.com' . "\r\n" .
                'X-Mailer: PHP/' . phpversion() . "\r\n" .
                'MIME-Version: 1.0' . "\r\n" .
                'Content-Type: text/html; charset=ISO-8859-1' . "\r\n";


            //replace vars
            $message = str_replace('[naam]', $eigenaar->Voornaam . ' ' . $eigenaar->Achternaam, $message);
            $message = str_replace('[link]', $link, $message);


            $result = mail($to, $subject, $message, $headers);

            echo $to . ':' . $subject;

            $promise = $this->sparkpost->transmissions->post([
                'options' => [
                    'sandbox' => false,
                ],
                'content' => [
                    'from' => [
                        'name' => 'Contract manager',
                        'email' => 'info@dev81.2sonder.com',
                    ],
                    'subject' => $subject,
                    'html' => $message,
                    'text' => 'Congratulations, {{name}}!! You just sent your very first mailing!',
                ],
                'substitution_data' => ['name' => 'Contract manager'],
                'recipients' => [
                    [
                        'address' => [
                            'name' => 'Contract manager',
                            'email' => $to,
                        ],
                    ],
                ],
            ]);

            try {
                $response = $promise->wait();
                var_dump($response);
                echo "Request:\n";
                print_r($response->getRequest());
                echo "Response:\n";
                echo $response->getStatusCode() . "\n";
                print_r($response->getBody()) . "\n";
            } catch (\Exception $e) {
                echo "Request:\n";
                print_r($e->getRequest());
                echo "Exception:\n";
                echo $e->getCode() . "\n";
                echo $e->getMessage() . "\n";
            }

            if ($result) {
                echo 'Succes ';
            } else {
                echo 'Error';
            }

        } else {
            echo 'Error';
        }
        die();
    } */

    public function validateAction($code)
    {

        $validateParts = explode('_', $code);
        $timestamp = $validateParts[0];

        $eigenaar = Eigenaar::findFirst("Activation = '" . $code . "'");

        if ($eigenaar) {

            if ($timestamp < time()) {
                $returnArray = [
                    'error' => true,
                    'message' => 'Validatie is verlopen.',
                ];
            } else {

                $eigenaar->Activation = null;
                $eigenaar->Eigenaarstatus_idEigenaarstatus = 1;

                if (!$eigenaar->save()) {

                    print_r($eigenaar->getMessages());
                    $returnArray = [
                        'error' => true,
                        'message' => 'Save mislukt.',
                    ];
                } else {
                    $returnArray = [
                        'error' => false,
                        'message' => 'Uw account is geactiveerd, u wordt automatisch doorgestuurd naar de applicatie.',
                    ];

                    echo '<meta http-equiv="refresh" content="3; url=http://app.contractmanager.eu/#/validate" />';
                }
            }

        } else {
            $returnArray = [
                'error' => true,
                'message' => 'Account is al geactiveerd.',
            ];
        }

        echo json_encode($returnArray);
    }
}