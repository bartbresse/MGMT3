# Contributing to FormSchema ElementUI

Please follow the [FormSchema Core Contributing](https://github.com/formschema/core/blob/master/CONTRIBUTING.md) page.
