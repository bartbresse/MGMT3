import Vue from 'vue'
import Router from 'vue-router'

import View from '@/components/mgmt/View'
import List from '@/components/mgmt/List'
import Add from '@/components/mgmt/Add'
import Edit from '@/components/mgmt/Edit'
import Addto from '@/components/mgmt/Addto'
import Settings from '@/components/mgmt/Settings'
import Setup from '@/components/mgmt/Setup'
import Signout from '@/components/mgmt/Signout'
import Document from '@/components/mgmt/Document'
import Autologin from '@/components/Autologin'
import Help from '@/components/Help'

import Access from '@/components/Access'
import Battleship from '@/components/Battleship'
import Database from '@/components/Database'
import {ClientTable, Event} from 'vue-tables-2'

import Contractstatus from '@/components/Contractstatus'
import Charting from '@/components/Charting'
import Finoverzicht from '@/components/Finoverzicht'


Vue.use(ClientTable, {
    perPage: 50
});
Vue.use(Router)

export default new Router({
    routes: [
        {
            path: '/add/:entity/:appdata',
            name: 'Toevoegen',
            component: Add,
            props: true
        },
        {
            path: '/add/:entity/:entity2/:appdata',
            name: 'Toevoegen',
            component: Add,
            props: true
        },
        {
            path: '/add/:entity/:entity2/:id/:appdata',
            name: 'Toevoegen',
            component: Add,
            props: true
        },
        {
            path: '/addto/:entity/:appdata',
            name: 'Toevoegen aan entiteit',
            component: Addto
        },
        {
            path: '/addto/:entity/:entity2/:entitykey/:id/:appdata',
            name: 'Toevoegen aan entiteit',
            component: Addto
        },
        {
            path: '/list/:entity/:appdata',
            name: 'List',
            component: List
        },
        {
            path: '/view/:entity/:appdata',
            name: 'View',
            component: View
        },
        {
            path: '/view/:entity/:id/:appdata',
            name: 'View',
            component: View
        },
        {
            path: '/edit/:entity/:id/:appdata',
            name: 'Edit',
            component: Edit
        },
        {
            path: '/document/:appdata',
            name: 'Document',
            component: Document
        },
        {
            path: '/setup/:appdata',
            name: 'Setup',
            component: Setup
        },
        {
            path: '/battleship/:appdata',
            name: 'Battleship',
            component: Battleship
        },
        {
            path: '/setup/:entity/:appdata',
            name: 'Setup',
            component: Setup
        },
        {
            path: '/signout/:appdata',
            name: 'Signout',
            component: Signout
        },
        {
            path: '/database/:appdata',
            name: 'Database',
            component: Database
        },
        {
            path: '/autologin/:key',
            name: 'Autologin',
            component: Autologin
        },
        {
            path: '/autologin/:key/:database',
            name: 'Autologin',
            component: Autologin
        },
        {
            path: '/help/:appdata',
            name: 'Help',
            component: Help
        },
        {
            path: '/settings/:appdata',
            name: 'Settings',
            component: Settings
        },
        {
            path: '/charting/:appdata',
            name: 'Charting',
            component: Charting
        },
        {
            path: '/access/:entity/:id/:appdata',
            name: 'Access',
            component: Access
        },
        {
            path: '/charting/:appdata',
            name: 'Charting',
            component: Charting
        },
        {
            path: '/contractstatus/:appdata',
            name: 'Contractstatus',
            component: Contractstatus
        },
        {
            path: '/finoverzicht/:appdata',
            name: 'Finoverzicht',
            component: Finoverzicht
        }
    ]
});



