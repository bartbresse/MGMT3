<template>
    <div id="app">
        <div v-if="componentWithoutLogin == false">
            <!--<div style="position: fixed;z-index:300;height: 100vh;">
                <el-menu :router="true" :default-active="activeItem" class="el-menu-vertical-demo" @open="handleOpen"
                         @close="handleClose" :collapse="isCollapse">
                    <div>
                        <img src="https://assets.contractmanager.eu/beeldmerk.svg" />
                    </div>
                    <el-menu-item index="" v-on:click="toggle()">
                        <i class="el-icon-arrow-right"></i>
                        <span slot="title">Navigatie sluiten</span>
                    </el-menu-item>
                    <el-menu-item index="dashboard" :route="{name:'Charting',params: {appdata: appdata}}">
                        <span slot="title">Dashboard</span>
                    </el-menu-item>
                    <el-menu-item index="battleship" :route="{name:'Battleship',params: {appdata: appdata}}">
                        <span slot="title">Contractgrid</span>
                    </el-menu-item>
                    <el-menu-item index="dossiers" :route="{name:'List',params: {entity: 'contractsoort',appdata: appdata}}">
                        <span slot="title">Contractrubrieken</span>
                    </el-menu-item>
                    <el-menu-item index="contract" :route="{name:'List',params: {entity: 'contract',appdata: appdata}}">
                        <span slot="title">{{ translations['Contracten'] }}</span>
                    </el-menu-item>
                    <el-menu-item index="onderwerp" :route="{name:'List',params: {entity: 'onderwerp',appdata: appdata}}">
                        <span slot="title">{{ translations['Onderwerpen'] }}</span>
                    </el-menu-item>
                  <!--  <el-menu-item index="taak" v-if="settings.Taken.settingvalue == '1'" :route="{name:'List',params: {entity: 'taak'}}">
                        <span slot="title">{{ translations['Taken'] }}</span>
                    </el-menu-item> -->
                 <!--   <el-menu-item index="gegevens" v-if="settings.Gegevens.settingvalue == '1'" :route="{name:'List',params: {entity: 'gegevens'}}">
                        <span slot="title">Financiële gegevens</span>
                    </el-menu-item> --><!--
                    <el-menu-item index="relatie" :route="{name:'List',params: {entity: 'relatie',appdata: appdata}}">
                        <span slot="title">Vendors</span>
                    </el-menu-item>
                    <el-menu-item index="medewerker" :route="{name:'List',params: {entity: 'medewerker',appdata: appdata}}">
                        <span slot="title">Contracteigenaar</span>
                    </el-menu-item>
                    <el-menu-item index="document" v-if="payload.rol < 3" :route="{name:'Document',params: {appdata: appdata}}">
                        <span slot="title">{{ translations['Documenten'] }}</span>
                    </el-menu-item>
                    <el-menu-item index="trigger" v-if="payload.rol < 3" :route="{name:'List',params: {entity: 'trigger', appdata: appdata}}">
                        <span slot="title">Trigger</span>
                    </el-menu-item>
                    <el-menu-item index="locatie" :route="{name:'List',params: {entity: 'adres', appdata: appdata}}">
                        <span slot="title">Adressen</span>
                    </el-menu-item>
                    <el-menu-item index="setup" v-if="payload.rol < 2" :route="{name:'Setup',params: { appdata: appdata}}">
                        <i class="el-icon-document"></i>
                        <span slot="title">Setup</span>
                    </el-menu-item>
                </el-menu>
            </div>-->
            <Notify></Notify>
            <el-container>
                <!--
                <el-header>
                    <el-menu class="el-menu-demo" mode="horizontal">
                        <el-submenu index="112">
                            <template slot="title">{{ payload.name }}</template>
                            <el-menu-item v-if="payload.rol < 2" index="2-1"><a href="https://account.barnworks.nl/users">Gebruiker beheer</a></el-menu-item>
                            <el-menu-item index="2-2"><span @click="open5">Updates</span></el-menu-item>
                            <el-menu-item index="2-3"><router-link to="/settings">Instellingen</router-link></el-menu-item>
                            <el-menu-item index="2-4"><router-link to="/help">Help</router-link></el-menu-item>
                            <el-menu-item index="2-5"><router-link to="/signout">Uitloggen</router-link></el-menu-item>
                        </el-submenu>
                    </el-menu>
                </el-header>-->
                <el-main v-bind:class="{ menuCollapsed: menuCollapsed, signedIn: auth }">
                <!--    <el-breadcrumb separator="/">
                        <el-breadcrumb-item :to="{ path: '/' }">Contractmanager</el-breadcrumb-item>
                        <div v-if="isNumber(pathvar[0])">
                            <el-breadcrumb-item v-if="routingtable[pathvar[1]] && !isNumber(pathvar[1])"
                                                :to="{ path: routingtable[pathvar[1]]['url'] }">{{
                                routingtable[pathvar[1]]['label'] }}
                            </el-breadcrumb-item>
                            <el-breadcrumb-item v-if="routingtable[pathvar[2]] && !isNumber(pathvar[2])">{{ pathvar[0] }}</el-breadcrumb-item>
                        </div>
                        <div v-if="!isNumber(pathvar[0])">
                            <el-breadcrumb-item v-if="routingtable[pathvar[0]] && !isNumber(pathvar[0])"
                                                :to="{ path: routingtable[pathvar[0]]['url'] }">{{
                                routingtable[pathvar[0]]['label'] }}
                            </el-breadcrumb-item>
                            <el-breadcrumb-item v-if="routingtable[pathvar[1]] && !isNumber(pathvar[1])"
                                                :to="{ path: routingtable[pathvar[1]]['url'] }">{{
                                routingtable[pathvar[1]]['label'] }}
                            </el-breadcrumb-item>
                        </div>
                    </el-breadcrumb> -->
                    <br/><br/>
                    <router-view></router-view>
                </el-main>
            </el-container>
        </div>
        <div v-if="componentWithoutLogin == true" style="margin-left: 10vw;">
            <router-view></router-view>
        </div>
        <dashboard></dashboard>
    </div>
</template>
<script>
    import axios from 'axios'
    import Register from './components/tobedeleted/Register'
    import Notify from './components/mgmt/Notify'
    import Dashboard from './components/Dashboard'

    function makeid() {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < 20; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        return text;
    }

    export default {
        name: 'app',
        data() {
            return {
                input5: '',
                search: '',
                auth: false,
                componentWithoutLogin: false,
                showForgot: false,
                showForgotMessage: false,
                showLoginError: false,
                routingtable: [],
                pathvar: '',
                isCollapse: true,
                menuCollapsed: true,
                updates: '',
                appdata:'',
                payload: {},
                translations: [],
                activeItem:'dashboard',
                settings:{Taken:{settingvalue:'0'},Gegevens:{settingvalue:'0'}}
            }
        },
        watch: {
            $route(to, from) {
                var self = this;
                this.pathvar = this.$route.path.replace(/^\/|\/$/g, '').split("/").reverse();
            }
        },
        mounted: function () {
            var self = this;
            self.pathvar = this.$route.path.replace(/^\/|\/$/g, '').split("/").reverse();

            this.getAuth();
            window.addEventListener('resize', this.handleResize);

            if(typeof(this.$route.params.entity) !== "undefined") {
                this.activeItem = this.$route.params.entity;
            }else{
                this.activeItem = 'dashboard';
            }
            this.handleResize();
        },
        beforeDestroy: function () {
            window.removeEventListener('resize', this.handleResize)
        },
        beforeUpdate: function () {
            var self = this;

            var componentName = self.$route.name;
            var componentsWithoutLogin = [
                "Register",
                "Validate",
                "Login",
                "Reset",
                "Autologin"
            ];

            if (componentsWithoutLogin.includes(componentName)) {
                self.componentWithoutLogin = true;
            } else {
                self.componentWithoutLogin = false;
            }

            if(typeof(this.$route.params.entity) !== "undefined") {
                this.activeItem = this.$route.params.entity;
            }else{
                this.activeItem = 'dashboard';
            }
        },
        methods: {
            getAuth: function () {
                var self = this;

                axios.post(process.env.API_URL + 'mgmt/auth/', {
                    data: {token:document.cookie, appdata: this.$route.params.appdata},
                    token: document.cookie
                },{
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(response => {

                    this.auth = response.data.auth;
                    this.payload = response.data.payload;
                    this.translations = response.data.translations;
                    this.settings = response.data.settings;

                    var componentsWithoutLogin = [
                        "/register",
                        "/validate",
                        "/login",
                        "/reset",
                        "/autologin",
                        "/autologin/"
                    ];

                    /*
                    if (this.auth != true && componentsWithoutLogin.indexOf(window.location.pathname) < 0) {
                        if(document.cookie == 'done') {
                            window.location.href = 'https://account.barnworks.nl/';
                        }
                        if(window.location.pathname != '/' && window.location.pathname != '/autologin' && window.location.pathname != '')
                        {
                            window.location.href = 'https://account.barnworks.nl/';
                        }
                    } */

                    this.appdata = response.data.appdata
                    this.username = response.data.email;
                    this.routingtable = response.data.routing;

                }).catch(e => {
                    // this.errors.push(e)
                })
            },
            signOut: function () {
                var self = this
                axios.post(process.env.API_URL + 'auth/signout/', {
                    data: this.model,
                    email: this.username,
                },{
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(response => {
                    this.auth = false;
                    document.cookie = '';
                }).catch(e => {
                    //    this.errors.push(e)
                })
            },
            handleResize: function () {
                if (window.innerWidth > 1200) {
                    this.isCollapse = false;
                    this.menuCollapsed = false;
                } else {
                    this.isCollapse = true;
                    this.menuCollapsed = true;
                }
            },
            showForgotForm: function () {

                var self = this
                this.showForgot = !this.showForgot;
                this.showForgotMessage = false;
            },
            forgot: function () {
                var self = this
                axios.post(process.env.API_URL + 'auth/forgotten/', {
                    data: this.model,
                    email: this.username,
                    mode: 'no-cors'
                }).then(response => {
                    console.log(response);
                    this.showForgotMessage = true;
                    this.auth = false;
                    document.cookie = '';

                }).catch(e => {
                    //  this.errors.push(e)
                })

            },
            isNumber: function (evt) {
                if (typeof(evt) != "undefined") {
                    var charCode = evt.charCodeAt(0)
                    if (((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) || charCode === undefined) {
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    return false;
                }
            },
            handleOpen(key, keyPath) {
                console.log(key, keyPath);

                this.isCollapse;

                //el-menu-vertical-demo el-menu

                // width: 62px; height: 40px; margin-top: 20px;
            },
            handleClose(key, keyPath) {
                console.log(key, keyPath);

                this.isCollapse;
                //el-menu-vertical-demo el-menu--collapse el-menu

                // width: 62px; height: 40px; margin-top: 20px;
            },
            toggle() {

                this.isCollapse = !this.isCollapse;
                this.menuCollapsed = !this.menuCollapsed;

                return false;
            },
            open5() {
                var str = '';
                var self = this
                axios.post(process.env.API_URL + '/update', {
                    data: {},
                    email: this.username,
                    mode: 'no-cors'
                }).then(response => {
                    this.updates = response.data;
                    for(var resdata in this.updates)
                    {
                        str += '<br /><br />';
                        str += '<p>'+this.updates[resdata].date+'</p>';
                        str += '<h3>'+this.updates[resdata].Naam+'</h3>';
                        str += '<div>'+this.updates[resdata].Content+'</div>';
                    }
                    this.$alert(str, 'Updates', {
                        dangerouslyUseHTMLString: true
                    });
                }).catch(e => { });
            },
            notify()
            {

            }
        },
        components: {Register, Dashboard, Notify}
    }
</script>
<style>
    .el-menu-vertical-demo{ overflow-y: scroll;}
    .el-menu-vertical-demo::-webkit-scrollbar { width: 0 !important }
    .el-menu-vertical-demo{ overflow: -moz-scrollbars-none; }
    .el-menu-vertical-demo{ -ms-overflow-style: none; }

    .el-menu-item-group__title {
        padding: 0px 0 0px 20px;
    }

    .el-menu-item-list {
        text-decoration: none;
    }

    .el-input .el-input--mini .el-input--suffix {
        max-width: 300px;
    }

    .el-input--mini .el-input__inner {
        max-width: 300px;
    }

    .el-badge__content.is-fixed {
        top: 16px;
    }

    .el-menu-demo.el-menu--horizontal > .el-menu-item, .el-menu-demo.el-menu--horizontal > .el-submenu {
        float: right;
    }

    .el-header {
        width: 100%;
        position: fixed;
        z-index: 200;
    }

    body {
        margin: 0px;
    }

    .el-menu-vertical-demo {
        height: 100vh;
    }

    .el-breadcrumb {
        position: absolute;
        top: 82px;
        width: 50%;
    }

    #app {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        color: #2c3e50;
        text-align: left;
        width: 100%;
        margin-left: 0px;
    }

    .el-main.menuCollapsed.signedIn {
        margin-left: 75px;
    }

    .el-menu-item a {
        text-decoration: none;
    }

    .el-form-item {
        margin-bottom: 0px;
    }

    .el-menu-vertical-demo:not(.el-menu--collapse) {
        width: 200px;
        min-height: 400px;
    }

    .el-menu-vertical-demo img{
        width: 45px;
        height: 86px;
        margin-left: 72px;
        margin-top: 20px;
    }

    .el-menu--collapse img{
        width: 62px; height: 40px; margin-top: 20px;margin-left: 0px;
    }

    .el-menu--collapse .el-menu .el-submenu, .el-menu--popup, .el-message-box
    {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
    }

    .el-date-editor.el-input, .el-date-editor.el-input__inner, .el-select {
        max-width: 300px;
        width: 100%;
    }
</style>