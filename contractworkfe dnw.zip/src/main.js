// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

import VeeValidate from 'vee-validate';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import locale from 'element-ui/lib/locale/lang/en';
import CKEditor from '@ckeditor/ckeditor5-vue';
import VueMce from 'vue-mce';

import Vuex from 'vuex'
import axios from 'axios'
import VueAxios from 'vue-axios'


Vue.use(VueMce);

Vue.use(CKEditor);

Vue.use(ElementUI, {locale})

Vue.config.productionTip = false

Vue.use(VeeValidate, {fieldsBagName: 'fieldx'});

Vue.use(Vuex)
Vue.use(VueAxios, axios)

new Vue({
    el: '#app',
    router,
    template: '<App/>',
    components: {App},
    store: new Vuex.Store({
        state: {
            notification: 0,
            params: {}
        },
        actions: {
            post({commit}, params) {
                params.data.token = document.cookie
                console.log(this)


                return axios.post(process.env.API_URL + params.url, {
                    data: params.data,
                    dataType: 'json',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                }, {
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                })
            },
            notifyUser({commit}, params){
                this.state.notification++
                this.state.params = params
            }
        },
        mutations: {}
    })
})