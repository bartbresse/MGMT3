<template>
    <div class="el-input el-input--mini">
        <el-input type="postcode" placeholder="1234AA" @change="changeHandler" v-model="property.value" />
    </div>
</template>
<script>
    export default {
        components: {},
        props: ['value'],
        data() {
            return {
                property: this.value,
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);

            }
        },
        mounted: function () {

        },
        methods:{
            changeHandler(e)
            {
                this.$emit('change',{key:this.property.field,value:e});
            }
        }
    }
</script>
<style>
</style>