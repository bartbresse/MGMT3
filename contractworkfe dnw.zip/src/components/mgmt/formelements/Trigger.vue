<template>
    <div id="triggers" v-if="visible">
        <div v-for="(triggerx,index) in data.triggers">
            <div v-if="triggerx.Triggertype_idTriggertype">
                <label>{{ triggerx.triggernaam }}</label>
                <switchf v-if="triggerx.idTriggertype == '1'" v-model="data.triggers[index]" @change="change"></switchf>
                <string v-if="triggerx.idTriggertype == '2'"  v-model="data.triggers[index]" @change="change"></string>
            </div>
        </div>
    </div>
</template>
<script>
    import axios from 'axios'
    import Switchf from "./Switchf";

    function guidGenerator() {
        var S4 = function() {
            return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
        };
        return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
    }

    export default {
        name: 'Trigger',
        components: { Switchf },
        props: ['value','entityid','properties','dossier','saveaction'],
        data() {
            return {
                contractsoortid: 0,
                data:{ triggers: {}},
                property: this.value,
                values:{},
                visible: false
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);
            },
            dossier: {
                immediate: true,
                handler (val, oldVal) {
                    this.get()
                }
            },
            saveaction: {
                immediate: true,
                handler (val, oldVal) {
                    if(val == true)
                    {
                        this.save()
                    }
                }
            }
        },
        mounted: function () {
            this.contractsoortid = this.properties['contract_has_contractsoort'].value
            this.get()
        },
        methods:{
            change(e){
                if(this.value.value.length < 5)
                {
                    this.value.value = guidGenerator();
                }
            },
            get(){
                var self = this
                axios.post(process.env.API_URL + 'trigger/get/'+this.contractsoortid, {
                    data: {'entity': self.value ,'contractsoort': self.dossier, 'token': document.cookie},
                }, {
                    headers: {'Content-Type': 'text/plain;'}
                }).then(response => {
                    self.data.triggers = response.data.triggers
                    self.visible = true
                });
            },
            save(){
                var self = this
                axios.post(process.env.API_URL + 'trigger/save/'+this.contractsoortid, {
                    data: {"data": {'entity': this.value, 'triggers': self.data.triggers, 'contractsoort': self.dossier}, 'token': document.cookie},
                }, {
                    headers: {'Content-Type': 'text/plain;'}
                }).then(response => {

                });
            }
        }
    }
</script>