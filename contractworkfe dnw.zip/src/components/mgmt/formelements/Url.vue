<template>
    <div class="el-input el-input--mini">
        <el-input type="url" @change="changeHandler" v-model="property.value" />
    </div>
</template>
<script>
    export default {
        components: {},
        props: ['value'],
        data() {
            return {
                property: this.value,
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);

            }
        },
        mounted: function () {
            if(this.property.value.length == 0){
                this.property.value = 'https://www';
            }
        },
        methods:{
            changeHandler(e)
            {
                this.$emit('change',{key:this.property.field,value:e});
            }
        }
    }
</script>
<style>
</style>