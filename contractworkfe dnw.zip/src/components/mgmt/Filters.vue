<template>
    <div id="filters">
        <div v-for="filter in filters" class="table-filter">
            <label>{{ filter.name }}:</label><br/>
            <el-select
                    v-model="filter.value"
                    multiple
                    :placeholder="'Select ' + filter.name"
                    @change="filterchange"
                    size="mini">
                <el-option
                        v-for="(item,index) in filter.values"
                        :key="index"
                        :label="item"
                        :value="index">
                </el-option>
            </el-select>
        </div>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Filters',
        components: {},
        props: ['filters'],
        beforeRouteUpdate(to, from, next) {
            next();
            this.getCourses(false);
            var self = this;
        },
        data: function () {
            return {}
        },
        mounted() {
        },
        created() {
        },
        methods: {
            filterchange() {
                this.$emit('change', {});
            },
        }
    }
</script>
<style>
    #filters .el-select {
        max-width: 170px;
    }

    .table-filter {
        float: left;
    }

    .table-filter label {
        float: left;
        font-size: 12px;
    }
</style>