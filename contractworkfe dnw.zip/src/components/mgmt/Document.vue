<template>
    <div>
        <br />
        <div class="searchfield">
            <el-input placeholder="Zoeken" v-on:change="searchnow" v-model="search" class="input-with-select">
                <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
        </div>
        <el-table style="width: 90vw;"
                  :data="data"
                  selected>
            <el-table-column fixed="left" min-width="110" width="110" align="center">
                <template slot-scope="scope">
                    <a v-if="scope.row.downloaduri" :href="scope.row.downloaduri" target="_blank">
                        <el-button type="success" icon="el-icon-download" size="mini" circle></el-button>
                    </a>
                </template>
            </el-table-column>
            <el-table-column :label="columns[0]" fixed
                             :width="columnData[columns[0]].attr.width"
                             :min-width="columnData[columns[0]].attr.minWidth"
                             :prop="columns[0]"
                             sortable>
                <template slot-scope="scope">{{ scope.row[columns[0]].value }}</template>
            </el-table-column>
            <el-table-column v-for="(column,index) in columns" v-if="index > 0"
                             :label="column"
                             :min-width="columnData[column].attr.minWidth"
                             :width="columnData[column].attr.width"
                             :prop="column"
                             sortable>
                <template slot-scope="scope">
                    <a v-if="scope.row[column] && scope.row[column].url" :href="scope.row[column].url">{{ scope.row[column].value }}</a>
                    <span v-if="scope.row[column] && !scope.row[column].url">{{ scope.row[column].value }}</span>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Document',
        components: {},
        data: function () {
            return {
                columns: [],
                columnData: [],
                multipleSelection: [],
                data: [],
                search: '',
                requestingcourse: false,
                checked: true,
                inactief: true
            }
        },
        mounted(){
            this.getCourses();
        },
        methods: {
            searchnow: function () {
                this.getCourses(this.search);
            },
            getCourses: function (q) {
                var self = this;

                var extension = '/document';


                if (typeof(this.$route.params.entity2) !== 'undefined') {
                    var postData = {
                        "q": q,
                        "isAddTo": this.selection,
                        "baseentity": this.$route.params.entity2,
                        "entityToAdd": this.$route.params.entity,
                        "entitykey": this.$route.params.entitykey,
                        "addToValue": this.$route.params.id,
                        "token": document.cookie
                    };
                } else {
                    var postData = {"q": q,"token": document.cookie};
                }
                const url = process.env.API_URL + 'mgmt/get' + extension;
                axios.post(url, {
                    data: postData,
                    dataType: 'json',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    mode: 'no-cors',
                    credentials: 'include'
                }).then(function (response) {
                    self.columns = response.data['columns'];

                    if (document.body.clientWidth < 1465) {
                        var i = 0;
                        var columns = [];
                        for (const value of self.columns) {
                            if (i < 6) {
                                columns.push(value);
                            }
                            i++;
                        }
                        self.columns = columns;
                    }


                    self.columnData = response.data['columnData'];
                    self.sortable = response.data['columns'];
                    self.filterables = response.data['columns'];
                    self.data = response.data['data'];
                }).catch(function (error) {
                    console.log(error)
                })
            }
        }
    }
</script>
<style>

    .input-with-select .el-input-group__append {
        background-color: #fff;
        border: none;
        border-right: 1px solid #dcdfe6;
        border-radius: 0px;
    }

    .el-table .cell, .el-table th div {
        text-overflow: unset;
    }

    .el-table__column-filter-trigger {
        display: none;
    }

    .searchfield {
        position: fixed;
        height: 60px;
        left: 25vw;
        width: 50vw;
        top: 0px;
        z-index: 400;
    }

    .el-input__inner {
        border-radius: 0px !important;
    }

    .searchfield input {
        height: 60px;
        border-bottom: 0px;
        border-top: 0px;
    }

    table {
        position: relative;
        overflow: hidden;
        box-sizing: border-box;
        flex: 1;
        width: 100%;
        max-width: 100%;
        background-color: #fff;
        font-size: 14px;
        color: #606266;
        text-align: left;
        z-index: 0;
    }

    thead {
        color: #909399;
        font-weight: 500;
    }

    td, th {
        border-bottom: 1px solid #ebeef5;
        padding: 12px 0;
    }

    .vue-title {

        margin-bottom: 10px;
    }

    .glyphicon.glyphicon-eye-open {
        width: 16px;
        display: block;
        margin: 0 auto;
    }

    .pagination li {
        display: inline-block;
        margin: 0 3px;
    }

    .el-form {
        max-width: 500px;

    }

    .el-form-item {
        margin-bottom: 0;
    }

    .el-date-editor.el-input, .el-date-editor.el-input__inner, .el-select {
        max-width: 300px;
        width: 100%;
    }
</style>