<template>
    <div>
        <br/>
        <el-button-group v-if="rights.update == 1">
            <router-link v-for="action in actions" :to="action['url']+'/'+ action['entityid'] + '/'+tableroute.id" >
                <el-button v-if="action.url != '/add/document'" type="primary">{{ action['label'] }}</el-button>
            </router-link>
        </el-button-group>
        <taak-afronden v-if="entity == 'taak'" :size="size" :id="tableroute.id"/>
        <div class="detail-container">
            <table class="detail-table" v-for="tables in fields">
                <tr v-for="(item, index) in tables">
                    <td><b>{{ index }}</b></td>
                    <td><p>
                        <a v-if="item.url && typeof item.path === 'undefined'" :href="item.url">{{ item.value }}</a>
                        <a v-if="item.url && typeof item.path !== 'undefined'" target="_blank" :href="item.path">{{ item.value }}</a>
                        <span v-if="!item.url" v-html="item.value"></span>
                    </p></td>
                </tr>
            </table>
            <table class="detail-actiontable">
                <tr>
                    <td>
                        <a v-if="settings.downloaduri" :href="settings.downloaduri" target="_blank">
                            <el-tooltip class="item" effect="dark" content="Bestand downloaden." placement="top-start">
                            <el-button type="success" icon="el-icon-download" size="mini" circle></el-button>
                            </el-tooltip>
                        </a>
                        <a v-if="rights.rol < 3 && rights.nonadmin > 0" :href="'/#/access/'+entity+'/'+ id">
                            <el-tooltip class="item" effect="dark" content="Geef rechten aan gebruikers."
                                        placement="top-start">
                                <el-button type="success" icon="el-icon-plus" size="mini" circle></el-button>
                            </el-tooltip>
                        </a>
                        <a v-if="rights.update == 1 && entity != 'document'" :href="settings.editurl">
                            <el-button type="primary" icon="el-icon-edit" size="mini" circle></el-button>
                        </a>
                        <el-button v-if="rights.delete == 1 && entity != 'document'" type="danger" @click="deleteEntity(settings.deleteurl)"
                                   icon="el-icon-delete" circle></el-button>
                    </td>
                </tr>
            </table>
            <br class="clear"/>
        </div>
        <br/><br/>

        <datamultitable v-if="reload"/>
    </div>
</template>
<script>
    import datamultitable from './Datamultitable'
    import axios from 'axios'
    import TaakAfronden from "../TaakAfronden";
    import Giveaccess from "../tobedeleted/Giveaccess";

    import RowFunctions from '@/components/mgmt/Rowfunctions'

    export default {
        name: 'View',
        components: {TaakAfronden, datamultitable, Giveaccess, RowFunctions},
        beforeRouteUpdate(to, from, next) {
            this.reload = false;

            next();

            this.entity = this.$route.params.entity;
            this.newurl = /add/ + this.$route.params.entity;
            //console.log('updated'+this.$route.params.entity);
            this.tableroute = this.$route.params
            this.getCourses();

            this.id = this.$route.params.id;
            this.entity = this.$route.params.entity;

            this.reload = true;
        },
        mounted() {
            this.rf = new RowFunctions();
            this.entity = this.$route.params.entity;
            this.newurl = /add/ + this.$route.params.entity;

            this.id = this.$route.params.id;
            this.entity = this.$route.params.entity;

            this.getCourses()
        },
        data() {
            return {
                entity: '',
                newurl: '',
                fields: [],
                actions: [],
                settings: [],
                eigenaar: [],
                rights: [],
                reload: true,
                tableroute: this.$route.params,
                size: 'large',
                id: 0
            }
        },
        methods: {
            getCourses: function () {
                var self = this
                var postData = {"token": document.cookie}


                axios.post(process.env.API_URL + 'mgmt/view/' + this.$route.params.entity + '/' + this.$route.params.id, {
                    data: postData,
                    appdata: this.$route.params.appdata
                },{
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(function (response) {
                    self.actions = response.data['actions'];
                    self.fields = response.data['fields'];
                    self.settings = response.data['settings'];
                    self.rights = response.data['rights'];
                }).catch(function (error) {
                    console.log(error)
                });
            },
            deleteEntity: function (url) {
                this.rf.deleteEntity(this,axios,process.env.API_URL + url);
            },
            accessEntity: function (url) {

            }
        }
    }
</script>
<style>
    .clear {
        clear: both;
    }

    .detail-container {
        border: 1px solid #ddd;
        padding: 20px;
    }

    .detail-actiontable {
        position: relative;
        float: right;
        border: none;
        width: inherit;
    }

    .detail-actiontable td {
        padding: 0px 0;
    }

    .detail-table {
        width: inherit;
        padding-right: 60px;
        position: relative;
        float: left;
        border: none;

    }

    .detail-table td {
        border: 0px;
        padding: 6px 0;
    }

    .detail-table p {
        margin: 0px;
        margin-left: 20px;
        padding: 0px;

    }

    table tr td, .detail-table tr td {
        text-align: left;
    }
</style>