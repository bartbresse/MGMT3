<template>
    <div>
        <br /><br />
        <el-row class="tac">
            <el-col :span="6">
                <el-menu default-active="2" class="el-menu-vertical-demo">
                  <!--  <el-menu-item index="1">
                        <router-link to="/setup/contractsoort">
                            <i class="el-icon-document"></i>
                            <span>Contract soorten</span>
                        </router-link>
                    </el-menu-item> -->
                    <el-menu-item index="2">
                        <router-link :to="'/setup/contractstatus/' + appdata">
                            <i class="el-icon-document"></i>
                            <span>Contract status</span>
                        </router-link>
                    </el-menu-item>

                  <!--  <el-menu-item index="3">
                        <router-link to="/setup/eigenaar">
                            <i class="el-icon-document"></i>
                            <span>Eigenaars</span>
                        </router-link>
                    </el-menu-item>-->
                    <!--   <el-menu-item index="4">
                           <router-link to="/setup/eigenaarstatus">
                               <i class="el-icon-document"></i>
                               <span>Eigenaar status</span>
                           </router-link>
                       </el-menu-item> -->
                  <!--     <el-menu-item index="5">
                           <router-link to="/setup/rol">
                               <i class="el-icon-document"></i>
                               <span>Eigenaar rollen</span>
                           </router-link>
                       </el-menu-item> -->
                    <el-menu-item index="6">
                        <router-link :to="'/setup/taakstatus/' + appdata">
                            <i class="el-icon-document"></i>
                            <span>Taak status</span>
                        </router-link>
                    </el-menu-item>
                    <el-menu-item index="7">
                        <router-link :to="'/setup/prioriteit/' + appdata">
                            <i class="el-icon-document"></i>
                            <span>Taak prioriteit</span>
                        </router-link>
                    </el-menu-item>
                   <!-- <el-menu-item index="8">
                        <router-link to="/setup/gegevenstype">
                            <i class="el-icon-document"></i>
                            <span>Financiële types</span>
                        </router-link>
                    </el-menu-item>-->
                    <el-menu-item index="9">
                        <router-link :to="'/setup/documentsoort/' + appdata">
                            <i class="el-icon-document"></i>
                            <span>Document soort</span>
                        </router-link>
                    </el-menu-item>
                    <!--
                    <el-menu-item index="10">
                        <router-link to="/setup/land">
                            <i class="el-icon-document"></i>
                            <span>Landen</span>
                        </router-link>
                    </el-menu-item>
                    <el-menu-item index="11">
                        <router-link to="/setup/valuta">
                            <i class="el-icon-document"></i>
                            <span>Valuta</span>
                        </router-link>
                    </el-menu-item>-->
                </el-menu>
            </el-col>
            <el-col :span="18">
                <div style="float: right;">
                    <router-link :to="{path: newurl}">
                        <el-button size="mini" type="primary">Toevoegen</el-button>
                    </router-link>
                </div>
                <br /><br />
                <div>
                  <datatable2 :selection="false"/>
                </div>
            </el-col>
        </el-row>
    </div>
</template>
<script>
    import datatable2 from '../Datatable2'
    import List from "./List";

    export default {
        name: 'Setup',
        components: {List, datatable2},
        data() {
            return {
                newurl: '/add/' + this.$route.params.entity + '/setup/' + this.$route.params.appdata,
                appdata: this.$route.params.appdata,
                payload:{}
            }
        },
        watch: {
            '$route.params.entity'(newId, oldId) {
                this.newurl = '/add/' + this.$route.params.entity + '/setup/' + this.$route.params.appdata
            }
        }
    }
</script>
<style>
    .el-menu-item a {
        display: block;
    }
</style>