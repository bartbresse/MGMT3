<template>
    <div>
        <div v-for="entity in entities" v-if="entity.data[0]">
            <div>
                <h2>{{ entity['entityname'] }}</h2>
                <div>
                    <el-table ref="multipleTable"
                              style="width: 90vw;"
                              :data="entity.data"
                              @selection-change="handleSelectionChange">
                        <el-table-column sortable :filter-method="filterHandler" :label="entity.columns[0]" sortable
                                         fixed min-width="100">
                            <template slot-scope="scope"><a :href="scope.row.viewuri">{{ scope.row[entity.columns[0]].value }}</a></template>
                        </el-table-column>
                        <el-table-column sortable :filter-method="filterHandler"
                                         v-for="(column,index) in entity.columns" v-if="index > 0" :label="column"
                                         sortable min-width="100">
                            <template slot-scope="scope">
                                <a v-if="scope.row[column] && scope.row[column].url" :href="scope.row[column].url">{{ scope.row[column].value }}</a>
                                <span v-if="scope.row[column] && !scope.row[column].url" v-html="scope.row[column].value"></span>
                            </template>
                        </el-table-column>
                        <el-table-column fixed="right" min-width="50">
                            <template slot-scope="scope">
                                <a v-if="scope.row.downloaduri" :href="scope.row.downloaduri">
                                    <el-button type="success" icon="el-icon-download" size="mini" circle></el-button>
                                </a>
                                <el-button type="danger" @click="deleteEntity(scope.row.deletedetailuri)"
                                           icon="el-icon-delete" circle></el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Datamultitable',
        mounted: function () {
            this.getCourses();
        },
        beforeRouteUpdate(to, from, next) {
            next();
            this.getCourses();

        },
        data: function () {
            return {
                entities: [],
                message: 'Course List Row',
                courses: [],
                multipleSelection: [],
                columns: ['idcontract', 'Nummer', 'Naam'],
                data: [],
                options: {
                    headings: {
                        idcontract: 'id',
                        Nummer: 'Nummer',
                        Naam: 'Naam'
                    },
                    sortable: ['idcontract', 'Nummer', 'Naam'],
                    filterables: ['idcontract', 'Nummer', 'Naam']
                }
            }
        },
        methods: {
            getCourses: function () {
                var self = this;

                const url = process.env.API_URL + 'mgmt/detail/' + this.$route.params.entity + '/' + this.$route.params.id;
                axios.post(url, {
                    data: {"token": document.cookie},
                    appdata: this.$route.params.appdata
                },{
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(function (response) {
                    self.entities = response.data;
                    self.entity = response.data['fields'];
                    self.relations = response.data['relations'];
                }).catch(function (error) {
                    console.log(error)
                })
            },
            deleteEntity: function (url) {
                this.$confirm('Weet u zeker dat u dit item wil verwijderen?', 'Verwijderen', {
                    confirmButtonText: 'Verwijderen',
                    cancelButtonText: 'Cancel',
                    type: 'info'
                }).then(() => {
                    axios.post(process.env.API_URL + url, {
                        data: {id: this.id},
                        token: document.cookie,
                        mode: 'no-cors',
                        headers: {
                            'Accept': 'text/plain',
                            'Content-Type': 'text/plain'
                        }
                    }).then(response => {
                        this.$message({
                            type: 'success',
                            message: 'Item verwijderd'
                        });
                        this.getCourses(false);
                    }).catch(e => {
                        // this.errors.push(e)
                    })

                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: 'Item verwijderen gecanceled'
                    });
                });
            },
            toggleSelection(rows) {
                if (rows) {
                    rows.forEach(row => {
                        this.$refs.multipleTable.toggleRowSelection(row);
                    });
                } else {
                    this.$refs.multipleTable.clearSelection();
                }
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },

            //sorting
            formatter(row, column) {
                return row.address;
            },
            filterTag(value, row) {
                return row.tag === value;
            },
            filterHandler(value, row, column) {
                const property = column['property'];
                return row[property] === value;
            }

        },
        watch: {
            '$route.params.entity'(newId, oldId) {
                this.getCourses();
            }
        },
        components: {}
    }
</script>
<style>
    #app {
        text-align: left;
    }

    input {
        -webkit-appearance: none;
        background-color: #fff;
        background-image: none;
        border-radius: 4px;
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        color: #606266;
        display: inline-block;
        font-size: inherit;
        height: 40px;
        line-height: 40px;
        outline: none;
        padding: 0 15px;
        transition: border-color .2s cubic-bezier(.645, .045, .355, 1);
        width: 300px;
    }

    table {
        position: relative;
        overflow: hidden;
        box-sizing: border-box;
        flex: 1;
        width: 100%;
        max-width: 100%;
        background-color: #fff;
        font-size: 14px;
        color: #606266;
        text-align: center;
    }

    thead {
        color: #909399;
        font-weight: 500;
    }

    td, th {
        border-bottom: 1px solid #ebeef5;
        padding: 12px 0;
    }

    .vue-title {

        margin-bottom: 10px;
    }

    .glyphicon.glyphicon-eye-open {
        width: 16px;
        display: block;
        margin: 0 auto;
    }

    .VueTables__child-row-toggler {
        width: 16px;
        height: 16px;
        line-height: 16px;
        display: block;
        margin: auto;
    }

    .VueTables__child-row-toggler--closed::before {
        content: "+";
    }

    .VueTables__child-row-toggler--open::before {
        content: "-";
    }

</style>