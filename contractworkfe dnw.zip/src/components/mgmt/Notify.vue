<template>
    <div id="error-queue">
        <el-alert v-for="message in messages" v-if="message.show"
                :title="message.title"
                :type="message.type"
                :description="message.message"
                show-icon>
        </el-alert>
    </div>
</template>
<script>
    import axios from 'axios'
    import RowFunctions from '@/components/mgmt/Rowfunctions'
    import Filters from "./Filters";

    export default {
        name: 'List',
        components: {Filters, RowFunctions},
        beforeRouteUpdate(to, from, next) {
            next();

        },
        data: function () {
            return {
                messages: [],
            }
        },
        mounted() {

        },
        created() {
            var self = this
            this.$store.watch(
                function (state) {
                    return state.notification
                },
                function () {
                    var message = {
                        message: '',
                        title: 'information',
                        type: 'info',
                        show: true
                    }
                    message.message = self.$store.state.params.message
                    message.type = self.$store.state.params.type
                    setTimeout(function(){ message.show = false }, 5000);
                    self.messages.push(message)
                },
                {
                    deep: true
                }
            );
        },
        methods: {
            changeFilter () {
            }
        }
    }
</script>
<style>
    #error-queue{
        position: fixed;
        z-index: 500;
        width: 96vw;
        margin: 2vw;
        bottom: 0vh;
    }
</style>