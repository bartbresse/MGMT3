<template>
    <div>
        <el-button v-if="size == 'large'" type="success" @click="open2">Taak afronden</el-button>
        <el-button v-if="size == 'small'" type="success" @click="open2" icon="el-icon-check" circle></el-button>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'TaakAfronden',
        props: ['size', 'id'],
        components: {},
        data() {
            return {}
        },
        methods: {
            open2() {
                this.$confirm('Weet u zeker dat u deze wil taak afronden? ' +
                    '\n Acties op taken worden vastgelegd binnen de audit trail.', 'Taak afronden', {
                    confirmButtonText: 'Afronden',
                    cancelButtonText: 'Cancel',
                    type: 'info'
                }).then(() => {
                    axios.post(process.env.API_URL + 'taak/changestatus', {
                        data: {id: this.id, token: document.cookie},
                    }, {
                        headers: {
                            'Content-Type': 'text/plain;',
                        }
                    }).then(response => {
                        this.$message({
                            type: 'success',
                            message: 'Taak afgerond'
                        });
                    }).catch(e => {
                        // this.errors.push(e)
                    })

                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: 'Taak afronden gecanceled'
                    });
                });
            }
        }
    }
</script>
<style>

</style>