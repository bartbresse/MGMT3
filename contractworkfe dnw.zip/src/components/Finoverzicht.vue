<template>
    <div>
        <Dashboardnav/>
        <div v-if="visible">
            <div>
                <div class="">
                    <Filters :filters="filters" v-on:change="changeFilter"/>
                </div>
            </div>
            <div style="padding-top:23px;">
                <b>&nbsp;&nbsp;Jaarwaarde totaal:</b>
                <span>{{ table.total }}</span>
            </div>
            <div>
                <el-table v-if="data.length > 0" ref="multipleTable"
                          style="width: 90vw; margin-top: 75px;"
                          :data="data"
                          selected>
                    <el-table-column fixed="left" min-width="110" width="110" align="center">
                        <template slot-scope="scope">
                            <a v-if="scope.row.downloaduri" :href="scope.row.downloaduri" target="_blank">
                                <el-button type="success" icon="el-icon-download" size="mini" circle></el-button>
                            </a>
                            <a v-if="scope.row.edituri" :href="scope.row.edituri">
                                <el-button type="primary" icon="el-icon-edit" size="mini" circle></el-button>
                            </a>
                            <el-button v-if="scope.row.deleteuri" type="danger" size="mini"
                                       @click="deleteEntity(scope.row.deleteuri)"
                                       icon="el-icon-delete" circle></el-button>
                        </template>
                    </el-table-column>
                    <el-table-column :label="table['columns'][0]" fixed
                                     :width="table['columnData'][table['columns'][0]].attr.width"
                                     :min-width="table['columnData'][table['columns'][0]].attr.minWidth"
                                     :prop="table['columns'][0]"
                                     sortable>
                        <template slot-scope="scope"><span v-html="scope.row[table['columns'][0]].value"></span>
                        </template>
                    </el-table-column>
                    <el-table-column v-for="(column,index) in table['columns']" v-if="index > 0"
                                     :label="column"
                                     :min-width="table['columnData'][column].attr.minWidth"
                                     :width="table['columnData'][column].attr.width"
                                     :prop="column"
                                     sortable>
                        <template slot-scope="scope">
                            <a v-if="scope.row[column] && scope.row[column].url" :href="scope.row[column].url">{{
                                scope.row[column].value }}</a>
                            <span v-if="scope.row[column] && !scope.row[column].url"><span
                                    v-html="scope.row[column].value"></span></span>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
    </div>
</template>
<script>
    import axios from 'axios'
    import Filters from "./mgmt/Filters";
    import Dashboardnav from '@/components/Dashboardnav'

    export default {
        name: 'Finoverzicht',
        components: {Filters, Dashboardnav},
        props: ['changeview'],
        data: function () {
            return {
                contracts: {},
                filters: [],
                contractsoort: '',
                data: {},
                value: true,
                relaties: [],
                visible: false
            }
        },
        watch: {
            changeview: function (newVal, oldVal) { // watch it
                this.getCourses(this.search)
            }
        },
        mounted() {
            this.getCourses(this.search)
        },
        methods: {
            changeFilter() {
                this.getCourses(this.search);
            },
            getCourses() {
                var self = this;

                axios.post(process.env.API_URL + 'finoverzicht', {
                    data: {token: document.cookie, filters: self.filters}
                }, {
                    headers: {
                        'Content-Type': 'text/plain;'
                    }
                }).then(response => {
                    self.filters = response.data.filters
                    self.relaties = response.data.relaties;

                    self.table = response.data;
                    self.database = response.data.database;
                    self.urlcsv = process.env.API_URL + 'csv/' + self.entity + '?database=' + self.database;

                    self.data = response.data['data'];
                    self.visible = true
                });
            },
            sortchange: function (obj) {
                this.sort = obj
                this.getCourses(this.search)
            },
            onSelectChange() {
            }
        }
    }
</script>
<style>

</style>