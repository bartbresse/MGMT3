<template>
    <div>
        <el-button-group>
            <router-link :to="'/charting/' + appdata">
                <el-button icon="el-icon-date">Contract kalender</el-button>
            </router-link>
            <router-link :to="'/contractstatus/' + appdata">
                <el-button icon="el-icon-finished">Contract status</el-button>
            </router-link>
            <router-link :to="'/finoverzicht/' + appdata">
                <el-button icon="el-icon-money">Financieel overzicht</el-button>
            </router-link>
        </el-button-group>
        <br /><br />
    </div>
</template>
<script>
    export default {
        name: 'Dashboardnav',
        data() {
            return {
                appdata: this.$route.params.appdata
            }
        }
    }
</script>
<style>

    </style>