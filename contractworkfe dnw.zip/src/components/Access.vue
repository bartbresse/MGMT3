<template>
    <div>
        <el-form>
            <table class="access-table">
                <tr>
                    <th></th>
                    <th>create</th>
                    <th>read</th>
                    <th>update</th>
                    <th>delete</th>
                </tr>
                <tr v-for="user in users">
                    <th><input type="hidden" v-model="user.idEigenaar"/>{{ user.name }}</th>
                    <td>
                        <el-checkbox type="checkbox" v-model="user.Create"></el-checkbox>
                    </td>
                    <td>
                        <el-checkbox type="checkbox" v-model="user.Read"></el-checkbox>
                    </td>
                    <td>
                        <el-checkbox type="checkbox" v-model="user.Update"></el-checkbox>
                    </td>
                    <td>
                        <el-checkbox type="checkbox" v-model="user.Delete"></el-checkbox>
                    </td>
                </tr>
            </table>
            <el-button size="small" type="primary" @click="submit">Opslaan</el-button>
        </el-form>
    </div>
</template>
<script>
    import dataform from './tobedeleted/Dataform'
    import axios from 'axios'


    export default {
        name: 'Access',
        data() {
            return {
                users: {}
            }
        },
        mounted() {
            var self = this;
            axios.post(process.env.API_URL + 'access/' + this.$route.params.entity + '/' + this.$route.params.id, {
                data: {token: document.cookie},
            }, {
                headers: {
                    'Content-Type': 'text/plain;',
                }
            }).then(response => {

                self.users = response.data;
            });
        },
        methods: {
            submit(e) {
                var self = this;

                axios.post(process.env.API_URL + '/access/store/' + this.$route.params.entity + '/' + this.$route.params.id, {
                    data: {user: self.users, token: document.cookie}
                }, {
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(response => {
                    this.$router.push({path: '/view/' + this.$route.params.entity + '/' + this.$route.params.id});
                });
            }
        },
        components: {dataform},
    }
</script>
<style>
    .center {
        margin: auto;
        width: 35%;
        padding: 10px;
    }

    .access-table {
        max-width: 400px;
    }

    .access-table th {
        text-align: left;
    }
</style>

