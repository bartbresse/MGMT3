export default class ContractFormLogic {
    testLogic(self, highestnumbertoday) {
        var date = new Date().toISOString().substr(0, 10);

        if(parseInt(highestnumbertoday) < 2)
        {
            highestnumbertoday = '001'
        }
        var clean = date.replace("-", '').replace("-", '') + highestnumbertoday
        self.properties.Nummer.value = clean;

        if (self.properties.Onbepaaldetijd.value == true) {
            self.properties.Einddatum.visible = false;
            self.properties.Contractduur.visible = false;
            self.properties.Laatsteopzegdatum.visible = false;

            self.properties.Einddatum.value = '';
            self.properties.Contractduur.value = '';
            self.properties.Laatsteopzegdatum.value = '';
        }
    }

    ContractduurChange(self) {
        if (self.properties.Begindatum.value.length > 0) {
            var ab = self.properties.Contractduur.value.split(" ");
            const begindatum = new Date(self.properties.Begindatum.value);
            let einddatum = '';
            switch (ab[1]) {
                case 'jaar':
                    einddatum = new Date(begindatum.setFullYear(begindatum.getFullYear() + parseInt(ab[0])))
                    break;
                case 'maand':
                    einddatum = new Date(begindatum.setMonth(begindatum.getMonth() + parseInt(ab[0])))
                    break;
                case 'dag':
                    einddatum = new Date(begindatum.setDate(begindatum.getDate() + parseInt(ab[0])))
                    break;
            }
            self.properties.Einddatum.value = einddatum;
        }
    }

    OpzegtermijnChange(self) {

        var ab = self.properties.Opzegtermijn.value.split(" ");
        const einddatum = new Date(self.properties.Einddatum.value);
        console.log(einddatum);

        let laatsteopzegdatum = '';
        switch (ab[1]) {
            case 'jaar':
                laatsteopzegdatum = new Date(einddatum.setFullYear(einddatum.getFullYear() - parseInt(ab[0])));
                break;
            case 'maand':
                laatsteopzegdatum = new Date(einddatum.setMonth(einddatum.getMonth() - parseInt(ab[0])));
                break;
            case 'dag':
                laatsteopzegdatum = new Date(einddatum.setDate(einddatum.getDate() - parseInt(ab[0])));
                break;
        }
        self.properties.Laatsteopzegdatum.value = laatsteopzegdatum;
    }

    onChange(self, event) {

        switch (event.key) {
            case 'Einddatum':
                if (self.properties.Einddatum.value < self.properties.Begindatum.value) {
                    self.properties.Einddatum.value = '';
                    self.properties.Einddatum.message = 'Selecteer een einddatum NA de begindatum';
                } else {
                    self.properties.Einddatum.message = '';
                }
                break;
            case 'Onbepaaldetijd':
                if (event.value == true) {
                    self.properties.Einddatum.visible = false;
                    self.properties.Contractduur.visible = false;
                    self.properties.Laatsteopzegdatum.visible = false;

                    self.properties.Einddatum.value = '';
                    self.properties.Contractduur.value = '';
                    self.properties.Laatsteopzegdatum.value = '';
                } else {
                    self.properties.Einddatum.visible = true;
                    self.properties.Contractduur.visible = true;
                    self.properties.Laatsteopzegdatum.visible = true;
                }
                break;
            case 'Contractduur':
                this.ContractduurChange(self);
                this.OpzegtermijnChange(self);
                break;
            case 'Opzegtermijn':
                this.ContractduurChange(self);
                this.OpzegtermijnChange(self);
                break;
        }

        console.log(self);
        console.log(event);
    }
}