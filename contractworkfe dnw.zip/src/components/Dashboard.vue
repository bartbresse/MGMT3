<template>
    <div v-if="pathvar == ''">
    </div>
</template>
<script>
    import axios from 'axios'
    import Chart from './Chart'
    import Charting from './Charting'
    import TaakAfronden from "./TaakAfronden";
    import Contractstatus from "./Contractstatus";
    import Finoverzicht from "./Finoverzicht";

    export default {
        name: 'Dashboard',
        data() {
            return {
                value1: '',
                value2: '',
                feed: {},
                charts: {},
                chartspersonal: {},
                pathvar: '',
                isCollapse: true,
                activeName: 'first',
                size: 'small',
                open: false,
                settings: {Taken: {}, Gegevens: {}},
                tabPosition: ''
            }
        },
        watch: {
            $route(to, from) {
                var self = this;
                self.pathvar = this.$route.path.replace(/^\/|\/$/g, '').split("/").reverse();
            }
        },
        beforeRouteUpdate(to, from, next) {
            this.getFeed();
        },
        mounted() {
            this.getFeed();
        },
        methods: {
            handleClick(tab, event) {
                this.tabPosition = tab.label
                this.getFeed();
            },
            getFeed() {
                var self = this;
                self.pathvar = this.$route.path.replace(/^\/|\/$/g, '').split("/").reverse();

                var postargs = {'token': document.cookie};

                axios.post(process.env.API_URL + 'chart', {
                    data: postargs,
                    token: document.cookie,
                    mode: 'no-cors',
                    headers: {
                        'Accept': 'text/plain',
                        'Content-Type': 'text/plain'
                    }
                }, {
                    headers: {
                        'Content-Type': 'text/plain;'
                    }
                }).then(response => {
                    var self = this;
                    self.feed = response.data.feed;
                    self.charts = response.data.charts;
                    self.chartspersonal = response.data.chartspersonal;
                    self.settings = response.data.settings;

                    self.open = true;
                }).catch(e => {
                    this.errors.push(e)
                });
            },
            open2(id) {
                this.$confirm('Weet u zeker dat u deze wil taak afronden?', 'Taak afronden', {
                    confirmButtonText: 'Afronden',
                    cancelButtonText: 'Cancel',
                    type: 'info'
                }).then(() => {
                    var postargs = {'token': document.cookie, id: id};
                    axios.post(process.env.API_URL + 'taak/changestatus', {
                        data: {id: id, token: document.cookie},
                    }, {
                        headers: {
                            'Content-Type': 'text/plain;',
                        }
                    }).then(response => {
                        this.$message({
                            type: 'success',
                            message: 'Taak afgerond'
                        });
                        this.getFeed();
                    }).catch(e => {
                        // this.errors.push(e)
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: 'Taak afronden gecanceled'
                    });
                });
            }

        },
        components: {Contractstatus, TaakAfronden, Finoverzicht, Chart, Charting}


    }
</script>
<style>
    .el-tabs__header {
        margin-left: 25% !important;
        width: 50%;
    }

    #pane-first {
        margin-left: 7%;
        width: 90%;
    }

    #pane-second, #pane-third {
        margin-left: 10%;
        width: 80%;
    }

    .dashboard-stat {
        padding: 12px 10px;
    }

    .chart-container {
        position: relative;
        float: left;
        width: 100%;
    }

    .chart-containerbig {
        position: relative;
        float: left;
        width: 100%;
    }

    .el-button.is-circle {
        padding: 6px !important;
    }

    .el-col {
        font-size: 14px;
    }

    .taken-datum {
        padding: 12px 10px;
        border-bottom: 0.5px solid #ddd;
        font-size: 14px;
    }

    .el-card {
        width: 100%;
    }

    .charts {
        width: 30%;
        margin-right: 3%;
        margin-top: 3%;
        float: left;

    }
</style>