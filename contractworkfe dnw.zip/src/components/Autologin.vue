<template>
    <div style="margin-left: -10vw;">Autologin</div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Autologin',
        data() {
            return {
                token: 0
            }
        },
        created: function () {
            var self = this;
            self.$route.params.entity = 'register';
        },
        mounted() {
            var self = this;
            axios.post(process.env.API_URL+'autoauth/'+this.$route.params.database+'/', {
                key: this.$route.params.key
            },{
                headers: {
                    'Content-Type': 'text/plain;'
                }
            }).then(response => {
                var token = response.data.token;
                if (token.length > 0) {
                    document.cookie = "token="+response.data.token+"&database="+this.$route.params.database;
                   // document.cookie = "database="+this.$route.params.database;
                    window.location.href = '/';
                }
            }).catch(e => {
                this.errors.push(e)
            })
        },
        methods: {   },
        components: {},
    }
</script>
<style>
    .center {
        margin: auto;
        width: 35%;
        padding: 10px;
    }
</style>