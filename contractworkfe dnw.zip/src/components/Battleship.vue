<template>
    <div id="battleship">
        <el-breadcrumb class="table-breadcrumb" separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">Contractmanager</el-breadcrumb-item>
            <el-breadcrumb-item>Contractgrid</el-breadcrumb-item>
        </el-breadcrumb>
        <br />
        <br /><br />
        <br />
        <table class="grid-table" v-if="grid">
            <tr>
                <td>&nbsp;</td>
                <td v-for="cell in grid[15].row">{{ cell.adres.Naam }}</td>
            </tr>
            <tr v-for="rows in grid">
                <td><span v-if="rows.subcategory">&nbsp;&nbsp;&nbsp;&nbsp;</span>{{ rows.contractsoort.Naam }}</td>
                <td v-for="(cell,index2) in rows.row" :style="'background-color: ' + cell.cell.color + ';'" >
                    <div class="viewcontract" v-if="cell.cell.Contract_idContract > 0" :style="'background-color: ' + cell.cell.color + ';'">
                        <a :href="'/#/view/contract/'+cell.cell.contract.idContract+'/'+appdata">{{ cell.cell.contract.Naam }} {{ cell.cell.contract.Nummer }}</a>
                    </div>
                    <div v-if="cell.cell.Contract_idContract < 1">
                        <el-select v-model="cell.cell.Positietype_idPositietype" placeholder="Select" :style="'background-color: ' + cell.cell.color + ';'"
                                   @change="cellChange(cell.cell.Positietype_idPositietype,rows.contractsoort.idContractsoort,cell.adres.idAdres)">
                            <el-option
                                    v-for="item in cell.cell.options"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                            </el-option>
                        </el-select>
                        <div v-if="cell.cell.Positietype_idPositietype == 3">
                            <el-select v-model="cell.cell.Contract_idContract" placeholder="Select"  @change="save()" :style="'background-color: ' + cell.cell.color + ';'">
                                <el-option
                                        v-for="item in cell.cell.contracts"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</template>
<script>
    export default {
        name: 'Battleship',
        data() {
            return {
                grid: false,
                appdata: this.$route.params.appdata
            }
        },
        watch: {
            changeview: function(newVal, oldVal) { // watch it
                this.getData()
            }
        },
        beforeRouteUpdate(to, from, next) {
            this.getData()
        },
        mounted() {
            this.getData()
        },
        methods: {
            getData() {
                var self = this
                this.$store.dispatch('post', {url: 'battleship/getgrid/', data: {}}).then(function (response) {
                    self.grid = response.data.grid
                })
            },
            save() {
                var self = this
                this.$store.dispatch('post', {
                    url: 'battleship/storegrid/',
                    data: {grid: this.grid}
                }).then(function (response) {
                    self.grid = response.data.grid
                })
            },
            cellChange(id, contractsoort, adres) {
                var self = this
                this.$store.dispatch('post', {
                    url: 'battleship/storegrid/',
                    data: {grid: this.grid}
                }).then(function (response) {
                    self.grid = response.data.grid
                })
            }
        },
        components: {}
    }
</script>
<style>
    .viewcontract{
        padding: 12px;
    }

    .grid-table {
        border-spacing: 0px;
        border-collapse: collapse;
    }

    .grid-table .el-input__inner{
        background-color: inherit !important;
    }

    .grid-table .el-input__inner{
        border: none;
    }

    .grid-table tr td {
        border-bottom: 1px solid #ddd;
        border-right: 1px solid #ddd;
        font-size: 14px;
        padding:0px 5px;
        width: auto !important;
        max-width: inherit !important;
    }
</style>