<template>
    <div id="print">
        PRINTEN
    </div>
</template>
<script>
    export default {
        name: 'Print',
        components: {},
        data () {
            return {
                route: this.$route.params
            }
        }
    }
</script>
<style>

</style>