<template>
    <div>

    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Delete',
        data: () => ({
            schema: {},
            model: {},
            formready: false
        }),
        methods: {
            submit(e) {
            }
        },
        mounted() {


            axios.post(process.env.API_URL + 'delete/' + this.$route.params.entity + '/' + this.$route.params.id, {
                data: this.model
            }, {
                headers: {
                    'Content-Type': 'text/plain;',
                }
            }).then(response => {
                if (response.data.error.length > 0) {
                    this.$message({
                        type: 'error',
                        message: response.data.error
                    });
                } else {
                    this.$message({
                        type: 'info',
                        message: response.data.info
                    });
                }

                this.$router.push({path: '/' + this.$route.params.entity});

                //this.$router.push({ path: '/setup/'+this.$route.params.entity});

            }).catch(e => {
                // this.errors.push(e)
            })
        },
        components: {}
    }
</script>
