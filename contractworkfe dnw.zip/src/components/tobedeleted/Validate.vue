<template>
    <div>
        <div class="center">

            <div class="el-form-item">
                <div style="margin-left: 120px;"><h1 center>Uw account is geactiveerd</h1></div>
            </div>

            <el-progress :text-inside="true" :stroke-width="18" :percentage="percentage" status="success"></el-progress>
            <a href="http://app.contractmanager.eu/#/">Klik om door te gaan</a>
        </div>
    </div>
</template>
<script>
    export default {
        name: 'Validate',
        data() {
            return {
                percentage: 0
            }
        },
        created: function () {
            var self = this;
            self.$route.params.entity = 'register';
        },
        mounted() {
            var self = this;
            var timeleft = 5;
           // this.percentage += 0;
            var downloadTimer = setInterval(function(){
                //document.getElementById("progressBar").value = 10 - --timeleft;
                self.percentage = self.percentage + 2;
                if(timeleft <= 0)
                    clearInterval(downloadTimer);

                if(self.percentage > 100){
                    window.location.href = "http://app.contractmanager.eu/#/";
                }
            },100);
        },
    }
</script>
<style>
    .center {
        margin: auto;
        width: 35%;
        padding: 10px;
    }
</style>