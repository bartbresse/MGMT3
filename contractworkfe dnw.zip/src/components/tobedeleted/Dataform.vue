<script>
    import axios from 'axios'
    import Vue from 'vue'
    import money from '../mgmt/formelements/money'
    import period from '../mgmt/formelements/period'
    import Editor from '@tinymce/tinymce-vue';
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

    import ContactFormLogic from '../ContractFormLogic'

    var matched = false;
    var idcc = 0;
    var cc2 = 0;

    function getElement(property, cc, referencefield) {
        var strt = '';


        var required = '';
        if (property.required == true) {
            required = '*';
        }

        switch (property.type) {
            case 'files':
                strt += '<el-form-item label="' + property.title + required + '"><el-upload v-model="document" action="' + process.env.API_URL + 'file/accept/' + document.cookie + '" multiple :file-list="fileList[' + cc + ']" :on-remove="handleFileRemoval" :on-success="onUpload' + cc2 + '"><el-button size="small" type="primary">Click to upload</el-button></el-upload><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                cc2++;
                break;
            case 'file':
                strt += '<el-form-item label="' + property.title + required + '"><el-upload v-model="document" action="' + process.env.API_URL + 'file/accept/' + document.cookie + '" :file-list="fileList[' + cc + ']" :on-remove="handleFileRemoval" :on-success="onUpload' + cc2 + '"><el-button size="small" type="primary">Click to upload</el-button></el-upload><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                cc2++;
                break;
            case 'date':
                strt += '<el-form-item class="' + property.cssclass + '" label="' + property.title + required + '"><el-date-picker size="mini" v-model="fields.field' + cc + '" type="date" value-format="yyyy-MM-dd" placeholder="' + property.placeholder + '"></el-date-picker><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                break;
            case 'string':
                strt += '<el-form-item class="' + property.cssclass + '" label="' + property.title + required + '"><el-input size="mini" placeholder="' + property.placeholder + '" v-model="fields.field' + cc + '"></el-input><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                break;
            case 'password':
                strt += '<el-form-item label="' + property.title + required + '"><el-input type="password" size="mini" placeholder="' + property.placeholder + '" v-model="fields.field' + cc + '"></el-input><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                break;
            case 'switchhide':
                strt += '<el-form-item label="' + property.title + required + '"><el-switch class="" v-on:change="onSwitch"  v-model="fields.field' + cc + '" ></el-switch><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                break;
            case 'switch':
                strt += '<el-form-item label="' + property.title + required + '"><el-switch v-model="fields.field' + cc + '" ></el-switch><span>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                break;
            case 'money':
                strt += '<el-form-item label="' + property.title + required + '">' +
                    '<money v-model="fields.field' + cc + '"><template slot="append">EUR</template></money>' +
                    '<span>{{ errors["' + property.field + '"] }}</span>' +
                    '</el-form-item>';
                break;
            case 'textarea':
                strt += '<el-form-item label="' + property.title + required + '">' +
                    //   '<vue-editor v-model="fields.field' + cc + '"></vue-editor>' +
                    //    '<ckeditor :editor="editor" v-model="fields.field' + cc + '" :config="editorConfig" :upload-adapter="UploadAdapter"></ckeditor>' +
                    '<editor api-key="sbm8epnx93792wlb970imlef78otmkof6euh43kc6glhtmbr" :init="{plugins: \'print preview fullpage powerpaste searchreplace autolink directionality advcode visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists textcolor wordcount tinymcespellchecker a11ychecker imagetools mediaembed  linkchecker contextmenu colorpicker textpattern help\'}" v-model="fields.field' + cc + '"></editor>' +
                    '<span>{{ errors["' + property.field + '"] }}</span>' +
                    '</el-form-item><br /><br />';

                /*
                    '<el-tabs :tab-position="\'html\'">' +
                    '<el-tab-pane label="html" name="html">' +
                    '</el-tab-pane>' +
                    '<el-tab-pane label="raw" name="raw">' +
                    '<el-input size="mini" type="textarea" :autosize="{ minRows: 2, maxRows: 4}" placeholder="' + property.placeholder + '" v-model="fields.field' + cc + '"></el-input>' +
                    '</el-tab-pane>' +
                    '</el-tabs>' +
                  */
                break;
            case 'number':
                strt += '<el-form-item label="' + property.title + required + '"><el-input-number size="small" v-model="fields.field' + cc + '" @change="handleChange" :min="1" :max="10"></el-input-number><span>{{ formerrors["' + property.field + '"] }}</span></el-form-item>';
                break;
            case 'select':
                strt += '<el-form-item class="' + property.cssclass + '" label="' + property.title + required + '" style="max-width: 1000px;">';

                if (typeof referencefield !== 'undefined' && typeof referencefield[0] !== 'undefined') {

                    var refnull = referencefield[0].toLowerCase();
                    var propnull = property.field.toLowerCase();
                } else {
                    var refnull = 'x';
                    var propnull = 'y';
                }


                if (referencefield && refnull == propnull) {
                    matched = true;

                    strt += '<span>';
                    for (var option in property.enum) {
                        if (referencefield && refnull == propnull && referencefield[1] == property.enum[option].value) {
                            idcc = cc;
                            strt += '<el-input value="' + property.enum[option].value + '" placeholder="' + property.enum[option].label + '" :disabled="true"></el-input>';
                        }
                        //   strt += '<el-input value="' + property.enum[option].value + '" placeholder="' + property.enum[option].label + '" v-model="fields.field' + cc + '" :disabled="true"></el-input>';
                    }
                    strt += '</span>';
                }
                else {
                    strt += '<el-select v-on:change="onSelectChange" placeholder="Selecteer een optie" size="mini" v-model="fields.field' + cc + '" value-key="fields.field' + cc + '"  >';

                    for (var option in property.enum) {
                        if (referencefield && refnull == propnull && referencefield[1] == property.enum[option].value) {
                            var selected = ' selected ';
                        } else {
                            var selected = '';
                        }

                        strt += '<el-option ' + selected + ' key="' + property.enum[option].value + '" label="' + property.enum[option].label + '" value="' + property.enum[option].value + '"></el-option>';
                    }

                    strt += '</el-select><span>' +
                        '<router-link v-if="' + property.addinform + ' == 1" to="/add/' + property.field + '">Toevoegen</router-link>{{ formerrors["' + property.field + '"] }}</span><span>' + property.description + '</span></el-form-item>';
                }

                strt += '</el-form-item>';

                break;

            case 'multiselect':
                if (typeof referencefield !== 'undefined' && typeof referencefield[0] !== 'undefined') {
                    var splitref = referencefield[0].toLowerCase().split("_");
                    var splitprop = property.field.toLowerCase().split("_");
                } else {
                    var refnull = 'x';
                    var propnull = 'y';
                }

                if (referencefield && (splitref[0] == splitprop[0] || splitref[0] == splitprop[2])) {
                    matched = true;
                    strt += '<el-form-item class="' + property.cssclass + '" multiple label="' + property.title + required + '">';
                    strt += '<span>';
                    for (var option in property.enum) {
                        if (referencefield && refnull == propnull && referencefield[1] == property.enum[option].value) {
                            idcc = cc;
                            strt += '<el-input value="' + property.enum[option].value + '" placeholder="' + property.enum[option].label + '" v-model="fields.field' + cc + '" :disabled="true"></el-input>';
                        }
                        //   strt += '<el-input value="' + property.enum[option].value + '" placeholder="' + property.enum[option].label + '" v-model="fields.field' + cc + '" :disabled="true"></el-input>';
                    }
                    strt += '<router-link v-if="' + property.addinform + ' == 1" to="/add/' + property.field + '">Toevoegen</router-link></span>';
                    strt += '</el-form-item>';


                } else if (referencefield && (splitref[0] != splitprop[0] && splitref[0] != splitprop[2])) {

                } else if (matched == false) {


                    strt += '<el-form-item class="' + property.cssclass + '" multiple label="' + property.title + required + '">';
                    strt += '<el-select v-on:change="onSelectChange(\'' + property.title + '\')" size="mini" v-model="fields.field' + cc + '" placeholder="Select">';

                    for (var option in property.enum) {
                        strt += '<el-option  key="' + property.enum[option].value + '" label="' + property.enum[option].label + '" value="' + property.enum[option].value + '"></el-option>';
                    }
                    strt += '</el-select><span>' +
                        '<router-link v-if="' + property.addinform + ' == 1" to="/add/' + property.field + '">Toevoegen</router-link>' +
                        '{{ formerrors["' + property.field + '"] }}</span>';
                    strt += '</el-form-item>';
                }
                break;
            case 'period':
                strt += '<el-form-item class="' + property.cssclass + '" label="' + property.title + '">' +
                    '<period v-model="fields.field' + cc + '"></period>' +
                    '<span>{{ formerrors["' + property.field + '"] }}</span>' +
                    '</el-form-item>';

                break;
            default:
                strt += '<el-form-item label="' + property.title + required + '"><el-input placeholder="' + property.placeholder + '" v-model="fields.field' + cc + '"></el-input><span>{{ formerrors["' + property.field + '"] }}</span></el-form-item>';
                break;
        }
        strt += '';
        return strt;
    }

    export default {
        name: 'Dataform',
        data: function () {
            return {
                form: {},
                msg: 'hello',

                editor: ClassicEditor,
                editorData: '<p>Rich-text editor content.</p>',
                editorConfig: {

                    tokenUrl: "http://dev81.2sonder.com/file/ckeditor",
                    uploadUrl: "http://dev81.2sonder.com/file/ckeditor2"
                },

                template: null,
                referencefield: false,
                fileList: [],
                document: [],
                valueset: [],
                files0: [],
                files1: [],
                files2: [],
                files3: [],
                fieldNames: [],
                formerrors: {},
                rfields: [],
                switchherhaald: false,
                schema: {},
                fields: {
                    field1: '',
                    field2: '',
                    field3: '',
                    field4: '',
                    field5: '',
                    field6: '',
                    field7: '',
                    field8: '',
                    field9: '',
                    field10: '',
                    field11: '',
                    field12: '',
                    field13: '',
                    field14: '',
                    field15: '',
                    field16: '',
                    field17: '',
                    field18: '',
                    field19: '',
                }
            }
        },
        render: function (createElement) {
            if (!this.template) {
                return createElement('div', 'Loading...');
            } else {
                return this.template();
            }
        },
        updated: function () {

            //
            if (this.valueset.length > 0) {
                //alert(this.valueset);
                var e = this.valueset;
                var entities = ['contract', 'taak', 'onderwerp'];
                if (entities.indexOf(e.toLowerCase()) > -1) {
                    for (var item in entities) {
                        if (entities[item] != e.toLowerCase()) {
                            var myClasses = document.querySelectorAll('.' + entities[item]),
                                i = 0,
                                l = myClasses.length;
                            for (i; i < l; i++) {
                                myClasses[i].style.display = 'none';
                            }
                        }
                    }
                }
            }

            //CUSTOM LOGIC IMPLEMENT SYSTEM FOR THIS
            if (this.switchherhaald == false) {
                var myClasses = document.querySelectorAll('.herhaald'),
                    i = 0,
                    l = myClasses.length;
                for (i; i < l; i++) {
                    myClasses[i].style.display = 'none';
                }
            }

        },
        beforeRouteUpdate(to, from, next) {
            alert('update');
            next();
        },
        mounted() {

            var cfl = new ContactFormLogic();

            cfl.testLogic();


            this.getForm();
        },
        watch: {
            $route(to, from) {
                this.getForm();
            }
        },
        methods: {
            UploadAdapter() {
                alert('adapter hit');
            },
            getForm() {
                cc2 = 0;

                var self = this;
                setTimeout(function () {

                    if (typeof (self.$route.params.entity2) !== 'undefined') {

                        self.referencefield = [self.$route.params.entity2, self.$route.params.id];
                        var url = self.$route.params.entity;
                    }
                    else if (typeof (self.$route.params.id) !== 'undefined') {
                        var url = self.$route.params.entity + '/' + self.$route.params.id;
                    }
                    else {
                        var url = self.$route.params.entity;
                    }

                    var postData = {"token": document.cookie};
                    axios.post(process.env.API_URL + 'form/' + url, {data: postData}, {
                        headers: {
                            'Content-Type': 'text/plain;',
                        }
                    }).then(response => {

                        var templatestring = '<div><div><el-form ref="formSchema" :model="form" style="max-width: 1000px !important;" label-width="220px">';
                        var schemaobject = {};
                        var cc = 1;
                        var fieldNames = [];

                        self.properties = response.data.properties;

                        //CUSTOM LOGIC FOR GEGEVENS
                        var valueset = '';
                        var cc4 = 0;
                        var cc2 = 0;
                        cc2 = 0;
                        for (var property in response.data.properties) {

                            self.fields['field' + cc] = response.data.properties[property].value;
                            // self.errors[response.data.properties[property].field] = '';

                            fieldNames.push(response.data.properties[property].field);
                            schemaobject[response.data.properties[property]] = '';

                            //if your adding a subentity to an entity
                            if (self.referencefield && self.referencefield[0] == response.data.properties[property].field) {
                                self.fields['field' + cc] = self.referencefield[1];
                            }

                            //set files
                            if (response.data.properties[property].type == 'files') {

                                self.fileList[cc] = response.data.properties[property].filelist;

                            }

                            var hidecolumns = [];
                            //CUSTOM LOGIC FOR GEGEVENS
                            var optional = ['contract', 'taak', 'onderwerp'];
                            if (optional.indexOf(response.data.properties[property].name.toLowerCase()) > -1) {
                                //typeof (self.$route.params.entity2) !== 'undefined
                                if (typeof(response.data.properties[property].value) !== 'undefined') {
                                    valueset = response.data.properties[property].name;
                                } else if (valueset.length > 0) {

                                    hidecolumns.push(valueset.toLowerCase());

                                }
                            }

                            templatestring += getElement(response.data.properties[property], cc, self.referencefield);
                            cc++;
                        }

                        self.entity = response.data.table;
                        self.fieldNames = fieldNames;

                        templatestring += '<el-form-item>' +
                            '<el-button size="small" type="primary" @click="submit">' + response.data.savebuttontext + '</el-button>' +
                            '<el-button size="small" type="" @click="cancel">Cancel</el-button>';
                        templatestring += '</el-form-item>';
                        templatestring += '<el-form-item label=""><p>Verplichte velden bevatten een asterix (*).</p></el-form-item></el-form></div></div>';

                        self.schema = schemaobject;
                        self.template = Vue.compile(templatestring).render;


                        self.valueset = valueset;
                    });
                }, 1000);
            },
            handleFileRemoval(file, fileList) {
            },
            onUpload0(file, fileList) {
             //   alert(file);
                console.log(file);

                this.files0.push(file);
            },
            onUpload1(file, fileList) {
                this.files1.push(file);
            },
            onUpload2(file, fileList) {
                this.files2.push(file);
            },
            onUpload3(file, fileList) {
                this.files3.push(file);
            },
            onSelectChange(e) {
                //contractmanager custom logic
                var entities = ['contract', 'taak', 'onderwerp'];
                if (entities.indexOf(e.toLowerCase()) > -1) {
                    for (var item in entities) {
                        if (entities[item] != e.toLowerCase()) {
                            var myClasses = document.querySelectorAll('.' + entities[item]),
                                i = 0,
                                l = myClasses.length;
                            for (i; i < l; i++) {
                                myClasses[i].style.display = 'none';
                            }
                        }
                    }
                }
            },
            onSwitch(e) {
                //CUSTOM LOGIC IMPLEMENT SOMETHING FOR THIS
                if (e == true) {
                    this.switchherhaald = true;
                    var myClasses = document.querySelectorAll('.herhaald'),
                        i = 0,
                        l = myClasses.length;
                    for (i; i < l; i++) {
                        myClasses[i].style.display = 'inherit';
                    }
                } else {
                    this.switchherhaald = false;
                }
            },
            cancel() {
                var self = this;

                var setupentities = ['contractstatus', 'contractsoort', 'eigenaar', 'eigenaarstatus', 'rol', 'taakstatus', 'prioriteit', 'documentsoort', 'gegevenstype'];

                if (setupentities.indexOf(self.$route.params.entity) != -1) {
                    this.$router.push({path: '/setup/' + this.$route.params.entity});
                }
                else if (typeof (self.$route.params.entity2) !== 'undefined' && self.$route.params.entity2 == 'setup') {
                    this.$router.push({path: '/setup/' + this.$route.params.entity})
                }
                else if (typeof (self.$route.params.entity2) !== 'undefined') {
                    var entityandid = this.$route.params.entity2.toLowerCase().split("_");
                    this.$router.push({path: '/view/' + entityandid[0] + '/' + this.$route.params.id})
                }
                else if (typeof this.$route.params.id != "undefined") {
                    this.$router.push({path: '/list/' + this.$route.params.entity})
                }
                else if (typeof (self.$route.params.entity) !== 'undefined') {
                    this.$router.push({path: '/list/' + this.$route.params.entity});
                }

                if (this.$route.name == 'Register') {
                    this.$router.push({path: '/login'});
                }


            },
            submit(e) {
                var self = this;

                var rfields = {};
                var cc = 0;

                for (var field in this.fields) {
                    if (cc == (idcc - 1)) {
                        rfields[this.fieldNames[cc]] = self.referencefield[1];
                    } else {
                        rfields[this.fieldNames[cc]] = this.fields[field];
                    }
                    cc++;
                }

                var cc3 = 0;
                for (var property in self.properties) {
                    var prop = self.properties[property];

                    if (prop.type == 'files' || prop.type == 'file') {
                        switch (cc3) {
                            case 0:
                                if (prop.type == 'file') {
                                    if (typeof (this.files0[0]) !== 'undefined') {
                                        rfields[prop.field] = this.files0[0]['idDocument'];
                                    }
                                } else {
                                    console.log(this.files0);
                                    rfields[prop.field] = this.files0;
                                }
                                cc3++;
                                break;
                            case 1:
                                if (prop.type == 'file') {
                                    if (typeof (this.files1[0]) !== 'undefined') {
                                        rfields[prop.field] = this.files1[0]['idDocument'];
                                    }
                                } else {
                                    rfields[prop.field] = this.files1;
                                }
                                cc3++;
                                break;
                            case 2:
                                if (prop.type == 'file') {
                                    if (typeof (this.files2[0]) !== 'undefined') {
                                        rfields[prop.field] = this.files2[0]['idDocument'];
                                    }
                                } else {
                                    rfields[prop.field] = this.files2;
                                }
                                cc3++;
                                break;
                            case 3:
                                if (prop.type == 'file') {
                                    if (typeof (this.files3[0]) !== 'undefined') {
                                        rfields[prop.field] = this.files3[0]['idDocument'];
                                    }
                                } else {
                                    rfields[prop.field] = this.files3;
                                }
                                cc3++;
                                break;
                        }

                    }
                }

                self.rfields = rfields;

                this.$refs.formSchema.validate((valid) => {
                    self = this;
                    if (valid) {

                        var urlid = '';
                        var url = '';

                       if (typeof (self.$route.params.entity2) !== 'undefined' && self.$route.params.entity2 == 'setup') {
                            url = 'post/' + this.$route.params.entity;
                            //    urlid = '/' + this.$route.params.id;
                        }
                        else if (typeof (self.$route.params.entity2) !== 'undefined') {
                            // url = 'post/' + this.$route.params.entity + '/' + self.$route.params.entity2;
                            url = 'post/' + this.$route.params.entity;
                            //urlid = '/' + this.$route.params.id;
                        }
                        else if (typeof (this.$route.params.id) != "undefined") {
                            url = 'post/' + this.$route.params.entity;
                            urlid = '/' + this.$route.params.id;
                        }
                        else if (typeof (self.$route.params.entity) !== 'undefined') {
                            url = 'post/' + this.$route.params.entity;
                        }

                        var postData = {"data": this.rfields, "files": this.files, 'token': document.cookie};
                        axios.post(process.env.API_URL + url + urlid, {
                            data: postData,
                        }, {
                            headers: {
                                'Content-Type': 'text/plain;',
                            }
                        }).then(response => {
                            //   console.log(response);
                            //   console.log(response.data.result);
                            if (response.data.result == 'succes') {


                                //contract manager specific
                                var setupentities = ['contractstatus', 'contractsoort', 'eigenaar', 'eigenaarstatus', 'rol', 'taakstatus', 'prioriteit'];
                                if (setupentities.indexOf(self.$route.params.entity) != -1) {
                                    this.$router.push({path: '/setup/' + this.$route.params.entity});
                                }
                                else if (typeof (self.$route.params.entity2) !== 'undefined' && self.$route.params.entity2 == 'setup') {
                                    this.$router.push({path: '/setup/' + this.$route.params.entity})
                                }
                                else if (typeof (self.$route.params.entity2) !== 'undefined') {
                                    var entityandid = this.$route.params.entity2.toLowerCase().split("_");
                                    this.$router.push({path: '/view/' + entityandid[0] + '/' + this.$route.params.id})
                                }
                                else if (typeof this.$route.params.id != "undefined") {
                                    this.$router.push({path: '/list/' + this.$route.params.entity})
                                }
                                else if (typeof (self.$route.params.entity) !== 'undefined') {
                                    this.$router.push({path: '/list/' + this.$route.params.entity});
                                }

                                if (this.$route.name == 'Register') {
                                    this.$router.push({path: '/login'});
                                }


                            } else if (response.data.result == 'failure') {
                                for (var data in response.data.properties) {

                                    //TODO: fix error message handling
                                    this.formerrors[response.data.properties[data].field] = response.data.properties[data].message;
                                }

                                var field = this.fields.field1;
                                this.fields.field1 = ' ';
                                this.fields.field1 = field;
                            }
                        }).catch(e => {
                            //     this.errors.push(e)
                        })
                    } else {
                        this.$refs.formSchema.setErrorMessage('Please fill out the required fields')
                        return false
                    }
                })
            }
        },
        //,VueEditor
        components: {money, period, Editor, ContactFormLogic}
    }


</script>
<style>
    .money {
        max-width: 300px;
    }

    .el-input .el-input--mini .el-input--suffix {
        max-width: 300px;
    }

    .el-input--mini .el-input__inner {
        max-width: 300px;
    }

    .el-form-item__label {
        width: 220px;
    }

    .periode tr td {
        border: none;
        padding: 0px;
    }

    .el-input__inner {
        height: 28px;
    }

    .el-button {
        text-decoration: none;
    }

    .el-form {
        max-width: 1000px;
    }

    .quillWrapper {
        width: 900px;
    }

    .el-form-item {
        margin-bottom: 0px !important;
    }

    .el-form-item__content {
        line-height: 12px;
        font-size: 12px;
    }

    .el-date-editor.el-input,
    .el-date-editor.el-input__inner,
    .el-select {
        max-width: 300px;
        width: 100%;
    }
</style>