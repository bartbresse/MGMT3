<template>
    <div style="margin-left: -10vw;">
        <el-container>
            <el-main>
                <el-row>
                    <el-col :span="6" :offset="9">
                        <div class="el-form-item">
                            <div><h1 center>Inloggen</h1></div>
                        </div>
                        <el-input placeholder="Email" v-model="username"></el-input>
                        <br/><br/>
                        <el-input placeholder="Password" type="password" v-model="password"></el-input>
                        <br/><br/>
                        <el-button type="primary" v-on:click="signIn()">Inloggen</el-button>
                        <br/><br/>
                        <br/>
                        <div>
                            <div style="float: left;">
                                <router-link to="/reset">
                                    <a>Wachtwoord vergeten</a>
                                </router-link>
                            </div>
                            <div style="float: right;">
                                <router-link to="/register">
                                    <a>Register</a>
                                </router-link>
                            </div>
                        </div>
                    </el-col>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Login',
        data() {
            return {
                username: '',
                password: '',
                percentage: 0
            }
        },
        created: function () {
            var self = this;
            self.$route.params.entity = 'register';
        },
        mounted() {
            var self = this;

        },
        methods: {
            getAuth: function () {
                var self = this
                axios.post(process.env.API_URL+'auth/', {
                    data: this.model,
                    token: document.cookie,
                    mode: 'no-cors',
                    headers: {
                        'Accept': 'text/plain',
                        'Content-Type': 'text/plain'
                    }
                }).then(response => {
                    this.auth = response.data.auth;

                    var componentsWithoutLogin = [
                        "/register",
                        "/validate",
                        "/login",
                        "/reset",
                        "/autologin"
                    ];

                    if (this.auth != true && componentsWithoutLogin.indexOf(window.location.pathname) < 0) {
                        this.$router.push({path: '/login'});
                    }

                    this.username = response.data.email;
                    this.routingtable = response.data.routing;

                }).catch(e => {
                    this.errors.push(e)
                })
            },
            signIn: function () {
                var self = this
                axios.post(process.env.API_URL+'auth/', {
                    email: this.username,
                    password: this.password,
                    mode: 'no-cors'
                }).then(response => {
                    var token = response.data.token;
                    if (token.length > 0) {
                        document.cookie = response.data.token;
                        this.getAuth();
                        window.location.href = '/';
                    }
                }).catch(e => {
                    this.errors.push(e)
                })
            },
        },
        components: {},
    }
</script>
<style>
    .center {
        margin: auto;
        width: 35%;
        padding: 10px;
    }
</style>