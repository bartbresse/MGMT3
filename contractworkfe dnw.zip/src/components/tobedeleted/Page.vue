<template>
    <div>
        <br/>

        <br/><br/>

    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Page',
        components: {},
        beforeRouteUpdate(to, from, next) {
            this.reload = false;
            next();
          this.getCourses();
        },
        mounted() {
            this.getCourses()
        },
        data() {
            return {

            }
        },
        methods: {
            getCourses: function () {
                var self = this

                axios.post(process.env.API_URL + 'page/' + this.$route.params.page, {
                    data: {"token": document.cookie},
                    dataType: 'json',
                    headers: {
                        'Accept': 'text/plain',
                        'Content-Type': 'text/plain'
                    },
                    mode: 'no-cors',
                    credentials: 'include'
                }).then(function (response) {

                }).catch(function (error) {
                    console.log(error)
                });
            }
        }
    }
</script>
<style>

</style>