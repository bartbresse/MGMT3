<template>
    <div>

        <div class="searchfield">
            <el-input placeholder="Zoeken" v-on:change="searchnow" v-model="search" class="input-with-select">
                <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
        </div>

        <el-row>
            <el-button v-if="selection" type="primary" @click="postSelection">Toevoegen aan dossier</el-button>
        </el-row>
        <el-table ref="multipleTable"
                  style="width: 90vw;"
                  :data="data"
                  @selection-change="handleSelectionChange"
                  selected>
            <el-table-column v-if="selection"
                             fixed
                             type="selection"
                             width="55">
            </el-table-column>
            <el-table-column :label="table['columns'][0]" fixed
                             :width="table['columnData'][table['columns'][0]].attr.width"
                             :min-width="table['columnData'][table['columns'][0]].attr.minWidth"
                             :prop="table['columns'][0]"
                             sortable>
                <template slot-scope="scope"><a :href="scope.row.viewuri">{{ scope.row[table['columns'][0]].value }}</a>
                </template>
            </el-table-column>
            <el-table-column v-for="(column,index) in table['columns']" v-if="index > 0"
                             :label="column"
                             :min-width="table['columnData'][column].attr.minWidth"
                             :width="table['columnData'][column].attr.width"
                             :prop="column"
                             sortable>
                <template slot-scope="scope">
                    <a v-if="scope.row[column] && scope.row[column].url" :href="scope.row[column].url">{{
                        scope.row[column].value }}</a>
                    <span v-if="scope.row[column] && !scope.row[column].url">{{ scope.row[column].value }}</span>
                </template>
            </el-table-column>
            <el-table-column fixed="right" min-width="110" width="110" align="center">
                <template slot-scope="scope">
                    <a v-if="scope.row.downloaduri" :href="scope.row.downloaduri" target="_blank">
                        <el-button type="success" icon="el-icon-download" size="mini" circle></el-button>
                    </a>
                    <a :href="scope.row.edituri">
                        <el-button type="primary" icon="el-icon-edit" size="mini" circle></el-button>
                    </a>
                    <el-button v-if="scope.row.deleteuri" type="danger" @click="deleteEntity(scope.row.deleteuri)"
                               icon="el-icon-delete" circle></el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Datatable3',
        props: ['selection'],
        beforeRouteUpdate(to, from, next) {
            console.log(to);
            console.log(from);
            console.log(next);
            next();
            this.getCourses(false);
        },
        mounted: function () {
            this.getCourses(false);
        },
        data: function () {
            return {
                columns: [],
                columnData: [],
                multipleSelection: [],
                data: [],
                table:{},
                search: '',
            }
        },
        methods: {
            searchnow: function () {
                this.getCourses(this.search);
            },
            deleteEntity: function (url) {
                this.$confirm('Weet u zeker dat u dit item wil verwijderen?', 'Verwijderen', {
                    confirmButtonText: 'Verwijderen',
                    cancelButtonText: 'Cancel',
                    type: 'info'
                }).then(() => {
                    axios.post(process.env.API_URL + url, {
                        data: {id: this.id},
                        token: document.cookie,
                        mode: 'no-cors',
                        headers: {
                            'Accept': 'text/plain',
                            'Content-Type': 'text/plain'
                        }
                    }).then(response => {
                        if (response.data.error.length > 0) {
                            this.$message({
                                type: 'error',
                                message: response.data.error
                            });
                        } else {
                            this.$message({
                                type: 'success',
                                message: 'Item verwijderd'
                            });
                        }
                        this.getCourses(this.search);
                    }).catch(e => {
                        // this.errors.push(e)
                    })

                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: 'Item verwijderen gecanceled'
                    });
                });
            },
            getCourses: function (q) {
                var self = this;

                if (typeof(this.$route.params.entity) !== 'undefined') {
                    var extension = '/' + this.$route.params.entity;
                }
                else {
                    var extension = this.$route.path;
                }

                if (typeof(this.$route.params.entity2) !== 'undefined') {
                    var postData = {
                        "q": q,
                        "isAddTo": this.selection,
                        "baseentity": this.$route.params.entity2,
                        "entityToAdd": this.$route.params.entity,
                        "entitykey": this.$route.params.entitykey,
                        "addToValue": this.$route.params.id
                    };
                } else {
                    var postData = {"q": q};
                }
                const url = process.env.API_URL + 'get' + extension;
                axios.post(url, {
                    data: postData,
                    dataType: 'json',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                }).then(function (response) {
                    self.table = response.data;
                    if (document.body.clientWidth < 1465) {
                        var i = 0;
                        var columns = [];
                        for (const value of self.columns) {
                            if (i < 6) {
                                columns.push(value);
                            }
                            i++;
                        }
                        self.table['columns'] = columns;
                    }
                    self.data = response.data['data'];
                }).catch(function (error) {
                    console.log(error)
                })
            },
            toggleSelection(rows) {
                if (rows) {
                    rows.forEach(row => {
                        this.$refs.multipleTable.toggleRowSelection(row);
                    });
                } else {
                    this.$refs.multipleTable.clearSelection();
                }
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            postSelection() {
                //Contract aan dossier toevoegen knop actie

                var str = "";
                for (var key in this.$route.params) {
                    if (str != "") {
                        str += "&";
                    }
                    str += key + "=" + encodeURIComponent(this.$route.params[key]);
                }

                axios.post(process.env.API_URL + 'addto?' + str, {
                    data: this.multipleSelection,
                    mode: 'no-cors',
                    headers: {
                        'Accept': 'text/plain',
                        'Content-Type': 'text/plain'
                    }
                }).then(response => {
                    if (response.data.result == 'succes') {
                        this.$message({
                            message: 'Contracten zijn toegevoegd aan het dossier.',
                            type: 'success'
                        });
                        this.$router.push({path: '/view/' + this.$route.params.entity2 + '/' + this.$route.params.id})
                    } else {
                        alert('contract aan dossier toevoegen mislukt');
                    }
                }).catch(e => {
                    //     this.errors.push(e)
                })
            }
        },
        components: {}
    }
</script>
<style>

    .input-with-select .el-input-group__append {
        background-color: #fff;
        border: none;
        border-right: 1px solid #dcdfe6;
        border-radius: 0px;
    }

    .el-table .cell, .el-table th div {
        text-overflow: unset;
    }

    .el-table__column-filter-trigger {
        display: none;
    }

    .searchfield {
        position: fixed;
        height: 60px;
        left: 25vw;
        width: 50vw;
        top: 0px;
        z-index: 400;
    }

    .el-input__inner {
        border-radius: 0px !important;
    }

    .searchfield input {
        height: 60px;
        border-bottom: 0px;
        border-top: 0px;
    }

    table {
        position: relative;
        overflow: hidden;
        box-sizing: border-box;
        flex: 1;
        width: 100%;
        max-width: 100%;
        background-color: #fff;
        font-size: 14px;
        color: #606266;
        text-align: left;
        z-index: 0;
    }

    thead {
        color: #909399;
        font-weight: 500;
    }

    td, th {
        border-bottom: 1px solid #ebeef5;
        padding: 12px 0;
    }

    .vue-title {

        margin-bottom: 10px;
    }

    .glyphicon.glyphicon-eye-open {
        width: 16px;
        display: block;
        margin: 0 auto;
    }

    .pagination li {
        display: inline-block;
        margin: 0 3px;
    }

    .el-form {
        max-width: 500px;

    }

    .el-form-item {
        margin-bottom: 0;
    }

    .el-date-editor.el-input,
    .el-date-editor.el-input__inner,
    .el-select {
        max-width: 300px;
        width: 100%;
    }
</style>