<template>
    <div>
        <div class="center">

            <div class="el-form-item">
                <div style="margin-left: 120px;"><h1 center>Wachtwoord vergeten</h1></div>
            </div>

            <el-input placeholder="Email" v-model="username"></el-input>
            <el-button type="primary" v-on:click="forgot()">Reset wachtwoord</el-button>
            <br/>
            <el-button type="primary" v-on:click="showForgotForm()">Terug naar login</el-button>
            <div v-if="showForgotMessage == true">
                <el-container>
                    <el-main>
                        <el-row>
                            <el-col :span="8">&nbsp;</el-col>
                            <el-col :span="8">
                                Er is een mail gestuurd naar het opgegeven email adres.
                            </el-col>
                            <el-col :span="8">&nbsp;</el-col>
                        </el-row>
                    </el-main>
                </el-container>
            </div>
        </div>
    </div>
</template>
<script>

    export default {
        name: 'Login',
        data() {
            return {
                username: '',
                percentage: 0
            }
        },
        created: function () {
            var self = this;
            self.$route.params.entity = 'register';
        },
        mounted() {
            var self = this;

        },
        methods: {
            showForgotForm: function () {
                var self = this
                this.showForgot = !this.showForgot;
                this.showForgotMessage = false;
            },
            forgot: function () {
                var self = this
                axios.post(process.env.API_URL+'auth/forgotten/', {
                    data: this.model,
                    email: this.username,
                    mode: 'no-cors'
                }).then(response => {
                    console.log(response);

                    this.showForgotMessage = true;
                    this.auth = false;
                    document.cookie = '';

                }).catch(e => {
                    this.errors.push(e)
                })
            },
        },
    }
</script>
<style>
    .center {
        margin: auto;
        width: 35%;
        padding: 10px;
    }
</style>