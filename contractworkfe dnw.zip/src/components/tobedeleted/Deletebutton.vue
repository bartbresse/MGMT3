<template>
<span>
        <el-button v-if="size == 'large'" type="danger" @click="open2">Taak afronden</el-button>
        <el-button v-if="size == 'small'" type="danger" @click="open2" icon="el-icon-delete" circle></el-button>
   </span>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Deletebutton',
        props: ['size', 'url'],
        components: {},
        data() {
            return {
                url: this.url,
            }
        },
        methods: {
            open2() {
                this.$confirm('Weet u zeker dat u dit item wil verwijderen?', 'Verwijderen', {
                    confirmButtonText: 'Verwijderen',
                    cancelButtonText: 'Cancel',
                    type: 'info'
                }).then(() => {
                    axios.post(process.env.API_URL + this.url, {
                        data: {id: this.id},
                        token: document.cookie,
                        mode: 'no-cors',
                        headers: {
                            'Accept': 'text/plain',
                            'Content-Type': 'text/plain'
                        }
                    }).then(response => {
                        this.$message({
                            type: 'success',
                            message: 'Item verwijderd'
                        });
                    }).catch(e => {
                        // this.errors.push(e)
                    })

                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: 'Item verwijderen gecanceled'
                    });
                });
            }
        }
    }
</script>
<style>

</style>