<template>
    <div>

        <!--
        <div class="el-form-item">
            <div style="margin-left: 120px;"><h1 center>Register</h1></div>
        </div>
        <dataform/>
        -->
    </div>
</template>
<script>
    import dataform from './Dataform'

    export default {
        name: 'Access',
        data() {
            return {}
        },
        created: function () {
            var self = this;
//            self.$route.params.entity = 'register';
        },
        methods: {},
        components: {dataform},
    }
</script>
<style>
    .center {
        margin: auto;
        width: 35%;
        padding: 10px;
    }
</style>

