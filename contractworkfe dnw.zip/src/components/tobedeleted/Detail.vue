<template>
    <div>
        <ul id="example-1">
            <li v-for="field in entity">
                {{ field }}
            </li>
        </ul>
        <h2>Relaties</h2>
        <div v-for="relation in relations">
            <h2>{{ relation['name'] }}</h2>
            <div class="source">
                <div class="" style="">
                    <table class="detail-table">
                        <thead>
                            <tr>
                                <th class="" v-for="(value,index) in relation['data'][0]">
                                    <div class="">{{ index }} </div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="" v-for="data in relation['data']">
                                <td class="" v-for="(value,index) in data">
                                    <div class="">{{ value }}</div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import axios from 'axios'


    export default {
        name: 'Detail',
        components: {},
        data() {
            return {
                'entity': [],
                'relations': [],
                'actions': []
            }
        },
        mounted: function () {
            this.getCourses()
        },
        methods: {
            getCourses: function () {

                var self = this
                const url = process.env.API_URL+'detail/contract/' + this.$route.params.id;
                axios.get(url, {
                    dataType: 'json',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    mode: 'no-cors',
                    credentials: 'include'
                }).then(function (response) {

                    alert(response.data);

                    self.entity = response.data['fields'];
                    self.relations = response.data['relations'];


                }).catch(function (error) {
                    console.log(error)
                })
            }
        },
    }
</script>
