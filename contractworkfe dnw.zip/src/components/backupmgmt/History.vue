<template>
    <div>
        <table class="el-table__header">
            <tr v-for="audit in data.log" class="el-table__row">
                <td>{{ audit.Action }}</td>
                <td>{{ audit.Eigenaar }}</td>
                <td>{{ audit.Lastedit }}</td>
                <td v-html="audit.changefields"></td>
                <td><el-button v-if="audit.Action != 'add'" @click="setBack(audit.id)" type="success" icon="el-icon-caret-left" circle></el-button></td>
            </tr>
        </table>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'History',
        props: ['entity'],
        components: {},
        data() {
            return {
                data:{log:{}}
            }
        },
        mounted(){
            var self = this;
            var url = '' + this.entity.entity + '/' + this.entity.id;

            axios.post(process.env.API_URL + 'mgmt/getaudit/' + url, {data: {"token": document.cookie}}, {
                headers: {
                    'Content-Type': 'text/plain;',
                }
            }).then(response => {
                self.data = response.data;
            });
        },
        methods:{
            setBack(id){
                var self = this;
                axios.post(process.env.API_URL + 'mgmt/postaudit/' + this.entity.entity + '/' + this.entity.id, {data: {"token": document.cookie,"id":id}}, {
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(response => {
                    self.data = response.data;
                });
            }
        }
    }
</script>