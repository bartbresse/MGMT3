<template>
    <div>
        <el-upload v-model="property.value" :action="apiurl + 'mgmt/file/' + cookie" :file-list="fileList" :on-remove="handleFileRemoval" :on-success="onUpload">
            <el-button size="small" type="primary">Uploaden</el-button>
        </el-upload>
    </div>
</template>
<script>
    export default {
        name: 'File',
        components: { },
        props: ['value'],
        data () {
            return {
                property: this.value,
                apiurl: process.env.API_URL,
                cookie: document.cookie,
                fileList:[]
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);
            }

        },
        mounted: function () {

        },
        methods: {
            handleFileRemoval() {
            },
            onUpload() {
            },
        }
    }
</script>