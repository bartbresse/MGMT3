<template>
    <div>
        <el-date-picker size="mini" v-model="property.value" type="date" value-format="yyyy-MM-dd" @change="changeHandler" :placeholder="property.placeholder"></el-date-picker>
    </div>
</template>
<script>
    export default {
        name: 'Date',
        components: { },
        props: ['value'],
        data () {
            return {
                property: this.value,
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);
            }
        },
        methods:{
            changeHandler(e)
            {
                this.$emit('change',{key:this.property.field,value:e});
            }
        }
    }
</script>