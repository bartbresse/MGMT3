<template>
    <div>

    </div>
</template>
<script>
    export default {
        name: 'Signout',
    //    components: {datatable},
        mounted: function () {
            document.cookie = document.cookie + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
            document.cookie = 'done';
            window.location.href='/';
        },
        data () {
            return {

            }
        }
    }
</script>