<template>
    <div>


        <el-form ref="formSchema" style="max-width: 1000px !important;" label-width="0px">
            <el-form-item v-for="(property,index) in data.properties" v-if="property.visible" :id="property.field"
                          :class="property.cssclass">
                <label>{{ property.title }}<span v-if="property.required">*</span></label>


                <string v-if="property.type == 'string'"  v-on:change="changeProperty"  v-model="data.properties[index]"></string>
                <date v-if="property.type == 'date'" v-on:change="changeProperty" v-model="data.properties[index]"></date>
                <selecty v-if="property.type == 'select' || property.type == 'multiselect'" v-on:change="changeProperty" v-model="data.properties[index]"></selecty>
                <switchf v-if="property.type == 'switch'" v-model="data.properties[index]" v-on:change="changeProperty"></switchf>
                <period v-if="property.type == 'period'" v-model="data.properties[index]" v-on:change="changeProperty"></period>


                <file v-if="property.type == 'files' || property.type == 'file'" v-model="data.properties[index]" :files="fileList"></file>

                <money v-if="property.type == 'money'" v-model="data.properties[index]">
                    <template slot="append">EUR</template>
                </money>

                <el-input v-if="property.type == 'password'" type="password" size="mini"
                          :placeholder="data.properties[index].placeholder"
                          v-model="data.properties[index].value"></el-input>

                <el-input v-if="property.type == 'textarea'" size="mini" type="textarea"
                          v-model="data.properties[index].value"></el-input>


                <span>{{ property.description }} {{ property.message }}</span>
            </el-form-item>
            <br />
            <el-form-item>
                <el-button size="small" type="primary" @click="submit">Opslaan</el-button>
                <el-button size="small" @click="cancel">Cancel</el-button>
            </el-form-item>
            <el-form-item label="">
                <p>Verplichte velden bevatten een asterix (*).</p>
            </el-form-item>
        </el-form>
    </div>
</template>
<script>
    import axios from 'axios'

    import String from './formelements/String'
    import Date from './formelements/Date'
    import Selecty from './formelements/Selecty'
    import File from "./formelements/File";
    import Switchf from "./formelements/Switchf";

    import money from './formelements/money'
    import period from './formelements/period'

    import ContactFormLogic from '../ContractFormLogic'

    export default {
        name: 'Dataformy',
        model: {
            prop: 'checked',
            event: 'onsuccess'
        },
        components: {File, String, Date, Selecty, money, period, Switchf},
        props: ['entity'],

        data: function () {
            return {
                data: [],
                fileList: [],
                paths: {url: '', redirect: ''},
                loading:false,
                checked:this.checked,
                cfl:{}
            }
        },
        mounted() {
            this.cfl = new ContactFormLogic();
            this.setPaths();
            this.getForm();
        },
        watch: {
            $route(to, from) {
                alert('watch');
                this.getForm();
            }
        },
        methods: {
            changeProperty(field){
                this.cfl.onChange(this.data,field);
            },
            submit() {
                var self = this;
                self.loading = true;
                for (var property in this.data.properties) {
                    if (this.data.properties[property].value == -1) {
                        console.log(this.data.properties[property]);
                    }
                }

                axios.post(process.env.API_URL + self.paths.url, {
                    data: {"data": self.data.properties, 'token': document.cookie},
                }, {
                    headers: {'Content-Type': 'text/plain;'}
                }).then(response => {
                    if (response.data.result == 'succes') {
                        this.$emit('onsuccess',{ id:response.data.id, fieldname:response.data.fieldname });
                    } else if (response.data.result == 'failure') {
                        for (var data in response.data.properties) {
                            //TODO: fix error message handling
                            self.data.properties[response.data.properties[data].field].message =  response.data.properties[data].message;
                        }
                    }
                    self.loading = false;
                }).catch(e => {
                    //     this.errors.push(e)
                });
            },
            setPaths() {
                var self = this;
                var redirect = '/list/' + this.entity.entity;
                if (typeof (self.entity.entity) !== 'undefined' && this.entity.entity2 == 'setup') {
                    var url = 'mgmt/post/' + this.entity.entity;
                    redirect = '/setup/' + this.entity.entity;
                }
                else if (typeof (self.entity.entity2) !== 'undefined' || typeof (this.entity.entity) !== 'undefined') {
                    var url = 'mgmt/post/' + this.entity.entity;
                }
                else if (typeof (self.entity.id) != "undefined") {
                    var url = 'mgmt/post/' + this.entity.entity + '/' + this.entity.id;
                }

                if (this.$route.name == 'Register') {
                    redirect = '/login';
                }
                self.paths.url = url;
                self.paths.redirect = redirect;
            },
            getForm() {
                this.setPaths();

                var self = this;
                if (typeof (this.entity.id) !== 'undefined') {
                    var url = this.entity.entity + '/' + this.entity.id;
                }
                else {
                    var url = this.entity.entity;
                }

                var postData = {"token": document.cookie};
                axios.post(process.env.API_URL + 'mgmt/form/' + url, {data: postData}, {
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(response => {
                    console.log(response.data.properties);

                    self.data = response.data;

                    this.cfl.testLogic(this.data);
                });
            },
            cancel() {
                this.$emit('oncancel');
            }
        }
    }
</script>
<style>
    .el-form-item__content {
        line-height: 12px;
        position: relative;
        font-size: 12px;
    }
</style>