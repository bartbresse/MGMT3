<template>
    <div>
        <el-form ref="formSchema" style="max-width: 1000px !important;" label-width="0px">
            <el-form-item v-for="setting in settings">
                <label>{{ setting.settingkey }}</label>
                <el-switch v-model="setting.settingvalue"></el-switch>
                <span>{{ setting.Description }}</span>
            </el-form-item>
            <el-form-item>
                <el-button size="small" type="primary" @click="submit">Opslaan</el-button>
                <el-button size="small" @click="cancel">Terug</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>
<script>
    import axios from 'axios'

    export default {
        name: 'Settings',
        mounted: function () {
            var self = this;
            axios.post(process.env.API_URL + '/settings/form', {
                data: {'token': document.cookie},
            }, {
                headers: {'Content-Type': 'text/plain;'}
            }).then(response => {
                self.settings = response.data;
            }).catch(e => {
                //     this.errors.push(e)
            });
        },
        data: function () {
            return {
                settings:[]
            }
        },
        methods: {
            submit() {
                var self = this;
                axios.post(process.env.API_URL + '/settings/store', {
                    data: {'data':self.settings ,'token': document.cookie},
                }, {
                    headers: {'Content-Type': 'text/plain;'}
                }).then(response => {
                   // self.settings = response.data;
                }).catch(e => {
                    //     this.errors.push(e)
                });
            },
            cancel() {

            }
        }
    }
</script>