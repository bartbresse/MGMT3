export default class RowFunctions {
    testLogic(self) {

    }

    deleteEntity(self,axios,baseurl)
    {
        self.$confirm('Weet u zeker dat u dit item wil verwijderen?', 'Verwijderen', {
            confirmButtonText: 'Verwijderen',
            cancelButtonText: 'Cancel',
            type: 'info'
        }).then(() => {
            axios.post(baseurl, {
                data: {id: this.id,token: document.cookie},
            }, {
                headers: {
                    'Content-Type': 'text/plain;',
                }
            }).then(response => {
                self.getCourses(self.search);
                if (response.data.error.length > 0) {
                    self.$message({
                        type: 'error',
                        message: response.data.error
                    });
                } else {

                    self.$message({
                        type: 'success',
                        message: 'Item verwijderd'
                    });
                    self.$router.push({path: '/list/' + self.$route.params.entity});
                }
            }).catch(e => {  // this.errors.push(e)
            });
        }).catch(() => {
            self.$message({
                type: 'info',
                message: 'Item verwijderen gecanceled'
            });
        });
    }
}