<template>
    <div>
        <Dashboardnav />

        <div>
            <el-button-group class="year-selection">
                <el-button v-on:click="previous"><</el-button>
                <el-button>{{ year }}</el-button>
                <el-button v-on:click="next"> ></el-button>
            </el-button-group>


            <!--
            <el-select v-on:change="onSelectChange" size="mini" v-model="contractsoort">
                <el-option v-for="(option,index) in filters" :key="index" :label="option"
                           :value="index"></el-option>
            </el-select> -->

            <Filters :filters="filters" v-on:change="changeFilter"  />
        </div>
        <table>
            <tr>
                <th v-for="month in xmonths">{{ month }}</th>
            </tr>
        </table>
        <div class="contracts">
            <div class="contract-spacer"></div>
            <div v-for="contract in contracts">
                <div class="line-contract tooltip2" v-bind:style="{ width: contract.width + '%', left: contract.left + '%' }">
                    <span class="tooltiptext2">
                        <a :href="contract.url">
                         <table>
                                <tr><td>Naam</td><td>{{ contract.Naam }}</td></tr>
                                <tr><td>Nummer</td><td>{{ contract.Nummer }}</td></tr>
                                <tr><td>Begin</td><td>{{ contract.Begin }}</td></tr>
                                <tr><td>Eind</td><td>{{ contract.Eind }}</td></tr>
                            </table>
                            </a>
                    </span>
                    <div class="leftbar">&nbsp;</div>
                    <a class="text" :href="contract.url"><span v-if="contract.width > 8">{{ contract.Nummer }}</span>
                        <span v-if="contract.width > 14">{{ contract.Naam }}</span> {{
                        contract.Contractstatus }}</a>

                    <div v-if="contract.width > 6" class="line-taak" v-for="(taak,index) in contract.taken">
                        <div class="line-taak-popover tooltip" v-bind:style="{ left: taak.left + '%' }">
                            <a :href="taak.uri">
                                <span class="tooltiptext">
                            <table>
                                <tr><td>Naam</td><td>{{ taak.Naam }}</td></tr>
                                <tr><td>Beschrijving</td><td>{{ taak.Beschrijving }}</td></tr>
                                <tr><td>Deadline</td><td>{{ taak.Einddatum }}</td></tr>
                                <tr><td>Eigenaar</td><td>{{ taak.Eigenaar }}</td></tr>
                            </table>
                        </span>
                            </a>
                        </div>
                    </div>
                    <div v-if="contract.width > 6" class="rightbar">&nbsp;</div>
                </div>
            </div>

            <div id="current-date" v-if="today != 0" v-bind:style="{ left: today + '%' }">
            </div>
        </div>
    </div>
</template>
<script>
    import axios from 'axios'
    import Filters from "./mgmt/Filters";
    import Dashboardnav from '@/components/Dashboardnav'

    export default {
        name: 'Charting',
        components: {Filters, Dashboardnav},
        props:['changeview'],
        data: function () {
            return {
                contracts: {},
                xmonths: [],
                value: '',
                options: [],
                year: 2019,
                today: 0,
                contractsoort: '',
                filters: []
            }
        },
        mounted() {
            var self = this;

            self.xmonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];

            let axiosConfig = {
                headers: {
                    'Content-Type': 'text/plain;'
                }
            };

            axios.post(process.env.API_URL + 'charting/', {
                data: {token: document.cookie, filters: this.filters}
            }, axiosConfig).then(response => {
                self.contracts = response.data.contracts;
                self.today = response.data.today;
                self.filters = response.data.filters;
            });
        },
        methods: {
            changeFilter () {
                var self = this;
                this.$store.dispatch('post',{url: 'charting/' + this.year,data:{filters: this.filters}}).then(response => {
                    self.contracts = response.data.contracts;
                    self.today = response.data.today;
                    self.filters = response.data.filters;
                });
            },
            onSelectChange() {
                var self = this;
                this.$store.dispatch('post',{url: 'charting/' + this.year,data:{filters: this.filters}}).then(response => {
                    self.contracts = response.data.contracts;
                    self.today = response.data.today;
                    self.filters = response.data.filters;
                });
            },
            previous() {
                var self = this;
                self.year--;
                this.$store.dispatch('post',{url: 'charting/' + this.year,data:{filters: this.filters}}).then(response => {
                    self.contracts = response.data.contracts;
                    self.today = response.data.today;
                    self.filters = response.data.filters;
                });
            },
            next() {
                var self = this;
                self.year++;
                this.$store.dispatch('post',{url: 'charting/' + this.year,data:{filters: this.filters}}).then(response => {
                    self.contracts = response.data.contracts;
                    self.today = response.data.today;
                    self.filters = response.data.filters;

                });
            }
        }
    }
</script>
<style>
    #current-date {
        position: absolute;
        border-left: 1px solid red;
        height: 100%;
        left: 20%;

        z-index: 50;
        top: 0px;
        color: red;
    }

    .tooltip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }

    .tooltip .tooltiptext {
        visibility: hidden;
        width: 120px;
        background-color: white;
        color: #000;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0;
        /* Position the tooltip */
        position: absolute;
        z-index: 1;
        margin-left: 20px;
    }

    .tooltip .tooltiptext table {
        font-size: 12px;
        min-width: 200px;
        text-align: left;
        background-color: #fff;
    }

    .tooltip .tooltiptext::after {
        content: " ";
        position: absolute;
        top: 50%;
        right: 100%; /* To the left of the tooltip */
        margin-top: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: transparent white transparent transparent;
    }

    .tooltip:hover .tooltiptext {
        visibility: visible;
    }










    .tooltip2 .tooltiptext2 {
        visibility: hidden;
        width: 120px;
        background-color: white;
        color: #000;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0;
        /* Position the tooltip */
        position: absolute;
        z-index: 1;
        margin-left: 20px;
    }

    .tooltip2 .tooltiptext2 table {
        font-size: 12px;
        min-width: 200px;
        text-align: left;
        background-color: #fff;
    }

    .tooltip2 .tooltiptext2::after {
        content: " ";
        position: absolute;
        top: 50%;
        right: 100%; /* To the left of the tooltip */
        margin-top: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: transparent white transparent transparent;
    }

    .tooltip2:hover .tooltiptext2 {
        visibility: visible;
    }










    table {
        width: 100%;
    }

    .contracts {
        position: relative;
        background-color: #f9f9f9;
        width: 100%;
    }

    .contract-spacer {
        margin: 2vh 0vw;
        position: relative;
        height: 40px;
    }

    .line-contract {
        margin: 2vh 0vw;
        position: relative;
        height: 60px;
        background-color: #fff;
        padding-left: -5px;
        padding-right: -5px;
    }

    .line-contract .leftbar {
        position: relative;
        height: 60px;
        float: left;
        width: 5px;
        background-color: #03a1da;
    }

    .line-contract .text {
        position: relative;
        height: 60px;
        float: left;
        padding-left: 10px;
        color: #000;
        text-decoration: none;
        font-size: 14px;
    }

    .line-contract .line-taak a {
        position: absolute;
        height: 60px;
        background-color: #03a1da;
        width: 10px;
        margin-top: -20px;
    }

    .line-taak-popover {
        position: absolute;
        height: 60px;
        background-color: #03a1da;
        width: 10px;
        cursor: pointer;
    }

    .line-contract .rightbar {
        position: relative;
        height: 60px;
        float: right;
        width: 5px;
        background-color: #03a1da;
    }

    .line-contract a {
        position: relative;
        top: 20px;
        left: 0px;
    }

    .year-selection {
        font-size: 20px;
    }

    .year-selection span {
        text-decoration: none;
        font-weight: bold;
        cursor: pointer;
    }
</style>