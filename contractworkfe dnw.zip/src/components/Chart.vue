<script>
    import VueCharts from 'vue-chartjs'
    import {Pie, Line} from 'vue-chartjs'

    function randomGet() {

        var myColors = new Array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
        var cutIn= 0;
        var myRandone = myColors[Math.floor(Math.random() * myColors.length)];
        var myRandtwo = myColors[Math.floor(Math.random() * myColors.length)];
        var myRandthree = myColors[Math.floor(Math.random() * myColors.length)];
        var myRandfour = myColors[Math.floor(Math.random() * myColors.length)];
        var myRandfive = myColors[Math.floor(Math.random() * myColors.length)];
        var myRandsix = myColors[Math.floor(Math.random() * myColors.length)];
        var sixDigitRandom =  myRandone + myRandtwo + myRandthree + myRandfour + myRandfive + myRandsix;

        return '#'+sixDigitRandom;
    }

    export default {
        extends: Pie,
        props: ['data', 'options'],
        mounted() {

            var test = {
                labels: ['January', 'February'],
                datasets: [
                    {
                        label: 'GitHub Commits',
                        backgroundColor: '#f87979',
                        data: [40, 20]
                    }
                ]
            };

            var datasets = [];
            datasets['data'] = [];
            datasets['backgroundcolor'] = [];
            for (var set in this.data.datasets) {
                datasets[set] = this.data.datasets[set];
                if (set == 'data') {
                    for (var x in this.data.datasets[set]) {
                        if (this.data.datasets[x] > 0) {

                            datasets['data'].push(this.data.datasets[x]);
                        }
                    }
                }
            }

            this.data.datasets = [datasets];
            this.renderChart(this.data, this.options);
        }
    }
</script>
<style>

</style>