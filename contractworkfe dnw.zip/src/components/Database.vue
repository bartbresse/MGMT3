<template>
    <div id="database">
        <el-form ref="form"  label-width="120px">
            <el-form-item label="Upload new MySQL structure">
                <file v-model="newstructure" ></file>
            </el-form-item>
            <div v-if="newstructure.value.length > 0">
            <el-form-item>
                <el-button @click="startUpdate" size="small" type="primary">Update database</el-button>
            </el-form-item>
                <!--
            <el-form-item label="Activity name">
                <el-input></el-input>
            </el-form-item>
            <el-form-item label="Activity zone">
                <el-select  placeholder="please select your zone">
                    <el-option label="Zone one" value="shanghai"></el-option>
                    <el-option label="Zone two" value="beijing"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <draggable class="draggable" v-model="myArray" group="people" @start="drag=true" @end="drag=false">
                    <div v-for="element in myArray" :key="element.id">{{element.name}}</div>
                </draggable>
            </el-form-item> -->
                <el-form-item>

                </el-form-item>
            </div>
        </el-form>
    </div>
</template>
<script>
    import draggable from 'vuedraggable'
    import { mapState } from 'vuex'
    import File from "./mgmt/formelements/File"
    import axios from 'axios'


    export default {
        name: 'Database',
        components: {draggable, File },
        computed: mapState([
            'data'
        ]),
        mounted (){
            this.load()
        },
        data () {
            return {
                myArray: [
                    {
                        "name": "Joao",
                        "text": "",
                        "id": 1
                    },
                    {
                        "name": "Jean",
                        "text": "",
                        "id": 2
                    },
                    {
                        "name": "John",
                        "text": "",
                        "id": 0
                    }
                ],
                fileList: [],
                apiurl: process.env.API_URL,
                cookie: document.cookie,
                newstructure: {value:''}
            }
        },
        methods: {
            startUpdate (){
                this.$store.dispatch('post',{url: process.env.API_URL + '/database/start',data:{data:this.newstructure,token: document.cookie}}).then(response => {
                })
            },
            load (){
                this.$store.dispatch('post',{url: process.env.API_URL + '/mgmt/test',data:''}).then(response => {

                })
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
            },
            handlePreview(file) {
                console.log(file);
            },
            handleExceed(files, fileList) {
                this.$message.warning(`The limit is 3, you selected ${files.length} files this time, add up to ${files.length + fileList.length} totally`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`Cancel the transfert of ${ file.name } ?`);
            }
        }
    }
</script>
<style>
    .draggable{
        cursor: pointer;
    }

    .draggable div{
        border-bottom: 1px solid #ddd;
    }
</style>