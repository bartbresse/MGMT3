<template>
    <div>
        <h1>Contractmanager: helpdesk</h1>

        <p>Ondervind u een probleem bij het gebruik van de Contractmanager? Laat het ons weten via: info@barnworks.nl</p>
        <p>Begin de onderwerp regel met 'issue contractmanager:'.</p>

        <br />
        <h2 style="float: left;">Features</h2><br /><br />
        <p>Mist u bepaalde functionaliteit? Dan horen we dat graag! Mogelijk hebben meerdere gebruikers hier behoefte aan.</p>
        <p>Stuur een Email met als onderwerp 'feature contractmanager: [uw onderwerp] ' naar info@barnworks.nl</p>
    </div>
</template>
<script>

    export default {
        name: 'Help',
        components: {},
        data () {
            return {
            }
        }
    }
</script>