'use strict';
module.exports = {
    NODE_ENV: '"production"',
    API_URL: '"https://api.contractmanager.eu/"'
}
