<?php

use Phalcon\Mvc\User\Component;
use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class SecurityHandler extends Component
{
    private $payload;
    private $eigenaar;
    private $secret;

    public function __construct($token = false, $urlexceptions = false, $dev = false)
    {
        $this->secret = '3k?H&Y;(W[39BTqU+<!j!<`m30w|$*';
        if (!$dev) {
            try {
                $uripart = '';
                if (is_array($urlexceptions)) {
                    $uri = explode('?', $_SERVER['REQUEST_URI']);
                    $uripart = $uri[0];
                } else {
                    $urlexceptions = [];
                }

                if (in_array($uripart, $urlexceptions)) {
                    $this->eigenaar = Eigenaar::findFirst();
                } else if ($token == false) {
                    echo json_encode(['result' => 'unauthorized']);
                    die();
                } else {
                    $this->payload = $this->payload($token);
                    $this->eigenaar = Eigenaar::findFirst('idEigenaar = "' . $this->payload->idEigenaar . '"');
                }
            } catch (Exception $e) {
                echo json_encode(['result' => 'expired']);
                die();
            }
        } else {
            $eigenaar = Eigenaar::findFirst();
            $this->payload = $eigenaar->toArray();
            $this->eigenaar = $eigenaar;
        }
    }

    public function getPayload($token = false)
    {
        return $this->payload;
    }

    private function payload($token)
    {
        $token = explode('&', $token);
        $token = explode('token=', $token[0]);
        $token = $token[1];

        $validator = new TokenValidator();
        $validator->splitToken($token)
            ->validateExpiration()
            ->validateSignature($this->secret);

        return json_decode($validator->getPayload());
    }

    public function getEigenaar()
    {
        return $this->eigenaar;
    }

    public function getEigenaarID()
    {
        return $this->payload->idEigenaar;
    }
}