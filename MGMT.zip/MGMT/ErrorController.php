<?php

class ErrorController extends ControllerBase
{
    public function route404Action()
    {
        echo '<h1>404</h1>';
    }
}