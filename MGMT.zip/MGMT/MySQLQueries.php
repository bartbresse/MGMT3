<?php
use Phalcon\Mvc\User\Component;

class MySQLQueries extends Component
{
    public function select($query)
    {
        $conn2 = new PDO('mysql:host=localhost;dbname='.$this->globalconfig->dbname, $this->globalconfig->username, $this->globalconfig->password);
        $query3 = $conn2->prepare($query);
        $result = $query3->execute();
        return $query3->fetchAll();
    }

    public function getTablesReferencedTables($tablename)
    {
        return $this->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      ( TABLE_NAME = '".$tablename."' )");

    }

    public function getTables($tablename)
    {
        //OR TABLE_NAME = '".$tablename."'
        return $this->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      ( REFERENCED_TABLE_NAME = '" . $tablename . "' )");

    }
}