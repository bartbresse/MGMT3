<?php

use Phalcon\Mvc\User\Component;

class FormJsonHandler extends Component
{
    protected $tableRowId;
    protected $table;

    private $language;

    public function __construct(EntityInfo $entityInfo)
    {
        //TODO: integrate entityinfo
        $this->table = $entityInfo->tablename;
        $this->tableRowId = $entityInfo->entityrowid;
    }

    public function setLanguageHandler($languageHandler)
    {
        $this->language = $languageHandler;
    }

    private function getBaseUrl()
    {
        $hostName = $_SERVER['HTTP_HOST'];
        $protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"], 0, 5)) == 'https' ? 'https' : 'http';
        return $protocol . '://' . $hostName;
    }

    private function getSelectFileList($key, $id)
    {
        $mysql = new MySQLQueries();
        $enum = [];

        if($key == 'product_has_document'){

            $results = ProductHasDocument::find('Product_idProduct = "' . $id . '"');
            foreach ($results as $naam) {

                //print_r($naam);

                $naam = $naam->Document->toArray();

                //print_r($naam);

                $lv = new labelfilevalue();
                $lv->url = $this->getBaseUrl() . $naam['Path'];
                $lv->name = $naam['Naam'];
                $enum[] = $lv;
            }

        }else if($key == 'document_has_contract') {

            $results = DocumentHasContract::find('Contract_idContract = "' . $id . '"');
            foreach ($results as $naam) {

                //print_r($naam);

                $naam = $naam->Document->toArray();

                //print_r($naam);

                $lv = new labelfilevalue();
                $lv->url = $this->getBaseUrl() . $naam['Path'];
                $lv->name = $naam['Naam'];
                $enum[] = $lv;
            }

        }else if($key == 'taak_has_document'){

            $results = TaakHasDocument::find('Taak_idTaak = "' . $id . '"');
            foreach ($results as $naam) {
                $naam = $naam->Document->toArray();

                $lv = new labelfilevalue();
                $lv->url = $this->getBaseUrl() . $naam['Path'];
                $lv->name = $naam['Naam'];
                $enum[] = $lv;
            }

        }

        return $enum;
    }

    private function getSelectList($key)
    {


        $enum = [];
            $mysql = new MySQLQueries();
            $results = $key::find();
            $columns = [];

            foreach ($mysql->select("DESCRIBE `" . strtolower($key) . "`") as $fieldx) {
                $columns[] = $fieldx['Field'];
            }

            foreach ($results->toArray() as $naam) {
                $structuur = Structuur::find('tabel = "' . strtolower($key) . '" AND sel > 0');
                if (count($structuur) > 0 || !isset($naam['Naam'])) {

                    $lv = new labelvalue();
                    $lv->value = $naam[$columns[0]];
                    $str = '';
                    foreach ($structuur as $index => $val) {
                        if ($index > 0) {
                            $str .= ' ';
                        }
                        $str .= $naam[$val->name];
                    }
                    $lv->label = $str;
                    $enum[] = $lv;

                } else {

                    $lv = new labelvalue();
                    $lv->value = $naam[$columns[0]];
                    $lv->label = $naam['Naam'];
                    $enum[] = $lv;

                }
            }

        return $enum;
    }

    private
    function getStructuurDatabaseVariable($field, $table)
    {
        $structuur = Structuur::findFirst('field = "' . $field['Field'] . '" AND tabel = "' . $table . '"');

        if (!$structuur) {
            $structuur = new Structuur();
            if (!isset($field['isTableField'])) {
                $field['isTableField'] = true;
            }
            $structuur->istablefield = $field['isTableField'];
            $structuur->field = $field['Field'];
            $structuur->name = $field['Field'];
            $structuur->title = $field['Field'];
            $structuur->placeholder = $field['Field'];
            $structuur->tabel = $table;

            if (!$structuur->save()) {
                //   print_r($structuur->getMessages());
            }
        }
        return $structuur;
    }

    public
    function getForeignRelations($table, $id, $row)
    {
           $fields = [];
        $mysql = new MySQLQueries();

        foreach ($mysql->getTables($table) as $table2) {
            $orm = new OrmEntity();
            $orm->setTableName($table2['TABLE_NAME']);
            $orm->setLocalEntity($table);

            //TODO: this is only used for the structuur->cssclass field
            $structuur = $this->getStructuurDatabaseVariable(['Field' => $orm->foreign_classname, 'isTableField' => false], $table);
            $f = $structuur->toArray();
            $f['attr'] = json_decode($f['attr'],true);

            $f['name'] = $orm->foreign_classname;
            $f['title'] = $this->language->translate($orm->foreign_classname);

            $f['field'] = $orm->tablename;
            $f['tabel'] = $orm->tablename;
            $f['description'] = ' ';
            $f['visible'] = true;
            $f['message'] = '';

            $f['placeholder'] = $orm->foreign_classname;

            if ($orm->isMany()) { //manyToMany

                //TODO: figure out how to do this better
                if ($orm->foreign == 'document') {

                    $f['filelist'] = $this->getSelectFileList($orm->tablename, $id);
                    $f['type'] = 'files';
                } else {
                    $f['enum'] = $this->getSelectList($orm->foreign_classname);
                    $f['entity'] = strtolower($orm->foreign_classname);
                    $f['type'] = 'multiselect';
                }

                //TODO: make multiple select option values possible with front end
                if (is_object($row)) {
                    $class = $orm->classname;
                    $foreignid = $orm->foreign_id;
                    foreach ($row->$class as $sub) {
                        $f['value'] = [$sub->$foreignid];
                    }
                }
            } else { //oneToMany
                if ($orm->tablename == 'document') {
                    $f['filelist'] = $this->getSelectFileList($orm->tablename, $id);
                    $f['type'] = 'files';
                } else {
                    $f['enum'] = $this->getSelectList($orm->classname);
                    $f['entity'] = strtolower($orm->classname);
                    $f['type'] = 'multiselect';
                }
            }
            if(!isset($f['value']))
            {
                $f['value'] = '';
            }

            $fields[$orm->tablename] = $f;
        }
        return $fields;
    }

    public static function getBetween($str,$left = "(",$right = ")")
    {
        $st =explode($left,$str);
        $fst = explode($right,$st[1]);
        return $fst[0];
    }

    public
    function render()
    {
        //TODO: fix everywhere
        $mysql = new MySQLQueries();

        $tags = $mysql->select("DESCRIBE `" . strtolower($this->table) . "`");

        $fields = [];
        $count = 0;

        $objectrow = [];
        if ($this->tableRowId) {
            $entity = ucfirst($this->table);

           // echo $entity.'='.'id' . $entity . ' = ' . $this->tableRowId;

            $row = $entity::findFirst('id' . $entity . ' = ' . $this->tableRowId);
            $objectrow = $row;
            $row = $row->toArray();
        }

        //TODO: not always defined
        $structuur = [];

        $structuurtable = Structuurtable::findFirst('sqltable = "' . $this->table . '"');
        if (!$structuurtable) {
            $structuurtable = new Structuurtable();
            $structuurtable->sqltable = $this->table;
            if (!$structuurtable->save()) {
                print_r($structuurtable->getMessages());
            }
        }

        foreach ($tags as $index => $field) {
            if ($count > 0) {

                $structuur = $this->getStructuurDatabaseVariable($field, $this->table);

                if ($field['Field'] != 'id' . $this->table && $field['Field'] != 'Verlenging') {
                    $f = $structuur->toArray();
                    $f['attr'] = json_decode($f['attr'],true);
                    $f['visible'] = true;
                    $f['message'] = '';

                    if($f['description'] == 'NULL' || $f['description'] == 'null' || $f['description'] == null)
                    {
                        $f['description'] = '';
                    }

                    $f['title'] = $this->language->translate($f['title']);

                    if ($field['Null'] == 'NO') {
                        $f['required'] = true;
                    } else {
                        $f['required'] = false;
                    }

                    if ($this->tableRowId) {
                        if($row[$field['Field']] == 'NULL' || $row[$field['Field']] == 'null' || $row[$field['Field']] == null)
                        {
                            $row[$field['Field']] = '';
                        }
                        $f['value'] = $row[$field['Field']];
                    } else if (strlen($f['defaultvalue']) > 0) {
                        $f['value'] = $f['defaultvalue'];
                    }
                    $dont = false;

                    if (strpos($field['Field'], '_id') !== false) {

                        $foreign = explode('_id', $field['Field']);
                        $key = ucfirst($foreign[1]);
                        //TODO should a class always exist? Or is it fine to Name relations te way you want it. Contract > extra document fields
                        //custom relationships go to else
                        if(class_exists($key)) {
                            $f['type'] = 'select';
                            $f['enum'] = $this->getSelectList($key);
                            $f['entity'] = strtolower($key);
                        }else{

                            $f['type'] = 'file';
                        }


                    } else {
                        //TODO: rework this bullshit
                        if (isset($structuur->type) && strlen($structuur->type) > 0) {
                            $field['Type'] = $structuur->type;
                        }

                        if (strpos($field['Type'], 'varchar') !== false) {
                            $type = 'string';
                        } else if (strpos($field['Type'], 'tinyint') !== false) {
                            $type = 'switch';
                            if(!isset($f['value']))
                            {
                                $f['value'] = false;
                            }
                        } else if (strpos($field['Type'], 'decimal') !== false) {
                            $type = 'money';
                        } else if (strpos($field['Type'], 'int') !== false) {
                            $type = 'number';
                            $f['minlength'] = 1;
                            $f['maxlength'] = $this->getBetween($field['Type']);
                        } else if (strpos($field['Type'], 'datetime') !== false) {
                            $type = 'date';
                        } else if (strpos($field['Type'], 'text') !== false) {
                            $type = 'textarea';
                        } else if (strpos($field['Type'], 'double') !== false) {
                            $type = 'number';
                            $f['minlength'] = 1;
                            $f['maxlength'] = 2; // $this->getBetween($field['Type']);
                        } else if ($field['Type'] == 'period') {
                            $type = $field['Type'];
                        }

                        if (isset($structuur->type) && strlen($structuur->type) > 0) {
                            $type = $structuur->type;
                        }

                        if (isset($structuur->cssclass) && strlen($structuur->cssclass) > 0) {
                            $f['cssclass'] = $structuur->cssclass;
                        }

                        $f['type'] = $type;
                    }

                    if(!isset($f['value']))
                    {
                        $f['value'] = '';
                    }

                    if (!$dont) {
                        $fields[$field['Field']] = $f;
                    }
                }
            }

            $count++;
        }


        $fields = array_merge($fields, $this->getForeignRelations($this->table, $this->tableRowId, $objectrow));
        $allfields = $fields;

        //show only relevant columns in forms
        if (!isset($structuurtable->fieldsinform) || strlen($structuurtable->fieldsinform) < 5) {
            //  print_r($structuurtable->fieldsinform);

            $fieldsinform = [];
            foreach ($fields as $field) {
                $fieldsinform[] = $field['field'];
            }

            $structuurtable->fieldsinform = json_encode($fieldsinform);
            $structuurtable->save();
        } else {
            $fieldsinform = json_decode($structuurtable->fieldsinform);

        //    print_r($fieldsinform);

            if (is_array($fieldsinform)) {

                $defaultnotvisiblefields = ['Createdat', 'Lastedit', 'Updatedat', 'Deletedat', 'Eigenaar_idEigenaar'];
                foreach ($fields as $index => $field) {

                    if (!in_array($field['field'], $fieldsinform)) {
                        unset($fields[$index]);
                    } else if (in_array($field['field'], $defaultnotvisiblefields)) {
                        unset($fields[$index]);
                    }
                }
            }

        //    print_r($fields);
        }

        $json = [];
        $json['$schema'] = 'http://json-schema.org/draft-04/schema#';
        $json['type'] = 'object';
        $json['title'] = $structuurtable->title;
        $json['table'] = $structuurtable->sqltable;
        $json['savebuttontext'] = $structuurtable->savebuttontext;
        $json['cancelbuttontext'] = $structuurtable->cancelbuttontext;

        $json['description'] = $structuurtable->description;
        $json['properties'] = $fields;

        $json['allconnectedproperties'] = $allfields;
        $json['additionalProperties'] = false;

        return $json;
    }
}

class labelvalue
{
    public $value;
    public $label;
}


class labelfilevalue
{
    public $url;
    public $name;
}