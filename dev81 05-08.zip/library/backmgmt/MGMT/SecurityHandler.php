<?php

use Phalcon\Mvc\User\Component;
use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class SecurityHandler extends Component
{
    private $payload;
    private $eigenaar;

    public function __construct($token = false, $urlexceptions = false, $dev = false)
    {

        if (!$dev) {
            try {
                $uripart = '';
                if (is_array($urlexceptions)) {
                    $uri = explode('?', $_SERVER['REQUEST_URI']);
                    $uripart = $uri[0];
                } else {
                    $urlexceptions = [];
                }

                if (in_array($uripart, $urlexceptions)) {
                    $this->eigenaar = Eigenaar::findFirst();
                } else if ($token == false) {
                    echo json_encode(['result' => 'unauthorized']);
                    die();
                } else {
                    $secret = '3k?H&Y;(W[39BTqU+<!j!<`m30w|$*';
                    $request_body = json_decode(file_get_contents('php://input'), true);

                    $token = explode('&', $token);
                    $token = explode('token=', $token[0]);
                    $token = $token[1];

                    $validator = new TokenValidator();
                    $validator->splitToken($token)
                        ->validateExpiration()
                        ->validateSignature($secret);

                    $this->payload = json_decode($validator->getPayload());
                    $this->eigenaar = Eigenaar::findFirst('idEigenaar = "' . $this->payload->idEigenaar . '"');
                }
            } catch (Exception $e) {
                echo json_encode(['result' => 'expired']);
                die();
            }


        } else {
            $eigenaar = Eigenaar::findFirst();
            $this->payload = $eigenaar->toArray();
            $this->eigenaar = $eigenaar;
        }
    }

    public function getEigenaar()
    {
        return $this->eigenaar;
    }

    public function getEigenaarID()
    {
        return $this->payload->idEigenaar;
    }
}