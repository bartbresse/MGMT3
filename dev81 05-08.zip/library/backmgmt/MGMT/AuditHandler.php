<?php

use Phalcon\Mvc\User\Component;

/**
 * Class AuditHandler
 *
 * Handles logging from every user action when, where, who
 * Write only system:
 *
 * code:
 * [file]:[line]
 */
class AuditHandler extends Component
{
    public function listAudit($entity,$id)
    {
        $structuurtable = Structuurtable::findFirst('sqltable = "'.$entity.'"');

        $log = [];
        $audits = Audit::find('Structuurtable_idStructuurtable = '.$structuurtable->idstructuurtable.' AND Entityid = '.$id);
        foreach($audits as $audit)
        {
            if($audit->Action == 'add')
            {
                $log[] = ['id' => $audit->idAudit,'Eigenaar' => $audit->Eigenaar->Voornaam.' '.$audit->Eigenaar->Achternaam,'Action' => 'Toevoegen','Lastedit' => date('d-m-Y H:i',strtotime($audit->Lastedit)),'changefields' => ''];
            }else{
                $new = json_decode($audit->Newrow,true);
                $changefields = '';
                foreach(json_decode($audit->Oldrow) as $index => $field)
                {
                    if($field != $new[$index])
                    {
                        $changefields .= $field.' <b>veranderd naar</b> '.$new[$index].',<br />';
                    }
                }
                $log[] = ['id' => $audit->idAudit,'Eigenaar' => $audit->Eigenaar->Voornaam.' '.$audit->Eigenaar->Achternaam,'Action' => 'Wijzigen','Lastedit' => date('d-m-Y H:i',strtotime($audit->Lastedit)),'changefields' => $changefields];
            }
        }

        return $log;
    }

    public function add($action, $eigenaar, EntityInfo $ei, $oldrow)
    {
        $audit = new Audit();

        $structuurtable = Structuurtable::findFirst('sqltable = "'.$ei->tablename.'"');

        $audit->Structuurtable_idStructuurtable = $structuurtable->idstructuurtable;
        $audit->Eigenaar_idEigenaar = $eigenaar;
        $audit->Action = $action;
        $audit->Oldrow = json_encode($oldrow);
        $audit->Entityid = $ei->entityrowid;

        $newrow = $ei->entityname::findFirst('id'.$ei->entityname.' = "'.$ei->entityrowid.'"');
        if($newrow){
           $newrow = $newrow->toArray();
        }else{
           $newrow = [];
        }

        $audit->Newrow = json_encode($newrow);

        if (!$audit->save()) {
            print_r($audit->getMessages());
        }
    }
}