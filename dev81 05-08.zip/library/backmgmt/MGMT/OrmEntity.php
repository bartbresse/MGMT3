<?php

class OrmEntity
{
    public $tablename;
    public $classname;
    public $local;
    public $local_classname;
    public $local_id;
    public $foreign;
    public $foreign_classname;
    public $foreign_id;
    public $type;

    public function toArray()
    {
        $f = [];
        $f['tablename'] = $this->tablename;
        $f['classname'] = $this->classname;
        $f['local'] = $this->local;
        $f['local_classname'] = $this->local_classname;
        $f['local_id'] = $this->local_id;
        $f['foreign'] = $this->foreign;
        $f['foreign_classname'] = $this->foreign_classname;
        $f['foreign_id'] = $this->foreign_id;
        $f['type'] = $this->type;
        return $f;
    }

    public function relationToSelf()
    {
        if ($this->local == $this->foreign) {
            return true;
        } else {
            return false;
        }
    }

    public function setLocalEntity($local)
    {
        $this->local = strtolower($local);
        $this->local_classname = ucfirst($local);
        //echo $local;
        $this->local_id = ucfirst($local) . '_id' . ucfirst($local);

        foreach (explode('_', $this->tablename) as $part) {
            if ($part != 'has' && $part != $this->local) {

                $foreign = $part;
            } else if ($part == 'has') {
                $this->type = 'hasmany';
            }
        }

        //Table has a relation to itself eg: a webpage has a parent webpage
        if (!isset($foreign)) {
            $foreign = $this->local;
        }

        $this->foreign_id = ucfirst($foreign) . '_id' . ucfirst($foreign);
        $this->foreign = $foreign;
        $this->foreign_classname = ucfirst($foreign);
        // die();
    }

    /**
     * Is many to many relation table
     */
    public function isMany()
    {
        if ($this->type == 'hasmany') {
            return true;
        } else {
            return false;
        }
    }

    public function setTableName($tablename)
    {
        $this->tablename = $tablename;
        if (strpos($this->tablename, '_') > 0) {

            if (strpos($this->tablename, '_has_') > 0) {
                // echo $tablename;

                $classname = '';
                foreach (explode('_', $tablename) as $name) {
                    //       echo $name;
                    $classname .= ucfirst($name);
                }

                // echo $classname;
            } else {
                $tablename = explode('_', $this->tablename);
                $classname = $tablename[0];
                $this->tablename = strtolower($tablename[0]);
            }
        } else {
            $classname = ucfirst($tablename);
            $this->tablename = strtolower($tablename);
        }
        /*   echo 'cn:'.$classname.'
           ';*/


        $this->classname = $classname;
    }

    public function setClassName($classname)
    {
        $this->classname = $classname;

    }
}