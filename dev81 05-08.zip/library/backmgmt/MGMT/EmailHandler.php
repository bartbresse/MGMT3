<?php

use Phalcon\Mvc\User\Component;

/**
 * Class AuditHandler
 *
 * Handles logging from every user action when, where, who
 * Write only system:
 *
 * code:
 * [file]:[line]
 */
class EmailHandler extends Component
{
    
}