<?php

use Phalcon\Mvc\User\Component;

class StorageHandler extends Component
{
    private $entityInfo;
    private $formRender;

    public function __construct(EntityInfo $entityInfo)
    {
        //TODO: integrate entityinfo
        $this->entityInfo = $entityInfo;
        $this->tableRowId = $entityInfo->entityrowid;
    }

    public function setFormRender($form)
    {
        $this->formRender = $form;
    }

    private function integrityCheck($postData, $ignorefields = [])
    {
        $mysql = new MySQLQueries();

        $fields = [];
        $errorCount = 0;

        foreach ($mysql->select("DESCRIBE `" . strtolower($this->entityInfo->entityname) . "`") as $item) {
            if (!in_array($item['Field'], $ignorefields)) {
                if ($item['Field'] != 'id' . ucfirst($this->entityInfo->entityname)) {

                    if (isset($postData[$item['Field']])) {
                        if (($item['Key'] == 'UNI' || $item['Key'] == 'PRI')) {

                            $entity = $this->entityInfo->entityname::findFirst($item['Field'] . ' = "' . $postData[$item['Field']]['value'] . '"');
                            // only we provide a different value on edit
                            $field = $item['Field'];
                            if ($entity && $postData[$item['Field']]['value'] != $entity->$field) {

                                $this->formRender['properties'][$item['Field']]['error'] = 1;
                                $this->formRender['properties'][$item['Field']]['message'] = 'Deze waarde is al eerder opgegeven.';
                                $errorCount++;
                            }
                        }

                        if ($item['Null'] != 'YES') {
                            if (strlen($postData[$item['Field']]['value']) < 1) {
                                //   echo '3 uni ' . $item['Field'];
                                $this->formRender['properties'][$item['Field']]['error'] = 1;

                                //    echo $item['Field'].'Dit veld moet worden ingevuld.';
                                $this->formRender['properties'][$item['Field']]['message'] = 'Dit veld moet worden ingevuld.';
                                $errorCount++;
                            }
                        }
                    } else if ($item['Null'] != 'YES') {
                        //   echo '4 uni ' . $item['Field'].'<br />';
                        $this->formRender['properties'][$item['Field']]['error'] = 1;
                        //   echo $item['Field'].'Dit veld moet worden ingevuld.';
                        $this->formRender['properties'][$item['Field']]['message'] = 'Dit veld moet worden ingevuld.';
                        // 	echo $item['Field'].' not set<br />';
                        $errorCount++;
                    } else {
                        $this->formRender['properties'][$item['Field']]['error'] = 0;
                        $this->formRender['properties'][$item['Field']]['message'] = false;
                    }
                }
            }
        }

        //print_r($this->formRender['properties']);
        /*
                foreach ($this->formRender['properties'] as $property){
                    if(isset($property['message']) && strlen($property['message']) > 0){
                        echo $property['name'].':'.$property['message'].'
                        ';
                    }
                }
                echo $errorCount;
        */

        if ($errorCount > 0) {
            return false;
        } else {
            return true;
        }
    }

    public function store($postData,$eigenaarID)
    {
        $ignorefields = ['Createdat', 'Updatedat', 'Lastedit', 'Deletedat', 'Eigenaar_idEigenaar'];

        $integritycheck = $this->integrityCheck($postData, $ignorefields);
        if ($integritycheck) {

            $id = 'id' . $this->entityInfo->entityname;
            if ($this->tableRowId) {
                $en = $this->entityInfo->entityname::findFirst('id' . $this->entityInfo->entityname . ' = ' . $this->tableRowId);
            } else {
                $en = new $this->entityInfo->entityname();
            }

            foreach ($postData as $index => $data) {
                $name = ucfirst($index);
                //TODO: fix document handling
                if ($name != 'Document') {
                    //if you try to store empty relations SQL:1452 will occur
                    if (isset($data['value']) && !is_array($data['value']) && strlen($data['value']) > 0) {
                        //boolean values need to be trans
                        $en->$name = $data['value'];
                    } else if (isset($data['value']) && is_array($data['value']) && count($data['value']) > 0) {
                        //TODO: figure out if we need to save arrays
                    }
                }
            }

            $en->Eigenaar_idEigenaar = $eigenaarID;

            if (!$en->save()) {
                $messages = [];

                print_r($en->getMessages());
                die();

                foreach ($en->getMessages() as $message) {
                    $messages[$message->getField()] = $message;
                }
                $this->formRender['result'] = 'failure';
            } else {

                //TODO: figure out where this goes / for popup forms
                $fieldname = '';
                foreach($this->formRender['properties'] as $index => $property)
                {
                    if(isset($property['sel']) && $property['sel'] > 0)
                    {
                        $fieldname .= $en->$index.' ';
                    }
                }

                $this->formRender['fieldname'] = $fieldname;
                $this->formRender['id'] = $en->$id;
                //TODO: fix this. what is this.

                foreach ($postData as $index => $data) {
                    $name = ucfirst($index);
                    //TODO: fix document handling
                    if ($name == 'Document') {
                        foreach ($data as $file) {

                            //TODO: force one option

                            $entityfieldname = $this->entityInfo->entityname . '_id' . $this->entityInfo->entityname;
                            $shortentityfieldname = 'id' . $this->entityInfo->entityname;

                            $classname = $this->entityInfo->entityname . 'HasDocument';
                            if (!class_exists($classname)) {

                                $classname = 'DocumentHas' . $this->entityInfo->entityname;
                            }

                            $document = new $classname();

                            $document->Document_idDocument = $file['idDocument'];
                            $document->$entityfieldname = $en->$shortentityfieldname;
                            if (!$document->save()) {
                                echo 'storagehandler:store():store document';
                                print_r($document->getMessages());
                                die();
                            }
                        }
                    }
                    //TODO: store many to many
                    $orm = new OrmEntity();
                    $orm->setTableName($index);
                    $orm->setLocalEntity($this->entityInfo->entityname);
                    if ($orm->isMany()) {
                        $class = $orm->classname;
                        $local = 'id' . $orm->local_classname;
                        $entity = $class::findFirst($orm->local_id . ' = ' . $en->$local . '');


                        if (!$entity) {

                          //  print_r($data);

                            if (is_array($data) && count($data['value']) == 0) {

                            } else if(is_array($data['value'])) {
                                $entity = new $class();
                                $local_id = $orm->local_id;
                                $entity->$local_id = $en->$local;
                                $foreign_id = $orm->foreign_id;

                                $entity->$foreign_id = $data['value'][0];
                              //  echo $local_id.'::'.$entity->$local_id;

                              //  print_r($entity->$foreign_id);

                              //  echo $foreign_id.'::'.$entity->$foreign_id;



                                if (!$entity->save()) {
                                    print_r($entity->getMessages());
                                    die();
                                }
                            }
                        }
                    }
                }
                $this->formRender['result'] = 'succes';
            }

            foreach ($this->formRender['properties'] as $index => $field) {
                if (isset($field['field']) && isset($messages[$field['field']])) {
                    $field['error'] = 1;
                    $field['message'] = $messages[$field['field']]->getMessage();
                }

                $this->formRender['properties'][$index] = $field;
            }
        } else {
            $this->formRender['result'] = 'failure';
        }

        // print_r($this->formRender);

        return $this->formRender;
    }
}