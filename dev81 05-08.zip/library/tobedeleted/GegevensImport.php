<?php
use Phalcon\Mvc\User\Component;

class GegevensImport extends Component
{
    public function import()
    {
        $file = 'Gegevens.csv';
        ini_set('max_execution_time', 600);
        if (($handle = fopen('../public/' . $file, 'r')) !== false) {
            $header = fgetcsv($handle, 0, ';');
            print_r($header);

            $params = ['body' => []];
            while (($data = fgetcsv($handle, 0, ';')) !== false) {

          //      print_r($data);

                /*
                [0] => Naam
                [1] => Contract
                [2] => Onderwerp
                [3] => Taak
                [4] => Relatie
                [5] => Waarde
                [6] => Eenheid
                [7] => Opmerkingen
                [8] => Begindatum
                [9] => Einddatum
                [10] => Toevoegdatum
                [11] => Eigenaar

                [0] => Bedrag per 4 weken (ex BTW)
                [1] => Ndix - ICT - Lijnverbinding - Tiel
                [2] =>
                [3] =>
                [4] => Ndix bv
                [5] => 450,00
                [6] => EUR
                [7] => Inclusief BTW, wordt elk kwartaal gefactureerd sinds 2015.
                [8] => 2015-06-01
                [9] => 2018-05-31
                [10] => 19-01-2018
                [11] => Anne Boelsma
                */


                $gg = new Gegevens();

                $gegevens = GegevensType::findFirst('Naam LIKE "%'.$data[0].'%"');
                $gg->GegevensType_idGegevensType = $gegevens->idGegevensType;

                $taak =Taak::findFirst('idTaak = "'.$data[3].'"');
                $gg->Taak_idTaak = $taak->idTaak;
                $gg->Waarde = $data[5];
                $gg->Opmerkingen = $data[7];
                $gg->Begindatum = date('Y-m-d',strtotime($data[8]));
                $gg->Einddatum = date('Y-m-d',strtotime($data[9]));

                $d = array_reverse(explode(' ',$data[10]));
                $eigenaar = Eigenaar::findFirst('Achternaam LIKE "%'.$d[11].'%"');
                $gg->Eigenaar_idEigenaar = $eigenaar->idEigenaar;

                if(!$gg->save())
                {
                    print_r($gg->getMessages());
                }

            }
        }
    }
}