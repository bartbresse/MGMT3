<?php

use Phalcon\Mvc\User\Component;

class EmailHandler extends Component
{

    public function send($subject,$message,$to)
    {
        $promise = $this->sparkpost->transmissions->post([
            'options' => [
                'sandbox' => false,
            ],
            'content' => [
                'from' => [
                    'name' => 'Contract manager',
                    'email' => 'info@dev81.2sonder.com',
                ],
                'subject' => $subject,
                'html' => $message,
                'text' => 'Congratulations, {{name}}!! You just sent your very first mailing!',
            ],
            'substitution_data' => ['name' => 'Contract manager'],
            'recipients' => [
                [
                    'address' => [
                        'name' => 'Contract manager',
                        'email' => $to,
                    ],
                ],
            ],
        ]);

        try {
            $response = $promise->wait();
            var_dump($response);
            echo "Request:\n";
            print_r($response->getRequest());
            echo "Response:\n";
            echo $response->getStatusCode() . "\n";
            print_r($response->getBody()) . "\n";
        } catch (\Exception $e) {
            echo "Request:\n";
            print_r($e->getRequest());
            echo "Exception:\n";
            echo $e->getCode() . "\n";
            echo $e->getMessage() . "\n";
        }

    }


}