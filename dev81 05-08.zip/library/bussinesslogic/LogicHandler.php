<?php

interface LogicHandler
{

}