<?php

use Phalcon\Mvc\User\Component;

class CrontaakHandler extends Component implements  LogicHandler
{
    public function __construct($entity,$entityInfo)
    {
        if($entityInfo->entityname == 'Taak')
        {
            $this->taakCron();
        }
    }

    private function taakCron()
    {
        $emailhandler = new EmailHandler();

        $notificationmodel = new NotificationModel();

        $taken = [];
        foreach(Taak::find() as $taak)
        {
            //upcoming tasks
            if((strtotime($taak->Einddatum) - (24*3600*14)) < time() && strtotime($taak->Einddatum) > time() && $taak->Taakstatus_idTaakstatus == 1)
            {
                $notificationmodel->addUpcomingTask($taak);
            }

            //active tasks that need to be notified
            if(strtotime($taak->Notificatiedatum) < time() && strtotime($taak->Einddatum) > time() && $taak->Taakstatus_idTaakstatus == 1)
            {
                $notificationmodel->addUpcomingNotificationTask($taak);
            }

            //overdue tasks
            if(strtotime($taak->Einddatum) < strtotime('-1 days') && $taak->Taakstatus_idTaakstatus == 1 && strtotime($taak->Einddatum) > 0)
            {
                $notificationmodel->addOverdueTask($taak);
            }
        }

        foreach (Contract::find() as $contract)
        {
            //opzegtermijn gaat in in 2 weken
            if((strtotime($contract->Opzegtermijn) - (24*3600*14)) < time() && strtotime($contract->Einddatum) > time())
            {
                $notificationmodel->addUpcomingNotificationContract($contract);
            }

            //contract eindigt binnen twee weken
            if((strtotime($contract->Einddatum) - (24*3600*14)) < time() && strtotime($contract->Einddatum) > time())
            {
                $notificationmodel->addEndingContract($contract);
            }
        }

        print_r($notificationmodel->getEmail());



      //  $emailhandler->send();
    }
}