<?php

use Phalcon\Mvc\User\Component;

class UrlDataContainer extends Component
{
    public $container;

    public function __construct($appdatastring = false)
    {
        if($appdatastring) {
            $this->container = json_decode(base64_decode($appdatastring), true);
        }
    }

    public function add($key,$value){
        if(!isset($container[$key])) {
            $container[$key] = $value;
        }
    }

    public function generate()
    {
        return base64_encode(json_encode($this->container));
    }
}