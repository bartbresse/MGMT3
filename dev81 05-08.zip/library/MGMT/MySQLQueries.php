<?php
use Phalcon\Mvc\User\Component;

class MySQLQueries extends Component
{
    public $result;
    public $errors;

    public function select($query)
    {
        $conn2 = new PDO('mysql:host='.$this->globalconfig->host.';dbname='.$this->globalconfig->dbname, $this->globalconfig->username, $this->globalconfig->password);
        $conn2->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );

        $query3 = $conn2->prepare($query);
        $this->result = $query3->execute();
        $this->errors = $query3->errorInfo();
        if($query3->rowCount() > 0) {
            return $query3->fetchAll();
        }else{
            return false;
        }
    }

    public function getTablesReferencedTables($tablename)
    {
        return $this->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      ( TABLE_NAME = '".$tablename."' )");
    }

    public function getTables($tablename)
    {
        //OR TABLE_NAME = '".$tablename."'
        $rows = $this->select("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      ( REFERENCED_TABLE_NAME = '" . $tablename . "' )");

        if(is_array($rows) && count($rows) > 0) {
            return $rows;
        }else{
            return [];
        }
    }
}