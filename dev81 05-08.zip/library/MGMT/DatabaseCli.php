<?php

use Phalcon\Mvc\User\Component;
require_once 'utils/MySQLQuery.php';

class DatabaseCli extends Component
{
    public function __construct()
    {

    }

    public function backupDatabaseTableData()
    {
        $Mysqlqueries = new MySQLQueries();
        $tables = $Mysqlqueries->select('show tables');
        $results = [];
        foreach($tables as $table)
        {
            $orm = new OrmEntity();
            $orm->setTableName($table[0]);
            $mysqlquery = new MySQLQuery();
            $rows = $orm->classname::find();
            $results[$table[0]] = $mysqlquery->insert($table[0], $rows->toArray());
        }
        return $results;
    }

    public function backupDatabase($databasename)
    {
        // mysqldump -u user_name -p name-of-database >file_to_write_to.sql
        $filename='database_backup_'.date('G_a_m_d_y').'.sql';

        $password = strval($this->globalconfig->database->rootpassword);
        $result=exec('mysqldump '.$databasename.' --password='.$password.' --user=root --single-transaction >/home/sonder/domains/2sonder.com/public_html/dev81/public/files/'.$filename,$output);
        if($output==''){ throw new Exception("DatabaseCli: Mysql backup command failed"); }
        else {

        }
        return $filename;
    }

    public function insertDatabaseStructure($filename)
    {
        echo 'mysql --password='.$this->globalconfig->database->rootpassword.' --user=root < /home/sonder/domains/2sonder.com/public_html/dev81/public/files/'.$filename;
        exec('mysql --password='.$this->globalconfig->database->rootpassword.' --user=root < /home/sonder/domains/2sonder.com/public_html/dev81/public/files/'.$filename,$output);
       return $output;
    }

    public function restoreDatabase()
    {
        // mysql -u user_name -p <file_to_read_from.sql
    }

}