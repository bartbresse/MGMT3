<?php

use Phalcon\Mvc\User\Component;

class FilterHandler extends Component
{
    public function render($ei)
    {
        $mysql = new MySQLQueries();
        $tablefields = [];
        foreach($mysql->select('DESCRIBE `'.$ei->tablename.'`') as $field)
        {
            $tablefields[] = $field['Field'];
        }

        $filters = [];
        foreach (Structuur::find('tabel = "' . $ei->tablename . '" AND filter = 1') as $structuur) {
            $filter = $structuur->toArray();
            $options = [];

            if(in_array($structuur->field,$tablefields)){

                $rows = $mysql->select("SELECT DISTINCT " . $structuur->field . " FROM " . $structuur->tabel . " ");
                $id = explode('_id', $structuur->field);

                if (isset($id[1])) {
                    $ex = ucfirst($structuur->tabel);
                    $selfields = [];
                    foreach (Structuur::find('tabel = "' . strtolower($id[0]) . '" AND sel > 0') as $str) {
                        $selfields[] = $str->field;
                    }
                }

                foreach ($rows as $row) {
                    if (isset($id[1])) {
                        $value = $id[0]::findFirst('id' . ucfirst($id[0]) . ' = ' . $row[0]);
                        if ($value) {
                            $val = '';
                            if (count($selfields) > 0) {
                                foreach ($selfields as $f) {
                                    $val .= $value->$f . ' ';
                                }
                                $options[$row[0]] = $val;
                            } else {
                                $options[$row[0]] = $row[0];
                            }
                        } else {
                            //
                        }
                    } else {
                        $options[$row[0]] = $row[0];
                    }
                }
                $filter['value'] = [];
                $filter['values'] = $options;
                $filters[] = $filter;
            }else{
                $options = [];
                $selcolumn = Structuur::findFirst('tabel = "'.strtolower($structuur->field).'" AND sel = 1');
                $rows = $structuur->field::find();
                foreach($rows as $row)
                {
                    $id = 'id'.ucfirst($structuur->field);
                    $field = $selcolumn->field;
                    $options[$row->$id] = $row->$field;
                }

                $filter['value'] = [];
                $filter['values'] = $options;
                $filters[] = $filter;
            }
        }
        return $filters;
    }
}