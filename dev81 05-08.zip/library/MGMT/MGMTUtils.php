<?php

use Phalcon\Mvc\User\Component;
require_once 'utils/DatabaseWatcher.php';
require_once 'utils/SnippetGenerator.php';

class MGMTUtils extends Component
{
    private $generator;
    private $databasewatcher;

    public function __construct()
    {
        $this->databasewatcher = new DatabaseWatcher();
        $this->generator = new SnippetGenerator();
    }

    public function getGenerator()
    {
        return $this->generator;
    }

    public function getDatabasewatcher()
    {
        return $this->databasewatcher;
    }
}