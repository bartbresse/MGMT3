<?php

class MySQLQuery
{
    public function __construct()
    {

    }

    public function insert($table,$rows)
    {
        $rowsstring = '';
        $cc2 = 0;
        if(count($rows) > 0) {
            foreach ($rows as $row) {

                if ($cc2 > 0) {
                    $rowsstring .= ',';
                }
                $fieldsstring = '(';
                $rowsstring .= ' (';
                $cc = 0;
                foreach ($row as $index => $field) {
                    if ($cc > 0) {
                        $fieldsstring .= ', ';
                        $rowsstring .= ', ';
                    }
                    if(is_numeric($field)) {
                        $rowsstring .= $field;
                    }else{
                        $rowsstring .= '\''.$field.'\'';
                    }
                    $fieldsstring .= '`'.$index.'`';

                    $cc++;
                }
                $fieldsstring .= ')';
                $rowsstring .= ')';
                $cc2++;
            }
            return "INSERT INTO `$table` $fieldsstring VALUES $rowsstring;";
        }
    }
}