<?php
use Phalcon\Mvc\User\Component;

class ImageUtils extends Component
{
    /**
     * @param $file
     * @param $w
     * @param $h
     * @param bool $crop
     * @return resource
     *
     * $img = $this->>resize_image(‘/path/to/some/image.jpg’, 200, 200);
     */
    public function resize_image($file, $w, $h, $crop = FALSE)
    {
        list($width, $height) = getimagesize($file);
        $r = $width / $height;
        if ($crop) {
            if ($width > $height) {
                $width = ceil($width - ($width * abs($r - $w / $h)));
            } else {
                $height = ceil($height - ($height * abs($r - $w / $h)));
            }
            $newwidth = $w;
            $newheight = $h;
        } else {
            if ($w / $h > $r) {
                $newwidth = $h * $r;
                $newheight = $h;
            } else {
                $newheight = $w / $r;
                $newwidth = $w;
            }
        }

        if('gif' == pathinfo($file, PATHINFO_EXTENSION))
        {
            $src = imagecreatefromgif($file);
        }
        else{
            $src = imagecreatefromjpeg($file);
        }
        $dst = imagecreatetruecolor($newwidth, $newheight);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

        return $dst;
    }

    public function copy_image($file,$newfile)
    {
        if (!copy($file, $newfile)) {
            echo "failed to copy $file...\n";
        }
    }

    public function compress_image($source_url, $destination_url, $quality) {

        $info = getimagesize($source_url);

        if ($info['mime'] == 'image/jpeg')
            $image = imagecreatefromjpeg($source_url);

        elseif ($info['mime'] == 'image/gif')
            $image = imagecreatefromgif($source_url);

        elseif ($info['mime'] == 'image/png')
            $image = imagecreatefrompng($source_url);

        imagejpeg($image, $destination_url, $quality);
        return $destination_url;
    }
}