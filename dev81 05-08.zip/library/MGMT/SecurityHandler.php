<?php
use Phalcon\Mvc\User\Component;
use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class SecurityHandler extends Component
{
    private $payload;
    private $eigenaar;
    private $secret;

    public function __construct($getparams = false, $urlexceptions = false, $dev = false)
    {
        $this->secret = $this->globalconfig->jwt->token;
        if (!$dev) {
            try {
                $uripart = '';
                if (is_array($urlexceptions)) {
                    $uri = explode('?', $_SERVER['REQUEST_URI']);
                    $uri = explode('/token',$uri[0]);
                    $uripart = $uri[0];
                } else {
                    $urlexceptions = [];
                }

                if (in_array($uripart, $urlexceptions)) {
                    $this->eigenaar = Eigenaar::findFirst();
                } else if ($getparams == false) {
                    echo json_encode(['result' => 'unauthorized']);
                    die();
                } else {
                    $this->payload = $this->payload($getparams);
                    $this->eigenaar = Eigenaar::findFirst('idEigenaar = "' . $this->payload->idEigenaar . '"');
                }
            } catch (Exception $e) {
                echo json_encode(['result' => 'expired']);
                die();
            }
        } else {
            $eigenaar = Eigenaar::findFirst();
            $this->payload = $eigenaar->toArray();
            $this->eigenaar = $eigenaar;
        }
    }

    public function getPayload($token = false)
    {
        return $this->payload;
    }

    private function payload($token)
    {
        parse_str($token,$url_params);
        if (isset($url_params['token'])) {
            $validator = new TokenValidator();
            $validator->splitToken($url_params['token'])
                ->validateExpiration()
                ->validateSignature($this->secret);
            return json_decode($validator->getPayload());
        } else {
            return false;
        }
    }

    public function getEigenaar()
    {
        return $this->eigenaar;
    }

    public function getEigenaarID()
    {
        return $this->payload->idEigenaar;
    }
}