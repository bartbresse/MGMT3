<?php

use Phalcon\Mvc\User\Component;

class LanguageHandler extends Component
{
    private $translations;

    public function __construct($language)
    {
        $lang = $this->session->get('lang');

        if(isset($lang) && count($lang)){
            $this->translations = $lang;
        }else{
            $translations = [];
            foreach(Language::find() as $lang){
                $translations[$lang->Dutch] = $lang->$language;
            }
            $this->session->set('lang',$translations);
            $this->translations = $translations;
        }
    }

    public function translate($word)
    {
        if(!in_array($word,array_keys($this->translations))){
            $lang = new Language();
            $lang->Dutch = $word;
            if(!$lang->save()){
                print_r($lang->getMessages());
                throw new Exception("Inconsistent structure table, new Language entry could not be saved");
            }
            $this->translations[$word] = '';
            return $word;
        }else if(strlen($this->translations[$word]) < 2) {
            return $word;
        }else{
            return $this->translations[$word];
        }
    }
}