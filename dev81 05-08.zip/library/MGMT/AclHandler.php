<?php

use Phalcon\Mvc\User\Component;

class AclHandler extends Component
{
    private $eigenaar;

    public $rightsPerRow;

    public function __construct($eigenaar)
    {
        $this->eigenaar = $eigenaar;
    }

    public function getRights(EntityInfo $ei)
    {
        $rights = ['create' => 0, 'read' => 0, 'update' => 0, 'delete' => 0,'rol' => intval($this->eigenaar->Rol_idRol)];

        $acl = Acl::findfirst('Eigenaar_idEigenaar = ' . $this->eigenaar->idEigenaar . ' AND Structuurtable_idStructuurtable = ' . $ei->structuurtable->idstructuurtable . ' AND Entityid = ' . $ei->entityrowid . '');
        if (!$acl) {
            if ($this->eigenaar->Rol_idRol < 3) {
                $rights = ['create' => 1, 'read' => 1, 'update' => 1, 'delete' => 1,'rol' => intval($this->eigenaar->Rol_idRol)];
            } else if ($this->eigenaar->Rol_idRol == 3) {
                $rights = ['create' => 0, 'read' => 1, 'update' => 0, 'delete' => 0,'rol' => intval($this->eigenaar->Rol_idRol)];
            }
        } else {
            if ($this->eigenaar->Rol_idRol < 3) {
                $rights = ['create' => 1, 'read' => 1, 'update' => 1, 'delete' => 1,'rol' => intval($this->eigenaar->Rol_idRol)];
            } else if ($this->eigenaar->Rol_idRol == 3) {
                $rights = ['create' => 0, 'read' => 1, 'update' => 0, 'delete' => 0,'rol' => intval($this->eigenaar->Rol_idRol)];
            }else{

                $rights = ['create' => intval($acl->Create), 'read' => intval($acl->Read), 'update' => intval($acl->Update), 'delete' => intval($acl->Delete),'rol' => intval($this->eigenaar->Rol_idRol)];
            }
        }

        $rights['admin'] = 0;
        $rights['nonadmin'] = 0;

        foreach(Eigenaar::find() as $index => $eigenaar)
        {
            if($eigenaar->Rol_idRol > 1) {
                $rights['nonadmin']++;
            }else{
                $rights['admin']++;
            }
        }
        $this->rightsPerRow = [$rights];
        return $rights;
    }

    public function getAllowedRowsQuery(EntityInfo $ei, $query = false)
    {
        $this->rightsPerRow = [];
        if(!$query) {
            $query = '';
        }
        $structuurtable = Structuurtable::findFirst('sqltable = "' . $ei->tablename . '"');
        if ($this->eigenaar->Rol_idRol > 3) {
            $rightsPerRow = [];
            $acl = Acl::find('Eigenaar_idEigenaar = "' . $this->eigenaar->idEigenaar . '" AND Structuurtable_idStructuurtable = "' . $structuurtable->idstructuurtable . '"');
            if (!$acl) {
                return false;
            }

            $query .= '( ';
            //LOOP THROUGH ALL ENTITIES
            foreach ($acl as $index => $value) {
                if ($index > 0) {
                    $query .= ' OR ';
                }

                $rightsPerRow[$value->Entityid] = ['create' => $value->Create, 'read' => $value->Read, 'update' => $value->Update, 'delete' => $value->Delete];
                $query .= ' id' . $ei->entityname . ' = ' . $value->Entityid;
            }
            $query .= ' ) ';
            if (strlen($query) < 10) {
                $query = false;
            }

        } else if ($this->eigenaar->Rol_idRol == 3) {
            $rightsPerRow[0] = ['create' => 0, 'read' => 1, 'update' => 0, 'delete' => 0];
            $query = false;
        } else {
            $rightsPerRow[0] = ['create' => 1, 'read' => 1, 'update' => 1, 'delete' => 1];
        }
        $this->rightsPerRow = $rightsPerRow;

        return $query;

    }
}