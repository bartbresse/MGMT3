<?php

use Phalcon\Mvc\User\Component;

class EmailHandler extends Component
{
    private $recipients;
    private $cc;
    private $bcc;

    public function __construct()
    {
        $this->recipients = [];
        $this->cc = [];
        $this->bcc = [];
        $this->defaulttemplate = '<!doctype html><html><head> <meta name="viewport" content="width=device-width"> <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <link href="https://fonts.googleapis.com/css?family=Raleway:300" rel="stylesheet"> <title>[title]</title> <style>a, a:visited{color: #0385D0; text-decoration: none; cursor: pointer}.ewf-btn{background-color: #0385D0; box-shadow: inset 0 0 0 2px #0385D0; color: #fff; position: relative; background-clip: padding-box; display: inline-block; min-width: 110px; padding: 6px 13px; border-radius: 21px; margin-bottom: 26px; text-align: center; text-decoration: none; cursor: pointer; appearance: none; transition: .3s all ease}a{color: #00BCD4}.ewf-btn{background-color: #86c3c6; -webkit-box-shadow: inset 0 0 0 2px #86c3c6; box-shadow: inset 0 0 0 2px #86c3c6}.headline h3{margin-bottom: 55px; z-index: 9; margin-top: 0; animation: anim_affluent_sliderPro_category 1000ms linear both; animation-delay: 400ms; font-size: 30px; font-weight: 300}.headline h3{font-family: Raleway; font-size: 30px; line-height: 28px}@media only screen and (max-width: 620px){table[class=body] h1{font-size: 28px !important; margin-bottom: 10px !important}table[class=body] p, table[class=body] ul, table[class=body] ol, table[class=body] td, table[class=body] span, table[class=body] a{font-size: 16px !important}table[class=body] .wrapper, table[class=body] .article{padding: 10px !important}table[class=body] .content{padding: 0 !important}table[class=body] .container{padding: 0 !important; width: 100% !important}table[class=body] .main{border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important}table[class=body] .btn table{width: 100% !important}table[class=body] .btn a{width: 100% !important}table[class=body] .img-responsive{height: auto !important; max-width: 100% !important; width: auto !important}}@media all{.ExternalClass{width: 100%}.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div{line-height: 100%}.apple-link a{color: inherit !important; font-family: inherit !important; font-size: inherit !important; font-weight: inherit !important; line-height: inherit !important; text-decoration: none !important}.btn-primary table td:hover{background-color: #34495e !important}.btn-primary a:hover{background-color: #34495e !important; border-color: #34495e !important}}</style></head><body class="" style="background-color: #f6f6f6; font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; line-height: 1.4; margin: 0; padding: 0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;"><table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background-color: #f6f6f6;"> <tr> <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">&nbsp;</td><td class="container" style="font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; Margin: 0 auto; max-width: 580px; padding: 10px; width: 580px;"> <div class="content" style="box-sizing: border-box; display: block; Margin: 0 auto; max-width: 580px; padding: 10px;"><span class="preheader" style="color: transparent; display: none; height: 0; max-height: 0; max-width: 0; opacity: 0; overflow: hidden; mso-hide: all; visibility: hidden; width: 0;">[title]</span> <table class="main" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #ffffff; border-radius: 3px;"> <tr> <td class="wrapper" style="font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;"> <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;"> <tr> <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;"><img width="200px" src="{{logo}}" alt=""/> <br/><br/> <p>[content]</p><br/><br/><br/><br/></td></tr></table> </td></tr><tr> <td style="background-color: deepskyblue;">&nbsp;</td></tr><tr> <td style="background-color: indigo;">&nbsp;</td></tr></table> <div class="footer" style="clear: both; Margin-top: 10px; text-align: center; width: 100%;"> <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;"> <tr></tr><tr> <td class="content-block powered-by" style="font-family: sans-serif; vertical-align: top; padding-bottom: 10px; padding-top: 10px; font-size: 12px; color: #999999; text-align: center;"> &copy;webshop 2019. </td></tr><tr> <td class="content-block powered-by" style="font-family: sans-serif; vertical-align: top; padding-bottom: 10px; padding-top: 10px; font-size: 12px; color: #999999; text-align: center;"> <p>Dit e-mailbericht is uitsluitend bestemd voor de geadresseerde. Als dit bericht niet voor u bestemd is, wordt u vriendelijk verzocht dit aan de afzender te melden.<br/> contractmanager.eu staat door de elektronische verzending van dit bericht niet in voor de juiste en volledige overbrenging van de inhoud, noch voor tijdige ontvangst daarvan. Voor informatie over voorwaarden raadpleegt u dev31.2sonder.com/legal.</p></td></tr><tr> <td class="content-block powered-by" style="font-family: sans-serif; vertical-align: top; padding-bottom: 10px; padding-top: 10px; font-size: 12px; color: #999999; text-align: center;"> </td></tr></table> </div></div></td><td style="font-family: sans-serif; font-size: 14px; vertical-align: top;">&nbsp;</td></tr></table></body></html>';
    }

    public function setTemplate($name,$data)
    {
        $template = Template::findFirst('Name = "'.$name.'"');
        $atemplate = $template->toArray();

        $str = str_replace('[content]',$atemplate['Html'],$this->defaulttemplate);
        foreach($data as $index => $item)
        {
            $str = str_replace($index,$item,$str);
        }
        $atemplate['Html'] = $str;

        $str = $atemplate['Plaintext'];
        foreach($data as $index => $item)
        {
            $str = str_replace($index,$item,$str);
        }
        $atemplate['Plaintext'] = $str;

        $str = $atemplate['Subject'];
        foreach($data as $index => $item)
        {
            $str = str_replace($index,$item,$str);
        }
        $atemplate['Subject'] = $str;


        $this->template = $atemplate;
    }

    public function addEmail($name, $email, $type)
    {
        $this->$type[] = [
            'address' => [
                'name' => $name,
                'email' => $email,
            ],
        ];
    }

    public function send($subject = false, $html = false, $text = false)
    {
        if(strlen($this->template['Html']) > 0)
        {
            $html = $this->template['Html'];
            $text = $this->template['Plaintext'];
            $subject = $this->template['Subject'];
        }

        try {
            $this->sparkpost->setOptions(['async' => false]);
            $base = [
                'content' => [
                    'from' => [
                        'name' => $this->globalconfig->email->name,
                        'email' => $this->globalconfig->email->email,
                    ],
                    'subject' => $subject,
                    'html' => $html,
                    'text' => $text,
                ],
                'recipients' => $this->recipients,
            ];


            if (count($this->cc) > 0) {
                $base['cc'] = $this->cc;
            }
            if (count($this->bcc) > 0) {
                $base['bcc'] = $this->bcc;
            }
            $response = $this->sparkpost->transmissions->post($base);

          //  echo $response->getStatusCode() . "\n";
          //  print_r($response->getBody()) . "\n";
        } catch (\Exception $e) {
         //   echo $e->getCode() . "\n";
         //   echo $e->getMessage() . "\n";
        }
    }
}