<?php session_start();

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    die();
}

$url = explode('/', $_GET['_url']);

$request_body = json_decode(file_get_contents('php://input'), true);
if (isset($request_body['data'])) {
    $cookies = [];
    foreach (explode('&', $request_body['data']['token']) as $cookie) {
        $lang = explode('=', $cookie);
        if (isset($lang[1])) {
            $cookies[$lang[0]] = $lang[1];
        }
    }
}

if (isset($_GET['database'])) {
    $database = $_GET['database'];
} else if (isset($cookies['database'])) {
    $database = $cookies['database'];
} else if (isset($_COOKIE['db'])) {
    //  print_r($_COOKIE);

    $database = $_COOKIE['db'];
} else if (isset($url[2]) && strlen($url[2]) > 2 && $url[2] != 'placekey') {
    $database = $url[2];
    setcookie("db", $url[2]);
    $_SESSION['db'] = $url[2];
} else if (isset($_POST['db'])) {
    $database = $_POST['db'];
} else if(isset($_SESSION['db'])) {
    $database = $_SESSION['db'];
}
$database = 'cmx15';
if(!isset($database))
{
    $database = 'cmx15';
}


defined('BASE_PATH') || define('BASE_PATH', getenv('BASE_PATH') ?: realpath(dirname(__FILE__) . '/../..'));
defined('APP_PATH') || define('APP_PATH', BASE_PATH . '/app');

return new \Phalcon\Config([
    'globalconfig' => [
        'host' => 'localhost',

        'database' => [
          
            'consistency' => false //When foreign keys are not defined, for example because you are connecting views. MGMT can't find all relations. false consistency means that we use the code
        ],
        'formmessages' => [
            'unique' => "This value is already in the database.",
            'empty' => "This field needs to be filled in."
        ],
        'jwt' => [
            'token' => '3k?H&Y;(W[39BTqU+<!j!<`m30w|$*'
        ],
        'imagesizes' => [
            'small' => ['x' => 260,'y' => 260],
            'medium' => ['x' => 500,'y' => 500],
            'large' => ['x' => 1200,'y' => 1200],
            'full' => []
        ],
        'security' => [
            ''
        ]
    ],
    'database' => [

    ],
    'application' => [
        'appDir' => APP_PATH . '/',
        'controllersDir' => APP_PATH . '/controllers/',
        'modelsDir' => APP_PATH . '/models/',
        'migrationsDir' => APP_PATH . '/migrations/',
        'viewsDir' => APP_PATH . '/views/',
        'pluginsDir' => APP_PATH . '/plugins/',
        'libraryDir' => APP_PATH . '/library/',
        'logicDir' => APP_PATH . '/library/bussinesslogic/',
        'mgmtDir' => APP_PATH . '/library/MGMT/',
        'cacheDir' => BASE_PATH . '/cache/',
        'emailDir' => BASE_PATH . '/emails/',
        'baseUri' => preg_replace('/public([\/\\\\])index.php$/', '', $_SERVER["PHP_SELF"]),
    ]
]);
