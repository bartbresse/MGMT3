<?php

require APP_PATH . "/../vendor/autoload.php";

use Phalcon\Mvc\View;
use Phalcon\Mvc\View\Engine\Php as PhpEngine;
use Phalcon\Mvc\Url as UrlResolver;
use Phalcon\Mvc\View\Engine\Volt as VoltEngine;
use Phalcon\Mvc\Model\Metadata\Memory as MetaDataAdapter;
use Phalcon\Session\Adapter\Files as SessionAdapter;
use Phalcon\Flash\Direct as Flash;

use SparkPost\SparkPost;
use GuzzleHttp\Client;
use Http\Adapter\Guzzle6\Client as GuzzleAdapter;

/**
 * Shared configuration service
 */
$di->setShared('config', function () {
    return include APP_PATH . "/config/config.php";
});

/**
 * The URL component is used to generate all kind of urls in the application
 */
$di->setShared('url', function () {
    $config = $this->getConfig();

    $url = new UrlResolver();
    $url->setBaseUri($config->application->baseUri);

    return $url;
});

$di->setShared('mgmt', function () {
    $request_body = json_decode(file_get_contents('php://input'), true);
    $token = explode('token=',$_GET['_url']);
    if (isset($_POST['token'])) {
        $request_body['data']['token'] = $_POST['token'];
    } else if ($_GET['_url'] && isset($token[1])) {
        $request_body['data']['token'] = $token[1];
    }

    if (!isset($request_body['data']['appdata'])) {
        $request_body['data']['appdata'] = false;
    }

    $mgmt = new MGMT(false, $request_body['data']['appdata']);
    $mgmt->setSecurityToken($request_body['data']['token'], ['/cron', '/file/ckeditor', '/mgmt/file']);
    return $mgmt;
});
$di->setShared('audit', function () {
    return new AuditHandler();
});
$di->setShared('sparkpost', function () {
    $httpClient = new GuzzleAdapter(new Client());
    return new SparkPost($httpClient, ['key' => '1613330ace8cff8dd4b8fa94e98858b574a8a428']);
});
/**
 * Setting up the view component
 */

$di->set('router', function () {

    $router = new \Phalcon\Mvc\Router(false);
    $router->notFound(array(
        "controller" => "error",
        "action" => "route404"
    ));

    $router->add('/mgmt/get/{entityname}', ['controller' => 'mgmt', 'action' => 'get']);
    $router->add('/mgmt/post/{entity}', ['controller' => 'mgmt', 'action' => 'post']);
    $router->add('/mgmt/post/{entity}/{id}', ['controller' => 'mgmt', 'action' => 'post']);
    $router->add('/mgmt/form/{slug}', ['controller' => 'mgmt', 'action' => 'form']);
    $router->add('/mgmt/form/{slug}/{id}', ['controller' => 'mgmt', 'action' => 'form']);
    $router->add('/mgmt/cron', ['controller' => 'mgmt', 'action' => 'cron']);
    $router->add('/mgmt/view/{slug}', ['controller' => 'mgmt', 'action' => 'view']);
    $router->add('/mgmt/view/{slug}/{id}', ['controller' => 'mgmt', 'action' => 'view']);
    $router->add('/mgmt/detail/{slug}', ['controller' => 'mgmt', 'action' => 'detail']);
    $router->add('/mgmt/detail/{slug}/{id}', ['controller' => 'mgmt', 'action' => 'detail']);
    $router->add('/mgmt/getaudit/{entity}/{id}', ['controller' => 'mgmt', 'action' => 'getaudit']);
    $router->add('/mgmt/postaudit/{entity}/{id}', ['controller' => 'mgmt', 'action' => 'postaudit']);
    $router->add('/mgmt/file/{token}', ['controller' => 'mgmt', 'action' => 'file']);
    $router->add('/mgmt/auth/', ['controller' => 'mgmt', 'action' => 'auth']);


    $router->add('/mgmt/signout/', ['controller' => 'mgmt', 'action' => 'signout']);


    $router->add('/form/register', ['controller' => 'form', 'action' => 'register']);
    $router->add('/import/', ['controller' => 'import', 'action' => 'show']);
    $router->add('/import/csv/{gegevens}', ['controller' => 'import', 'action' => 'csv']);

    $router->add('/auth/forgotten/', ['controller' => 'auth', 'action' => 'forgotten']);
    $router->add('/auth/validate/{code}', ['controller' => 'auth', 'action' => 'validate']);
    $router->add('/autoauth/{db}/', ['controller' => 'autoauth', 'action' => 'index']);
    $router->add('/autoauth/placekey/', ['controller' => 'autoauth', 'action' => 'placekey']);
    $router->add('/feed', ['controller' => 'feed', 'action' => 'index']);
    $router->add('/delete/{entity}/{id}', ['controller' => 'delete', 'action' => 'show']);
    $router->add('/edit/{entity}/{id}', ['controller' => 'edit', 'action' => 'show']);
    $router->add('/file/ckeditor', ['controller' => 'file', 'action' => 'ckeditor']);
    $router->add('/chart', ['controller' => 'chart', 'action' => 'index']);
    $router->add('/taak/changestatus', ['controller' => 'taak', 'action' => 'changestatus']);
    $router->add('/addto', ['controller' => 'addto', 'action' => 'index']);
    $router->add('/addto/{slug}/{slug2}/{id}', ['controller' => 'addto', 'action' => 'index']);

    $router->add('/test', ['controller' => 'test', 'action' => 'show']);
    $router->add('/test/mgmtutils', ['controller' => 'test', 'action' => 'mgmtutils']);
    $router->add('/test/generator/{id}', ['controller' => 'test', 'action' => 'generator']);
    $router->add('/test/dbupdate', ['controller' => 'test', 'action' => 'dbupdate']);


    $router->add('/csv/{entity}', ['controller' => 'csv', 'action' => 'show']);
    $router->add('/update', ['controller' => 'update', 'action' => 'show']);
    $router->add('/charting', ['controller' => 'charting', 'action' => 'show']);
    $router->add('/charting/{year}', ['controller' => 'charting', 'action' => 'show']);
    $router->add('/access/{entity}/{id}', ['controller' => 'access', 'action' => 'index']);
    $router->add('/access/store/{entity}/{id}', ['controller' => 'access', 'action' => 'store']);
    $router->add('/user/changeUser', ['controller' => 'user', 'action' => 'changeUser']);
    $router->add('/settings/store', ['controller' => 'settings', 'action' => 'store']);
    $router->add('/settings/form', ['controller' => 'settings', 'action' => 'form']);

    $router->add('/contractstatus', ['controller' => 'contractstatus', 'action' => 'show']);
    $router->add('/finoverzicht', ['controller' => 'finoverzicht', 'action' => 'show']);

    $router->add('/contract/gethighestcontractnumbertoday', ['controller' => 'contract', 'action' => 'gethighestcontractnumbertoday']);

    $router->add('/trigger/get/{id}', ['controller' => 'trigger', 'action' => 'get']);
    $router->add('/trigger/save/{id}', ['controller' => 'trigger', 'action' => 'save']);
    $router->add('/trigger/save/', ['controller' => 'trigger', 'action' => 'save']);

    $router->add('/battleship/getgrid/', ['controller' => 'battleship', 'action' => 'getgrid']);
    $router->add('/battleship/storegrid/', ['controller' => 'battleship', 'action' => 'storegrid']);

    $router->add('/database/start', ['controller' => 'database', 'action' => 'start']);

    $router->add('/export/print/{entity}/{params}', ['controller' => 'export', 'action' => 'print']);
    $router->add('/export/csv/{entity}/{params}', ['controller' => 'export', 'action' => 'csv']);

    return $router;
});

$di->setShared('view', function () {
    $config = $this->getConfig();

    $view = new View();
    $view->setDI($this);
    $view->setViewsDir($config->application->viewsDir);

    $view->registerEngines([
        '.volt' => function ($view) {
            $config = $this->getConfig();

            $volt = new VoltEngine($view, $this);

            $volt->setOptions([
                'compiledPath' => $config->application->cacheDir,
                'compiledSeparator' => '_'
            ]);

            return $volt;
        },
        '.phtml' => PhpEngine::class

    ]);

    return $view;
});

/**
 * Database connection is created based in the parameters defined in the configuration file
 */

use Phalcon\Db\Profiler as ProfilerDb;
use Phalcon\Events\Manager as EventsManager;
use Phalcon\Db\Adapter\Pdo\Mysql as MysqlPdo;


$di->set('profiler', function () {
    return new ProfilerDb();
}, true);


$di->setShared('db', function () {

    $eventsManager = new EventsManager();

    // Get a shared instance of the DbProfiler
    $profiler = $this->getProfiler();

    // Listen all the database events
    $eventsManager->attach('db', function ($event, $connection) use ($profiler) {
        if ($event->getType() == 'beforeQuery') {
            $profiler->startProfile($connection->getSQLStatement());
        }

        if ($event->getType() == 'afterQuery') {
            $profiler->stopProfile();
        }
    });


    $config = $this->getConfig();

    $class = 'Phalcon\Db\Adapter\Pdo\\' . $config->database->adapter;
    $params = [
        'host' => $config->database->host,
        'username' => $config->database->username,
        'password' => $config->database->password,
        'dbname' => $config->database->dbname,
        'charset' => $config->database->charset
    ];

    if ($config->database->adapter == 'Postgresql') {
        unset($params['charset']);
    }

    $connection = new $class($params);

    $connection->setEventsManager($eventsManager);

    return $connection;
});

//TODO: replace all settings with global settings
$di->setShared('globalconfig', function () {
    $config = $this->getConfig();
    return $config->globalconfig;
});

/**
 * If the configuration specify the use of metadata adapter use it or use memory otherwise
 */
$di->setShared('modelsMetadata', function () {
    return new MetaDataAdapter();
});

/**
 * Register the session flash service with the Twitter Bootstrap classes
 */
$di->set('flash', function () {
    return new Flash([
        'error' => 'alert alert-danger',
        'success' => 'alert alert-success',
        'notice' => 'alert alert-info',
        'warning' => 'alert alert-warning'
    ]);
});

/**
 * Start the session the first time some component request the session service
 */
$di->setShared('session', function () {
    $session = new SessionAdapter();
    $session->start();
    return $session;
});


$di->setShared('curl', function () {
    return new Curl();
});


