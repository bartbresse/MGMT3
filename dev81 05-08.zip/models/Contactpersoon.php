<?php

class Contactpersoon extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idContactpersoon;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Voornaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Achternaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Email;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Telefoon;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Mobiel;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Relatie_idRelatie;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->belongsTo('Relatie_idRelatie', '\Relatie', 'idRelatie', ['alias' => 'Relatie']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'contactpersoon';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Contactpersoon[]|Contactpersoon
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Contactpersoon
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
