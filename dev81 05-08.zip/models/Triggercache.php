<?php

class Triggercache extends \Phalcon\Mvc\Model
{

}