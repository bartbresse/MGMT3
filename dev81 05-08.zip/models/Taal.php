<?php

class Taal extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idTaal;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Code;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idTaal', 'Eigenaar', 'Taal_idTaal', ['alias' => 'Eigenaar']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'taal';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Taal[]|Taal
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Taal
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
