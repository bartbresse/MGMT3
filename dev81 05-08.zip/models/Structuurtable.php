<?php

class Structuurtable extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idstructuurtable;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $title;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $description;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $sqltable;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $savebuttontext;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $cancelbuttontext;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $fieldsinform;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('idstructuurtable', 'Audit', 'Structuurtable_idStructuurtable', ['alias' => 'Audit']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'structuurtable';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Structuurtable[]|Structuurtable
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Structuurtable
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
