<?php

class Contract extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idContract;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Nummer;

    /**
     *
     * @var string
     * @Column(type="string", length=245, nullable=true)
     */
    public $Nummerklant;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Begindatum;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Onbepaaldetijd;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $Contractduur;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Einddatum;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $Opzegtermijn;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Laatsteopzegdatum;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Verlenging;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Contractstatus_idContractstatus;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Relatie_idRelatie;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Updatedat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Medewerker_idMedewerker;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Document_idDocument1;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Document_idDocument2;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Document_idDocument3;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Adres_idAdres;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $Verlengtermijn;

    /**
     *
     * @var integer
     * @Column(type="integer", length=1, nullable=true)
     */
    public $Automatischeverlenging;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $Maximaleverlengingsperiode;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Triggers;

    /**
     *
     * @var double
     * @Column(type="double", length=11, nullable=true)
     */
    public $Jaarwaarde;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->hasMany('idContract', 'ContractHasContractsoort', 'Contract_idContract', ['alias' => 'ContractHasContractsoort']);
        $this->hasMany('idContract', 'ContractHasGegevens', 'Contract_idContract', ['alias' => 'ContractHasGegevens']);
        $this->hasMany('idContract', 'DocumentHasContract', 'Contract_idContract', ['alias' => 'DocumentHasContract']);
        $this->hasMany('idContract', 'Onderwerp', 'Contract_idContract', ['alias' => 'Onderwerp']);
        $this->hasMany('idContract', 'Positie', 'Contract_idContract', ['alias' => 'Positie']);
        $this->hasMany('idContract', 'Taak', 'Contract_idContract', ['alias' => 'Taak']);
        $this->belongsTo('Adres_idAdres', '\Adres', 'idAdres', ['alias' => 'Adres']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
        $this->belongsTo('Relatie_idRelatie', '\Relatie', 'idRelatie', ['alias' => 'Relatie']);
        $this->belongsTo('Document_idDocument2', '\Document', 'idDocument', ['alias' => 'Document']);
        $this->belongsTo('Document_idDocument1', '\Document', 'idDocument', ['alias' => 'Document']);
        $this->belongsTo('Document_idDocument3', '\Document', 'idDocument', ['alias' => 'Document']);
        $this->belongsTo('Medewerker_idMedewerker', '\Medewerker', 'idMedewerker', ['alias' => 'Medewerker']);
        $this->belongsTo('Contractstatus_idContractstatus', '\Contractstatus', 'idContractstatus', ['alias' => 'Contractstatus']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'contract';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Contract[]|Contract
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Contract
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
