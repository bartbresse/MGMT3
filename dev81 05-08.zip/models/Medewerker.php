<?php

class Medewerker extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idMedewerker;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Voornaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Achternaam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Email;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Telefoon;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Adres_idAdres;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idMedewerker', 'Contract', 'Medewerker_idMedewerker', ['alias' => 'Contract']);
        $this->belongsTo('Adres_idAdres', '\Adres', 'idAdres', ['alias' => 'Adres']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'medewerker';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Medewerker[]|Medewerker
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Medewerker
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
