<?php

class Onderwerp extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idOnderwerp;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Beschrijving;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Opmerkingen;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Contract_idContract;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idOnderwerp', 'GegevensHasOnderwerp', 'Onderwerp_idOnderwerp', ['alias' => 'GegevensHasOnderwerp']);
        $this->hasMany('idOnderwerp', 'OnderwerpHasDocument', 'Onderwerp_idOnderwerp', ['alias' => 'OnderwerpHasDocument']);
        $this->hasMany('idOnderwerp', 'Taak', 'Onderwerp_idOnderwerp', ['alias' => 'Taak']);
        $this->belongsTo('Contract_idContract', '\Contract', 'idContract', ['alias' => 'Contract']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'onderwerp';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Onderwerp[]|Onderwerp
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Onderwerp
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
