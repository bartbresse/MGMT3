<?php

class Contractsoort extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idContractsoort;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Beschrijving;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Contractsoort_idContractsoort;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_cmx15");
        $this->hasMany('idContractsoort', 'ContractHasContractsoort', 'Contractsoort_idContractsoort', ['alias' => 'ContractHasContractsoort']);
        $this->hasMany('idContractsoort', 'Contractsoort', 'Contractsoort_idContractsoort', ['alias' => 'Contractsoort']);
        $this->hasMany('idContractsoort', 'ContractsoortHasTrigger', 'Contractsoort_idContractsoort', ['alias' => 'ContractsoortHasTrigger']);
        $this->hasMany('idContractsoort', 'Positie', 'Contractsoort_idContractsoort', ['alias' => 'Positie']);
        $this->belongsTo('Contractsoort_idContractsoort', '\Contractsoort', 'idContractsoort', ['alias' => 'Contractsoort']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'contractsoort';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Contractsoort[]|Contractsoort
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Contractsoort
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
