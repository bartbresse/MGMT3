<?php

class Land extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idLand;

    /**
     *
     * @var string
     * @Column(type="string", length=5, nullable=false)
     */
    public $Code;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Taal;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('idLand', 'Relatie', 'Land_idLand', ['alias' => 'Relatie']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'land';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Land[]|Land
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Land
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
