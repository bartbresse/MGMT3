<?php

class Adres extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idAdres;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Straat;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Huisnummer;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Postcode;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Plaats;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idAdres', 'Contract', 'Adres_idAdres', ['alias' => 'Contract']);
        $this->hasMany('idAdres', 'Medewerker', 'Adres_idAdres', ['alias' => 'Medewerker']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'adres';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Adres[]|Adres
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Adres
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
