<?php

class Audit extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idAudit;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Oldrow;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Newrow;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Structuurtable_idStructuurtable;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Entityid;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Lastedit;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Action;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
        $this->belongsTo('Structuurtable_idStructuurtable', '\Structuurtable', 'idstructuurtable', ['alias' => 'Structuurtable']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'audit';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Audit[]|Audit
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Audit
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
