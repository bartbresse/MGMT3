<?php

class OnderwerpHasDocument extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Onderwerp_idOnderwerp;

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Document_idDocument;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->belongsTo('Document_idDocument', '\Document', 'idDocument', ['alias' => 'Document']);
        $this->belongsTo('Onderwerp_idOnderwerp', '\Onderwerp', 'idOnderwerp', ['alias' => 'Onderwerp']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'onderwerp_has_document';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return OnderwerpHasDocument[]|OnderwerpHasDocument
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return OnderwerpHasDocument
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
