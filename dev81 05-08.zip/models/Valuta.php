<?php

class Valuta extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idValuta;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Code;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Naam;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSchema("sonder_dev76b");
        $this->hasMany('idValuta', 'Gegevens', 'Valuta_idValuta', ['alias' => 'Gegevens']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'valuta';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Valuta[]|Valuta
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Valuta
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
