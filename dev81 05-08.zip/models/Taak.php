<?php

class Taak extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(type="integer", length=11, nullable=false)
     */
    public $idTaak;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=false)
     */
    public $Naam;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Beschrijving;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Einddatum;

    /**
     *
     * @var string
     * @Column(type="string", length=45, nullable=true)
     */
    public $Notificatiedatum;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Taakstatus_idTaakstatus;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Prioriteit_idPrioriteit;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Eigenaar_idEigenaar;

    /**
     *
     * @var integer
     * @Column(type="integer", length=4, nullable=true)
     */
    public $Einddatumtaak;

    /**
     *
     * @var integer
     * @Column(type="integer", length=4, nullable=true)
     */
    public $Herhaald;

    /**
     *
     * @var string
     * @Column(type="string", length=255, nullable=true)
     */
    public $Herhaalelke;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Eindatumherhaal;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Contract_idContract;

    /**
     *
     * @var integer
     * @Column(type="integer", length=11, nullable=true)
     */
    public $Onderwerp_idOnderwerp;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Createdat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=false)
     */
    public $Updatedat;

    /**
     *
     * @var string
     * @Column(type="string", nullable=true)
     */
    public $Deletedat;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->hasMany('idTaak', 'TaakHasDocument', 'Taak_idTaak', ['alias' => 'TaakHasDocument']);
        $this->hasMany('idTaak', 'TaakHasGegevens', 'Taak_idTaak', ['alias' => 'TaakHasGegevens']);
        $this->belongsTo('Eigenaar_idEigenaar', '\Eigenaar', 'idEigenaar', ['alias' => 'Eigenaar']);
        $this->belongsTo('Prioriteit_idPrioriteit', '\Prioriteit', 'idPrioriteit', ['alias' => 'Prioriteit']);
        $this->belongsTo('Taakstatus_idTaakstatus', '\Taakstatus', 'idTaakstatus', ['alias' => 'Taakstatus']);
        $this->belongsTo('Contract_idContract', '\Contract', 'idContract', ['alias' => 'Contract']);
        $this->belongsTo('Onderwerp_idOnderwerp', '\Onderwerp', 'idOnderwerp', ['alias' => 'Onderwerp']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'taak';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Taak[]|Taak
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Taak
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
