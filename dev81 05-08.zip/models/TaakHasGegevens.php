<?php

class TaakHasGegevens extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Taak_idTaak;

    /**
     *
     * @var integer
     * @Primary
     * @Column(type="integer", length=11, nullable=false)
     */
    public $Gegevens_idGegevens;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        //$this->setSchema("sonder_cmx15");
        $this->belongsTo('Gegevens_idGegevens', '\Gegevens', 'idGegevens', ['alias' => 'Gegevens']);
        $this->belongsTo('Taak_idTaak', '\Taak', 'idTaak', ['alias' => 'Taak']);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'taak_has_gegevens';
    }

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return TaakHasGegevens[]|TaakHasGegevens
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return TaakHasGegevens
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
