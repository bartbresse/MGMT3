<?php

class ContractController extends ControllerBase
{
    public function indexAction()
    {

    }

    public function gethighestcontractnumbertodayAction()
    {
        $contract = Contract::findFirst(['conditions' => 'DATE(Createdat) = CURDATE()', 'order' => 'idContract DESC']);
        if (!$contract) {
            $highestnumber = '001';
        } else {
            $nummer = substr($contract->Nummer, -3);
            $nummer = (intval($nummer) + 1);
            $format = str_pad($nummer, 3, '0', STR_PAD_LEFT);
            $highestnumber = $format;
        }
        echo json_encode(['highestnumber' => $highestnumber], JSON_UNESCAPED_SLASHES);
    }
}