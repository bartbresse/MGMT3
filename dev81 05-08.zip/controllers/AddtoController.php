<?php

class AddtoController extends ControllerBase
{
    public function indexAction()
    {
    	error_reporting(0);
    	ini_set('display_errors', 0);

        $request_body = json_decode(file_get_contents('php://input'), true);

		$urlParts = explode('/', trim($_GET['_url'], '/'));
		$entityToAdd = '';
		$entityId = '';

		if(isset($_GET['entity2']) and $_GET['entity2'] != ''){
			$entity = ucfirst($_GET['entity2']);
			$entityToAdd = ucfirst($_GET['entity1']);
			$entityId = ucfirst($_GET['id']);
		} else if(isset($urlParts['2']) and $urlParts['2'] != ''){
			$entity = ucfirst($urlParts['2']);
			$entityToAdd = ucfirst($urlParts['1']);
			$entityId = ucfirst($urlParts['3']);
		}

        if ($entity == 'Contract') {

		    $errors = 0;

			if($entityToAdd == 'Onderwerp'){
				foreach ($request_body['data'] as $data) {
					$onderwerp = new Onderwerp();
					$onderwerp->Naam = $data['Naam'];
					$onderwerp->idContract = $entityId;
					$onderwerp->Beschrijving = $data['Beschrijving'];
					$onderwerp->Opmerkingen = $data['Opmerkingen'];
					$onderwerp->Toevoegdatum = date('Y-m-d', strtotime($data['Toevoegdatum']));
					$onderwerp->idEigenaar = $data['idEigenaar'];
					if (!$onderwerp->save()) {
					    $errors++;
						echo json_encode(['result' => 'failure']);
					}
				}
			}
			elseif($entityToAdd == 'Taak'){
				foreach ($request_body['data'] as $data) {
					$taak = new Taak();
					$taak->contract_idContract = $data['contract_idContract'];
					$taak->Naam = $data['Naam'];
					$taak->Beschrijving = $data['Beschrijving'];
					$taak->Einddatum = $data['Einddatum'];
					$taak->Notificatiedatum = date('Y-m-d', strtotime($data['Notificatiedatum']));
					$taak->Taakstatus_idTaakstatus = $data['Taakstatus_idTaakstatus'];
					$taak->Prioriteit_idPrioriteit = $data['Prioriteit_idPrioriteit'];
					$taak->Eigenaar_idEigenaar = $data['Eigenaar_idEigenaar'];
					$taak->einddatumtaak = date('Y-m-d', strtotime($data['einddatumtaak']));
					$taak->Onderwerp_idOnderwerp = $data['Onderwerp_idOnderwerp'];
					if (!$taak->save()) {
					    $errors++;
                        echo json_encode(['result' => 'failure']);
					}
				}
			}

            if($errors == 0)
            {
                echo json_encode(['result' => 'succes']);
                die();
            }
        }
        if ($entity == 'Dossier') {
            foreach ($request_body['data'] as $data) {
                $contract = Contract::findFirst('idContract = "' . $data['idContract'] . '"');

                $chd = new ContractHasDossier();
                $chd->Contract_idContract = $contract->idContract;
                $chd->Dossier_idDossier = $_GET['id'];
                if (!$chd->save()) {
                    print_r($chd->getMessages());
					echo json_encode(['result' => 'failure']);
					die();
                } else {

				}
            }
            echo json_encode(['result' => 'succes']);
            die();
        }

    }
}