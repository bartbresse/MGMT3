<?php

class AccessController extends ControllerBase
{
    public function indexAction($entity, $id)
    {
        $users = [];
        $structuurtable = Structuurtable::findFirst('sqltable = "' . $entity . '"');

        $eigenaars = [];
        foreach (Eigenaar::find('Rol_idRol > 3') as $eigenaar) {
            $eigenaars[] = $eigenaar;
        }

        $acl = Acl::find('Structuurtable_idStructuurtable = ' . $structuurtable->idstructuurtable . ' AND Entityid = ' . $id);
        if ($acl) {
            $existinguserrules = [];

            foreach ($acl as $rule) {

                $existinguserrules[] = $rule->Eigenaar->idEigenaar;
                $line = $rule->toArray();
                $line['idEigenaar'] = $rule->Eigenaar->idEigenaar;
                if ($line['Create'] == 1) {
                    $line['Create'] = true;
                }
                if ($line['Update'] == 1) {
                    $line['Update'] = true;
                }
                if ($line['Read'] == 1) {
                    $line['Read'] = true;
                }
                if ($line['Delete'] == 1) {
                    $line['Delete'] = true;
                }
                $line['name'] = $rule->Eigenaar->Voornaam . ' ' . $rule->eigenaar->Achternaam;
                $users[] = $line;
            }

            foreach (Eigenaar::find('Rol_idRol > 3') as $eigenaar) {
                if (!in_array($eigenaar->idEigenaar, $existinguserrules)) {
                    $users[] = ['idEigenaar' => $eigenaar->idEigenaar, 'name' => $eigenaar->Voornaam . ' ' . $eigenaar->Achternaam, 'Create' => false, 'Read' => false, 'Update' => false, 'Delete' => false];
                }
            }
        } else {
            foreach (Eigenaar::find('Rol_idRol > 1') as $eigenaar) {
                $users[] = ['idEigenaar' => $eigenaar->idEigenaar, 'name' => $eigenaar->Voornaam . ' ' . $eigenaar->Achternaam, 'Create' => false, 'Read' => false, 'Update' => false, 'Delete' => false];
            }
        }

        echo json_encode($users, JSON_UNESCAPED_SLASHES);
    }

    private function boolToNumber($val)
    {
        if ($val == true) {
            return 1;
        } else {
            return 0;
        }
    }

    private function storeAcl($idEigenaar, $idStructuurtable, $create, $read, $update, $delete, $id)
    {
        $acl = Acl::findFirst('Eigenaar_idEigenaar = '.$idEigenaar.' AND Structuurtable_idStructuurtable = '.$idStructuurtable.' AND Entityid = '.$id);
        if(!$acl){
            $acl = new Acl();
            $acl->Eigenaar_idEigenaar = $idEigenaar;
            $acl->Structuurtable_idStructuurtable = $idStructuurtable;
            $acl->Entityid = $id;
        }
        $acl->Create = $this->boolToNumber($create);
        $acl->Read = $this->boolToNumber($read);
        $acl->Update = $this->boolToNumber($update);
        $acl->Delete = $this->boolToNumber($delete);
        if (!$acl->save()) {
            print_r($acl->getMessages());
        }
    }

    public function storeAction($entity, $id)
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        $structuur = Structuurtable::findFirst('sqltable = "' . $entity . '"');


        foreach ($request_body['data'] as $e) {

            $this->storeAcl($e['idEigenaar'], $structuur->idstructuurtable, $e['Create'], $e['Read'], $e['Update'], $e['Delete'], $id);

            switch ($entity) {
                case 'dossier':
                    $dossierid = 1;
                    //enables all contracts under dossier
                    foreach (ContractHasDossier::find('Dossier_idDossier = ' . $dossierid) as $contract) {
                        $this->storeAcl($e['idEigenaar'], 36, $e['Create'], $e['Read'], $e['Update'], $e['Delete'], $contract->Contract_idContract);


                        foreach (Taak::find('Contract_idContract = ' . $contract->Contract_idContract) as $contract) {
                            $this->storeAcl($e['idEigenaar'], 21, $e['Create'], $e['Read'], $e['Create'], $e['Create'], $contract->idTaak);
                        }

                        //enables all gegevens under contract
                        foreach (Gegevens::find('Contract_idContract = ' . $contract->Contract_idContract) as $gegevens) {
                            $this->storeAcl($e['idEigenaar'], 38, $e['Create'], $e['Read'], $e['Create'], $e['Create'], $gegevens->idGegevens);
                        }

                        //enables all onderwerpen under contract
                        foreach (Onderwerp::find('Contract_idContract = ' . $contract->Contract_idContract) as $onderwerp) {
                            $this->storeAcl($e['idEigenaar'], 25, $e['Create'], $e['Read'], $e['Create'], $e['Create'], $onderwerp->idOnderwerp);
                        }
                    }

                    break;
                case 'contract':
                    $contractid = 1;
                    //enables all taken under contract
                    foreach (Taak::find('Contract_idContract = ' . $contractid) as $contract) {
                        $this->storeAcl($e['idEigenaar'], 21, $e['Create'], $e['Read'], $e['Create'], $e['Create'], $contract->idTaak);
                    }

                    //enables all gegevens under contract
                    foreach (ContractHasGegevens::find('Contract_idContract = ' . $contractid) as $gegevens) {
                        $this->storeAcl($e['idEigenaar'], 38, $e['Create'], $e['Read'], $e['Create'], $e['Create'], $gegevens->Gegevens_idGegevens);
                    }

                    //enables all onderwerpen under contract
                    foreach (Onderwerp::find('Contract_idContract = ' . $contractid) as $onderwerp) {
                        $this->storeAcl($e['idEigenaar'], 25, $e['Create'], $e['Read'], $e['Create'], $e['Create'], $onderwerp->idOnderwerp);
                    }

                    break;
            }

        }

        echo json_encode(['result' => 'success']);
    }
}