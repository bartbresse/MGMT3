<?php

use Phalcon\Mvc\Controller;

class TriggerController extends Controller
{
    public function getAction()
    {
        $this->view->disable();
        $triggers = [];

        $request_body = json_decode(file_get_contents('php://input'), true);
        $dossiers = $request_body['data']['contractsoort'];
        if (count($dossiers) > 0) {
            $query = '';
            foreach ($dossiers as $index => $dossier) {
                if ($index > 0) {
                    $query .= ' OR ';
                }
                $query .= 'Contractsoort_idContractsoort = ' . $dossier;
            }

            if(strlen($request_body['data']['entity']['value']) > 5) {
                $tc = Triggercache::findFirst('uuid = "' . $request_body['data']['entity']['value'] . '"');
                if($tc) {
                    $vals = json_decode($tc->data, true);
                }
            }
            foreach (ContractsoortHasTrigger::find($query) as $contractsoorthastrigger) {
                $trigger = $contractsoorthastrigger->Trigger;
                $triggertype = $trigger->Triggertype;
                $atrigger = $trigger->toArray();
                if(isset($vals) && isset($vals[$trigger->idTrigger])) {
                    $atrigger['value'] = $vals[$trigger->idTrigger];
                }else{
                    $atrigger['value'] = false;
                }
                $atrigger['triggernaam'] = $trigger->Naam;
                $triggers[] = array_merge($atrigger, $triggertype->toArray());
            }
        }
        echo json_encode(['triggers' => $triggers]);
    }

    public function saveAction()
    {
        $this->view->disable();
        $request_body = json_decode(file_get_contents('php://input'), true);
        $data = $request_body['data']['data'];

        $tc = Triggercache::findFirst('uuid = "'.$data['entity']['value'].'"');
        if(!$tc) {
            $tc = new Triggercache();
            $tc->uuid = $data['entity']['value'];
        }
        $triggers = [];
        foreach ($data['triggers'] as $trigger) {
            if ($trigger['value'] == 1) {
                $val = true;
            } else {
                $val = false;
            }
            $triggers[$trigger['idTrigger']] = $val;
        }
        $tc->data = json_encode($triggers);
        if(!$tc->save()){
            print_r($tc->getMessages());
        }else {
            echo json_encode(['result' => 'success']);
        }
    }
}