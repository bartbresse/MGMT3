<?php

class SettingsController extends ControllerBase
{
    public function formAction()
    {
        $settings = [];
        foreach (Setting::find() as $setting) {
            $set = $setting->toArray();
            $set['settingvalue'] = boolval($set['settingvalue']);
            $settings[] = $set;
        }
        echo json_encode($settings, JSON_UNESCAPED_SLASHES);
    }

    public function storeAction()
    {
        $request_body = json_decode(file_get_contents('php://input'), true);

        foreach ($request_body['data']['data'] as $row) {
            $setting = Setting::findFirst('settingkey = "' . $row['settingkey'] . '"');
            $setting->settingvalue = $row['settingvalue'];
            $setting->save();
        }
    }
}