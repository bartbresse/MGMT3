<?php

use Phalcon\Mvc\Controller;

class PrintController extends Controller
{
    public function indexAction($entity,$params)
    {
        $this->view->enable();

    }
}