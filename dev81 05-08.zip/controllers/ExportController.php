<?php

use Phalcon\Mvc\Controller;

class ExportController extends Controller
{
    public function printAction($params, $entity)
    {
        $this->view->disable();
        $post = $this->request->getPost();
        $render = $this->mgmt->getByEntityName($entity, $post['q'], false, false, json_decode($post['filters'], true));

        $html = '<table>';
        $html .= '<tr>';
        foreach($render['columns'] as $column)
        {
            $html .= '<th align="left"><b>'.$column.'</b></th>';
        }
        $html .= '</tr>';
        foreach ($render['data'] as $row) {
            $html .= '<tr>';
            foreach ($render['columns'] as $column) {
                if (isset($row[$column]) && is_array($row[$column])) {
                    $html .= '<td>' . $row[$column]['value'] . '</td>';
                }else{
                    $html .= '<td>&nbsp;</td>';
                }
            }
            $html .= '</tr>';
        }
        $html .= '</table>';

        $html .= '<style>
@page { size: landscape; }
table{     
    font-size: 13px;
    font-family: sans-serif; 
    border-collapse: collapse;
    }
    table tr td{
        border: 1px solid #eee;
    }
   
    </style><script>window.print()</script>';

        echo $html;
    }

    private function removelink($link)
    {
        $left = explode('>',$link);
        $right = explode('<',$left[1]);
        return $right[0];
    }

    public function csvAction($params, $entity)
    {
        $this->view->disable();

        $post = $this->request->getPost();
        $render = $this->mgmt->getByEntityName($entity, $post['q'], false, false, json_decode($post['filters'], true));

        $rowindex = 0;
        $rows = [];
        foreach($render['columns'] as $index => $column)
        {
            if($index > 0){
                $rows[$rowindex] .= ';';
            }else{ $rows[$rowindex] = ''; }
            $rows[$rowindex] .= $column;
        }

        foreach ($render['data'] as $row) {
            $rowindex++;
            foreach ($render['columns'] as $index => $column) {
                if($index > 0){
                    $rows[$rowindex] .= ';';
                }else{ $rows[$rowindex] = ''; }

                if (isset($row[$column]) && is_array($row[$column]) && isset($row[$column]['value'])) {
                    $link = explode('<a',$row[$column]['value']);
                    if(isset($link[1])){
                        $rows[$rowindex] .= $this->removelink($row[$column]['value']);
                    }else{
                        $rows[$rowindex] .= $row[$column]['value'];
                    }
                }else{
                    $rows[$rowindex] .= '';
                }
            }
        }

        $csvstr = '';
        foreach($rows as $row){
            $csvstr .= $row.'
            ';
        }


        header('Content-Disposition: attachment; filename="sample.csv"');
        header('Content-Type: text/plain'); # Don't use application/force-download - it's not a real MIME type, and the Content-Disposition header is sufficient
        header('Content-Length: ' . strlen($csvstr));
        header('Connection: close');
        echo $csvstr;
    }
}