<?php

class CsvController extends ControllerBase
{
    public function showAction($entity)
    {
        $classname = ucfirst($entity);
        $ignorefields = ['Createdat','Deletedat','Updatedat','Password'];

        $rowheader = [];
        $tablerowheader = [];
        $rowscsv = [];
        foreach ($classname::find() as $row) {
            $rowcsv = [];
            $rowheader = [];
            $tablerowheader = [];

            $fields = $row->toArray();

            foreach ($row->toArray() as $index => $field) {

                if (strpos($index, '_') > 0) {
                    //  echo $index.'<br />';

                    $ex = explode('_', $index);
                    $exo = $ex[0];

                    foreach ($row->$exo->toArray() as $index2 => $field2) {
                        //remove db ids

                        if($index2 != $ex[1] && !in_array($index2,$ignorefields)) {

                            //    echo $index2 . ':' . $field2 . '<br />';
                            //print_r($field2);

                            $rowheader[] = $index2;
                            if (!in_array($exo, $tablerowheader)) {
                                $tablerowheader[] = $exo;
                            } else {
                                $tablerowheader[] = '';
                            }
                            $rowcsv[] = $field2;
                        }
                    }

                } else {

                    if(!in_array($index,$ignorefields)) {

                        if (!in_array($entity, $tablerowheader)) {
                            $tablerowheader[] = $entity;
                        } else {
                            $tablerowheader[] = '';
                        }
                        $rowheader[] = $index;
                        $rowcsv[] = $field;
                    }
                }
            }
            $rowscsv[] = $rowcsv;
        }

      //  print_r($rowscsv);

        $rowcsvf = [];
        $rowcsvf[0] = $tablerowheader;
        $rowcsvf[1] = $rowheader;
        $i = 2;

        $rowscsvf = array_merge($rowcsvf,$rowscsv);


      //  print_r($rowscsvf);


        $filename = 'export.csv';
        header('Content-Disposition: attachment; filename="'.$filename.'";');
        $this->array_to_csv_download($rowscsvf,$filename,$classname);


    }

    function array_to_csv_download($array, $filename = "export.csv", $classname, $delimiter = ";")
    {
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '";');

        // open the "output" stream
        // see http://www.php.net/manual/en/wrappers.php.php#refsect2-wrappers.php-unknown-unknown-unknown-descriptioq
        $f = fopen('php://output', 'w');

        foreach ($array as $line) {
            fputcsv($f, $line, $delimiter);
        }
    }
}