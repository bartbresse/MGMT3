<?php

use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class AutoauthController extends ControllerBase
{
    public function indexAction()
    {
        $body = json_decode(file_get_contents('php://input'));
        $secret = '3k?H&Y;(W[39BTqU+<!j!<`m30w|$*';
        $routing = [
            '' => ['url' => '', 'label' => ''],
            'view' => ['url' => '/view', 'label' => 'Bekijken'],
            'dashboard' => ['url' => '/dashboard', 'label' => 'Dashboard'],
            'dossier' => ['url' => '/dossier', 'label' => 'Dossiers'],
            'contract' => ['url' => '/contract', 'label' => 'Contracten'],
            'onderwerp' => ['url' => '/onderwerp', 'label' => 'Onderwerpen'],
            'taak' => ['url' => '/taak', 'label' => 'Taken'],
            'document' => ['url' => '/document', 'label' => 'Documenten'],
            'gegevens' => ['url' => '/gegevens', 'label' => 'Financiële gegevens'],
            'relatie' => ['url' => '/relatie', 'label' => 'Relaties'],
            'rapportage' => ['url' => '/rapportage', 'label' => 'Rapportage'],
            'add' => ['url' => '/add', 'label' => 'Toevoegen'],
        ];

        if (isset($body->key)) {
            $eigenaar = Eigenaar::findFirst("Token = '" . $body->key . "'");

        //    $passwordCheck = password_verify($body->password, $eigenaar->Password);
            $this->session->set('eigenaar', $eigenaar);
            if ($eigenaar) {
                $us = new Usersession();
                $us->Creationtime = date('Y-m-d H:i:s');
                $us->Eigenaar_idEigenaar = $eigenaar->idEigenaar;
                $us->Sessioncode = uniqid();

                if (!$us->save()) {
                    print_r($us->getMessages());
                    die();
                }

                $builder = new TokenBuilder();

                $builder->setSubject('cmt'); // whom the token refers to
                $builder->setAudience('login'); // who or what the token is intended for
                $expiration = time() + (8 * 60 * 60); // + 8 uur
                $issuer = 'Contract management tool'; // who created and signed the token
                $admin = ($eigenaar->rol_idrol = 3) ? true : false; // administrator ?

                $token = $builder->addPayload(['key' => 'name', 'value' => $eigenaar->Voornaam . ' ' . $eigenaar->Achternaam])
                    ->addPayload(['key' => 'admin', 'value' => $admin])
                    ->addPayload(['key' => 'idEigenaar', 'value' => $eigenaar->idEigenaar])
                    ->addPayload(['key' => 'rol', 'value' => $eigenaar->Rol_idRol])
                    ->setSecret($secret)
                    ->setExpiration($expiration)
                    ->setIssuer($issuer)
                    ->build();
                echo json_encode(['routing' => $routing, 'auth' => true, 'token' => $token, '']);
            } else {
                echo json_encode(['auth' => false]);
            }
        }
    }

    public function placekeyAction()
    {
        if(isset($_POST['apploginkey']))
        {
            $eigenaar = Eigenaar::findFirst('Email = "'.$_POST['email'].'"');
            if($eigenaar)
            {
                $eigenaar->Token = $_POST['apploginkey'];
                echo json_encode(['key' => $eigenaar->Token]);
                if(!$eigenaar->save())
                {
                    print_r($eigenaar->getMessages());
                    die();
                }
            }
        }

    }
}