<?php

class ImportController extends ControllerBase
{
    public function csvAction($gegevens)
    {
        $this->view->disable();

        switch($gegevens)
        {
            case 'gegevens': $import = new GegevensImport(); break;
            case 'onderwerp': $import = new OnderwerpImport(); break;
            case 'contract': $import = new ContractImport(); break;
            case 'relatie': $import = new RelatieImport(); break;
            case 'taak': $import = new TakenImport(); break;
        }
        $import->import();

        die();
    }

    public function showAction()
    {
        $this->view->disable();

        $import = 'Afval	
Beveiliging - Alarminstallaties	
Beveiliging - Brandmeldinstallaties	
Beveiliging - Meldkamer	
Beveiliging - Opvolging	
Collectie	
Energie - Electra	
Energie - Gas en electra	
Groen voorziening	
Huur	
Huur en service	
ICT - Bibliotheek systeem	
ICT - Lijnverbinding	
ICT - Servicedesk	
ICT - Software	
ICT - Zelfservice	
Inrichting	
Klantenservice	
Koffie en Vending	
MF kopieermachines	
Office Management	
Onderhoud gebouwen - Deuren	
Onderhoud gebouwen - Liften	
Onderhoud gebouwen - Luchtbehandeling	
Overig	
Personeelszaken	
Sanitair	
Schoonmaak	
Service	
Telefonie - Mobiel	
Telefonie - Vast	
Verzekering	
Verzekeringen - Aansprakelijkheid	
Verzekeringen - Apparatuur	
Verzekeringen - Autoverzekeringen	
Verzekeringen - Inboedel	
Verzekeringen - Kostbaarheden	
Water	
Waterkoeler';

        $skuList = explode(PHP_EOL, $import);

        foreach (explode(PHP_EOL, $import) as $value)
        {
            echo 'INSERT INTO `contractsoort` (`Naam`) VALUES ("'.trim($value,' ').'"); <br />';
        }

$taakstatus = 'Niet Gestart		
In Behandeling
Geweigerd
Gereed';
        $skuList = explode(PHP_EOL, $taakstatus);

        foreach (explode(PHP_EOL, $import) as $value)
        {
            echo 'INSERT INTO `taakstatus` VALUES ("'.$value.'"); <br />';
        }

$documentsoort ='Algemene voorwaarden	
Bijlage bij contract	
Contract	
Opzegging	
Polis	
Werkprogramma';
        $skuList = explode(PHP_EOL, $documentsoort);

        foreach (explode(PHP_EOL, $import) as $value)
        {
            echo 'INSERT INTO `documentsoort` VALUES ("'.$value.'"); <br />';
        }

        die();
    }
}