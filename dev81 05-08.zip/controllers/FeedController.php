<?php

class FeedController extends ControllerBase
{
    private function createTaakArray($naam, $id, $prioriteit, $time,$taak)
    {
        $a = [];
        $a['naam'] = $naam;
        $a['url'] = '/view/taak/' . $id;
        $a['id'] = $id;
        $a['prio'] = $prioriteit;
        $a['date'] = date('d-m-Y', $time);

        if(is_array($taak->Contract))
        {

        }

        print_r($taak->Contract->toArray());

       // echo strtotime(date('Y-m-d')) .'=='. $time.'<br />';

        if (strtotime(date('Y-m-d')) >= $time) {
            $a['late'] = true;
        } else {
            $a['late'] = false;
        }

        return $a;
    }

    public function indexAction()
    {
        /*
        $body = json_decode(file_get_contents('php://input'));
        print_r($body);


        $validator = new TokenValidator();
        $validator->splitToken($body['data']['token'])
            ->validateExpiration()
            ->validateSignature($this->globalconfig->secret);
        $sessie = json_decode($validator->getPayload());
        */

        $feed = [];
        foreach (Taak::find(array('conditions' => 'Eigenaar_idEigenaar = 3 AND Taakstatus_idTaakstatus < 3', 'order' => 'Einddatum ASC')) as $taak) {
            if (!isset($feed[date('d-m-Y', strtotime($taak->Einddatum))])) {
                $feed[date('d-m-Y', strtotime($taak->Einddatum))] = [];
            }
            $feed[date('d-m-Y', strtotime($taak->Einddatum))][] = $this->createTaakArray($taak->Naam, $taak->idTaak, $taak->Prioriteit->Naam, strtotime($taak->Einddatum),$taak);
        }

        echo json_encode($feed);
    }
}