<?php

class FinoverzichtController extends ControllerBase
{
    public function showAction()
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        if(!isset($request_body['data']['filters']))
        {
            $request_body['data']['filters'] = [];
        }
        $render = $this->mgmt->getByEntityName('contract', '', '',false,$request_body['data']['filters']);
        $rows = [];
        $total = 0;

        foreach($render['data'] as $row) {
            $total += $row['Jaarwaarde']['value'];
        }
        $render['total'] = '€ '.number_format( $total,2,",",".");
     //   $render['columns'] = ["Rubriek","Medewerker_idMedewerker","Eigenaar_idEigenaar","Adres_idAdres","Nummer","Naam","Vendor","Jaarwaarde"];
        $render['columns'] = ["Rubriek","Contracteigenaar","Eigenaar","Adres","Nummer","Nummerklant","Vendor","Naam","Jaarwaarde"];
       // $render['columnData']['percentage'] = ['attr' => []];
        echo json_encode($render, JSON_UNESCAPED_SLASHES);
    }
}