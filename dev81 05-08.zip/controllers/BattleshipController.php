<?php

class BattleshipController extends ControllerBase
{
    public function indexAction()
    {

    }

    public function getgridAction()
    {
        $options = [];
        foreach (Positietype::find() as $positie) {
            $options[] = ['value' => $positie->idPositietype, 'label' => $positie->Naam];
        }

        $contracts = [];
        foreach (Contract::find() as $contract) {
            $contracts[] = ['value' => $contract->idContract, 'label' => $contract->Nummer . ' ' . $contract->Naam];
        }

        $grid = [];
        $contractsoorten = [];
        foreach (Contractsoort::find(['conditions' => 'Contractsoort_idContractsoort = 0']) as $contractsoort2) {
            $contractsoorten[] = $contractsoort2;
            foreach (Contractsoort::find(['conditions' => 'Contractsoort_idContractsoort = ' . $contractsoort2->idContractsoort]) as $contractsoort) {
                $contractsoorten[] = $contractsoort;
            }
        }

        foreach ($contractsoorten as $contractsoort) {
            $grid[$contractsoort->idContractsoort]['contractsoort'] = $contractsoort->toArray();
            $grid[$contractsoort->idContractsoort]['row'] = [];

            $grid[$contractsoort->idContractsoort]['subcategory'] = false;
            if($contractsoort->Contractsoort_idContractsoort > 0) {
                $grid[$contractsoort->idContractsoort]['subcategory'] = true;
            }

            foreach (Adres::find() as $adres) {
                $grid[$contractsoort->idContractsoort]['row'][$adres->idAdres]['adres'] = $adres->toArray();

                $positie = Positie::findFirst('Contractsoort_idContractsoort = ' . $contractsoort->idContractsoort . ' AND Adres_idAdres = "' . $adres->idAdres . '"');
                if (!$positie) {
                    $positie = new Positie();
                    $positie->Adres_idAdres = $adres->idAdres;
                    $positie->Contractsoort_idContractsoort = $contractsoort->idContractsoort;
                }

                $pos = $positie->toArray();
                if ($positie->Contract_idContract > 0) {
                    $pos['contract'] = Contract::findFirst('idContract = ' . $positie->Contract_idContract)->toArray();
                } else {
                    $pos['contract'] = [];
                }
                $pos['options'] = $options;
                $pos['contracts'] = $contracts;


                switch ($pos['Positietype_idPositietype']) {
                    case 1:
                        $pos['color'] = '#EEEEEE';
                        break;
                    case 2:
                        $pos['color'] = '#E0FFFF';
                        break;
                    case 3:
                        $pos['color'] = '#98FB98';
                        break;
                    default:
                        $pos['color'] = '#FFD8D8';
                        break;
                }

                $grid[$contractsoort->idContractsoort]['row'][$adres->idAdres]['cell'] = $pos;
            }
        }

        echo json_encode(['grid' => $grid], JSON_UNESCAPED_SLASHES);
    }

    public
    function storegridAction()
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        foreach ($request_body['data']['grid'] as $index => $row) {

            foreach ($row['row'] as $index2 => $field) {

                $positie = Positie::findFirst('Contractsoort_idContractsoort = ' . $field['cell']['Contractsoort_idContractsoort'] . ' AND Adres_idAdres = "' . $field['cell']['Adres_idAdres'] . '"');
                if (!$positie) {
                    $positie = new Positie();
                    $positie->Adres_idAdres = $field['cell']['Adres_idAdres'];
                    $positie->Contractsoort_idContractsoort = $field['cell']['Contractsoort_idContractsoort'];
                }

                if ($field['cell']['Contract_idContract'] > 0) {
                    $positie->Contract_idContract = $field['cell']['Contract_idContract'];
                }

                $positie->Positietype_idPositietype = $field['cell']['Positietype_idPositietype'];
                if (!$positie->save()) {
                    print_r($positie->getMessages());
                    die();
                }

                switch ($field['cell']['Positietype_idPositietype']) {
                    case "1":
                        $color = '#EEEEEE';
                        break;
                    case 2:
                        $color = '#E0FFFF';
                        break;
                    case "3":
                        $color = '#98FB98';
                        break;
                    default:
                        $color = '#FFD8D8';
                        break;
                }
                $request_body['data']['grid'][$index]['row'][$index2]['cell']['color'] = $color;

                if ($positie->Contract_idContract > 0) {
                    $request_body['data']['grid'][$index]['row'][$index2]['cell']['contract'] = Contract::findFirst('idContract = ' . $positie->Contract_idContract)->toArray();
                } else {
                    $request_body['data']['grid'][$index]['row'][$index2]['cell']['contract'] = [];
                }
            }
        }

        echo json_encode(['grid' => $request_body['data']['grid']], JSON_UNESCAPED_SLASHES);
    }
}