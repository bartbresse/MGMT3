<?php

use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class ChartController extends ControllerBase
{
    private function createTaakArray($naam, $id, $prioriteit, $time,$contract)
    {
        $a = [];
        $a['naam'] = $naam;
        $a['url'] = '/view/taak/' . $id;
        $a['id'] = $id;
        $a['prio'] = $prioriteit;
        if($time > 0) {
            $a['date'] = date('d-m-Y', $time);
        }
        // echo strtotime(date('Y-m-d')) .'=='. $time.'<br />';

//        print_r($contract);

        if (strtotime(date('Y-m-d')) >= $time) {
            $a['late'] = true;
        } else {
            $a['late'] = false;
        }

        return $a;
    }

    private function attentionlist()
    {
        $nh = new NotificationHandler();

        $contracts = $nh->listOfDueContracts();
        print_r($contracts);

        $tasks = $nh->listOfDueTasks();
        print_r($tasks);
    }

    private function generatefeed($token)
    {
        $eigenaar = $this->mgmt->getEigenaar();
        $id = $eigenaar->idEigenaar;

        /*
        $sh = new SecurityHandler();
        $id = $sh->getEigenaarID();
        */

        $feed = [];
        foreach (Taak::find(array('conditions' => 'Eigenaar_idEigenaar = '.$id.' AND Taakstatus_idTaakstatus < 2', 'order' => 'Einddatum ASC')) as $taak) {
            if (!isset($feed[date('d-m-Y', strtotime($taak->Einddatum))])) {
                $feed[date('d-m-Y', strtotime($taak->Einddatum))] = [];
            }
            $feed[date('d-m-Y', strtotime($taak->Einddatum))][] = $this->createTaakArray($taak->Naam, $taak->idTaak, $taak->Prioriteit->Naam, strtotime($taak->Einddatum),$taak->Contract);
        }

        if(isset($feed['01-01-1970'])){

            $feed['Geen datum'] = $feed['01-01-1970'];

            unset($feed['01-01-1970']);
        }

      //  print_r($feed);

        return $feed;
    }

    private function random_color_part() {
        return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
    }

    private function random_color() {
        return '#'.$this->random_color_part() . $this->random_color_part() . $this->random_color_part();
    }

    public function indexAction()
    {
        $this->mgmt;

        $request_body = json_decode(file_get_contents('php://input'), true);

        $chart = [];
        $bigchart = [];
        //taken by status
        $status = [];

        $userid = 1;

        foreach(['','Eigenaar_idEigenaar = "'.$userid.'"'] as $arg) {

            foreach (Taak::find($arg) as $taak) {
                if (!isset($status[$taak->Taakstatus->Naam])) {
                    $status[$taak->Taakstatus->Naam] = 0;
                }
                $status[$taak->Taakstatus->Naam] += 1;
            }

            $labels = array_keys($status);
            $cc = count($labels);

            $colors = [];
            for ($i = 0; $i < $cc; $i++) {
                $colors[] = $this->random_color();
            }

            $chartloop['statustaken'] = [];
            $chartloop['statustaken'] = ['name' => 'Status taken','width' => '50%', 'labels' => $labels, 'datasets' => array('label' => 'GitHub Commits', 'backgroundColor' => $colors, 'data' => array_values($status))];

            //mijn objecten
            $contracts = count(Contract::find($arg));
            $taken = count(Taak::find($arg));
            //$onderwerpen = count(Onderwerp::find($arg));
            $onderwerpen = [];

            $gegevens = count(Gegevens::find($arg));
            $documenten = count(Document::find($arg));

            $colors = [];
            for ($i = 0; $i < 4; $i++) {
                $colors[] = $this->random_color();
            }

            $chartloop['objecten'] = [];
            $chartloop['objecten'] = ['name' => 'Objecten','width' => '50%', 'labels' => ['Contracts', 'Taken', 'Onderwerpen', 'Gegevens', 'Documenten'], 'datasets' => ['label' => 'Mijn Objecten', 'backgroundColor' => $colors, 'data' => [$contracts, $taken, $onderwerpen, $gegevens, $documenten]]];


            //contracten per soort
            $contracten = [];
            /*
            foreach (Contract::find($arg) as $contract) {
                if (!isset($contracten[$contract->Contractsoort->Naam])) {
                    $contracten[$contract->Contractsoort->Naam] = 0;
                }
                $contracten[$contract->Contractsoort->Naam] += 1;
            }
               */

            $contracts = [];
            foreach ($contracten as $index => $con) {
                if ($con > 4) {
                    $contracts[$index] = $con;
                }
            }

            $colors = [];
            for ($i = 0; $i < count(array_values($contracts)); $i++) {
                $colors[] = $this->random_color();
            }

            /*
            $chartloop['soortcontract'] = [];
            $chartloop['soortcontract'] = ['name' => 'Contract soorten','width' => '100%', 'labels' => array_keys($contracts), 'datasets' => ['label' => 'Soorten contracten', 'backgroundColor' => $colors, 'data' => array_values($contracts)]];
*/

            if(strlen($arg) > 0)
            {
                $bigchart = $chartloop;
            }else{
                $chart = $chartloop;
            }
        }

        $this->attentionlist();

        $settings = [];
        foreach(Setting::find() as $setting)
        {
            $settings[$setting->settingkey] = $setting->toArray();
        }

        echo json_encode(['charts'=>$chart,'chartspersonal'=>$bigchart,'feed' => $this->generatefeed($request_body['token']), 'settings' => $settings],true);
    }
}