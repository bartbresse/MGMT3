<?php


class ViewController extends ControllerBase
{
    public function showAction($entity, $id = false)
    {
        $tableData = $this->mgmt->getRowByEntityNameAndId($entity, $id);
        $render = [];

        $cc = 0;
        $cc2 = 0;
        $row = [];

        $render['settings'] = ['editurl' => '/#/edit/'.$entity.'/'.$id, 'deleteurl' => 'delete/'.$entity.'/'.$id];

        foreach ($tableData->renderRow() as $index => $field) {

            if($index != 'Path') {
                if ($cc % 4 == 0) {
                    $cc2++;
                }
                if (!isset($row[$cc2])) {
                    $row[$cc2] = [];
                }

                $row[$cc2][$index] = $field;
                $cc++;
            }
            if($entity == 'document' && $index == 'Path')
            {
                $render['settings']['downloaduri'] = $this->globalconfig->domain . $field['value'];
            }


        }

        $render['fields'] = $row;
        $render['actions'] = Action::find('entity = "' . $entity . '"')->toArray();
        $render['rights'] = $this->mgmt->getRights();

        echo json_encode($render, JSON_UNESCAPED_SLASHES);
    }
}