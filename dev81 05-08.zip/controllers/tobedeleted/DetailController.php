<?php

class DetailController extends ControllerBase
{
    public function showAction($entityname, $entityRowId = false)
    {
        $dataTables = $this->mgmt->getByEntityAndIdName($entityname,$entityRowId);

        echo json_encode($dataTables, JSON_UNESCAPED_SLASHES);
    }

}