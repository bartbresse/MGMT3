<?php


class AuditController extends ControllerBase
{
    public function postAction($entity, $id)
    {
        $request_body = json_decode(file_get_contents('php://input'), true);
        $log = $this->mgmt->restoreRow($entity,$id,$request_body['data']['id']);
        echo json_encode(['log' => $log], JSON_UNESCAPED_SLASHES);
    }

    public function showAction($entity, $id)
    {
        $log = $this->mgmt->listAudit($entity, $id);
        echo json_encode(['log' => $log], JSON_UNESCAPED_SLASHES);
    }
}