<?php


class PostController extends ControllerBase
{
    //TODO: to be removed
    /*
    private function getForeignTable($table, $has)
    {
        foreach ($has as $t) {
            if ($t == $table) {

            } else {
                return $t;
            }
        }
    }

    /*
    private function storeManyToMany($table, $data, $entityobject)
    {
        //TODO: refactor this
        $conn = new PDO('mysql:host=localhost;dbname='.$this->globalconfig->dbname, $this->globalconfig->username, $this->globalconfig->password);
        $query2 = $conn->prepare("SELECT
                      *
                    FROM
                      INFORMATION_SCHEMA.KEY_COLUMN_USAGE
                    WHERE
                      REFERENCED_TABLE_SCHEMA = '" . $this->globalconfig->dbname . "' AND
                      REFERENCED_TABLE_NAME = '" . $table . "'");
        $query2->execute();
        $tables = $query2->fetchAll();
        foreach ($tables as $table2) {
            // many to many
            $has = explode('_has_', $table2['TABLE_NAME']);
            if (isset($has[1])) {
                $foreigntable = $this->getForeignTable($table, $has);
                $ent = ucfirst($foreigntable);

                //home
                $ucentity = ucfirst($table);
                $lentity = $table . '_id' . $ucentity;

                //foreign
                $fentity = $foreigntable . '_id' . $foreigntable;
                $idptr = $ucentity;

                $modelname = $has[0] . 'Has' . $has[1];

                $e = new $modelname();
                $e->$fentity = $data->$idptr;
                $e->$lentity = $entityobject->$ucentity;
                if (!$e->save()) {
                    print_r($e->getMessages());
                }
            }
        }
    } */

    /**
     * Used for login
     *//*
	public function registerAction()
	{
		$request_body = json_decode(file_get_contents('php://input'), true);
		$tableData = $this->mgmt->storeEntity('eigenaar',false);


		$post = $request_body['data']['data'];

		if($post && isset($post['Password']) && isset($post['Voornaam']) && isset($post['Achternaam'])){
			if($post['Password'] === $post['PasswordAgain']){
				$post['Password'] = password_hash($post['Password'],PASSWORD_BCRYPT);
				$post['Rol_idRol'] = 1;
				$post['Eigenaarstatus_idEigenaarstatus'] = 1;
				$post['Activation'] = time() + (24 * 60 * 60).'_'.md5(time().$post['Voornaam'].$post['Achternaam']);

				unset($post['PasswordAgain']);
				unset($post['undefined']);
			}
            $response['activationUrl'] = $this->globalconfig->domain.'/auth/validate/'.$post['Activation'];
		}

        $response = $tableData->store($post);

		echo json_encode($response, JSON_UNESCAPED_SLASHES);


	} */
}