<?php

use ReallySimpleJWT\TokenBuilder;
use ReallySimpleJWT\TokenValidator;

class FileController extends ControllerBase
{
    public function acceptAction($token)
    {

        $token = explode('&',$token);
        $token = explode('token=',$token[0]);
        $token = $token[1];

        $validator = new TokenValidator();
            $validator->splitToken($token)
                ->validateExpiration()
                ->validateSignature($this->globalconfig->secret);
            $sessie = json_decode($validator->getPayload());

        $jsondata = ['test'];

        $id = uniqid();
        foreach($_FILES as $file)
        {
            $doc = new Document();
            $doc->Versie = 1;
            $info = pathinfo($file['name']);
            $ext = $info['extension']; // get the extension of the file

            if(!is_dir('../public/files/'.$id.'/'))
            {
                mkdir('../public/files/'.$id.'/');
            }

            $target = '../public/files/'.$id.'/'.$file['name'];
            if(move_uploaded_file( $file['tmp_name'], $target)) {

                $doc->Naam = $file['name'];
                $doc->Path = '/files/'.$id.'/'.$file['name'];
                $doc->Eigenaar_idEigenaar = $sessie->idEigenaar;


                if (!$doc->save()) {
                    print_r($doc->getMessages());
                }else{
                    $jsondata = $doc->toArray();
                }
            }
        }
        echo json_encode($jsondata, JSON_UNESCAPED_SLASHES);
    }
}