<?php

class CronController extends ControllerBase
{
    public function indexAction()
    {
        $this->view->disable();

        $this->mgmt->cron();

    }
}