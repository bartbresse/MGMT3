<?php

class EditController extends ControllerBase
{
    public function showAction($entityx, $id = false)
    {
		$this->view->disable();

		if(!$id){
			die();
		}

		$ei = new EntityInfo($entityx);

		$en = $ei->entityname;
		$entity = $en::find('id'.ucfirst($entityx).' = '.$id);

		$json = new TableJsonHandler();
		$obj = $json->getTableJson($ei,$entity);

		echo json_encode($obj, JSON_UNESCAPED_SLASHES);
    }
}