<template>
    <div>
        <el-tabs v-model="activeName">
            <el-tab-pane label="Form" name="first">

                <el-form ref="formSchema" style="max-width: 1000px !important;" label-width="0px">
                    <el-form-item v-for="(property,index) in data.properties" v-if="property.visible"
                                  :id="property.field"
                                  :class="property.cssclass">
                        <label>{{ property.title }}<span v-if="property.required">*</span></label>


                        <string v-if="property.type == 'string'" v-on:change="changeProperty"
                                v-model="data.properties[index]"></string>
                        <date v-if="property.type == 'date'" v-on:change="changeProperty"
                              v-model="data.properties[index]"></date>
                        <selectf v-if="property.type == 'select' || property.type == 'multiselect'"
                                 v-on:change="changeProperty" v-model="data.properties[index]"></selectf>
                        <switchf v-if="property.type == 'switch'" v-model="data.properties[index]"
                                 v-on:change="changeProperty"></switchf>
                        <period v-if="property.type == 'period'" v-model="data.properties[index]"
                                v-on:change="changeProperty"></period>
                        <trigger v-if="property.type == 'trigger'" v-model="data.properties[index]"></trigger>
                        <file v-if="property.type == 'files' || property.type == 'file'"
                              v-model="data.properties[index]" ></file>
                        <money v-if="property.type == 'money'" v-model="data.properties[index]">
                            <template slot="append">EUR</template>
                        </money>
                        <el-input v-if="property.type == 'password'" type="password" size="mini"
                                  :placeholder="data.properties[index].placeholder"
                                  v-model="data.properties[index].value"></el-input>

                        <el-input v-if="property.type == 'textarea'" size="mini" type="textarea"
                                  v-model="data.properties[index].value"></el-input>


                        <span>{{ property.description }} {{ property.message }}</span>
                    </el-form-item>
                    <br/>
                    <el-form-item>
                        <el-button size="small" type="primary" @click="submit">Opslaan</el-button>
                        <el-button size="small" @click="cancel">Cancel</el-button>
                    </el-form-item>
                    <el-form-item label="">
                        <p>Verplichte velden bevatten een asterix (*).</p>
                    </el-form-item>
                </el-form>

            </el-tab-pane>
            <el-tab-pane v-if="" label="Historie" name="second">
                <history :entity="entity"/>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
    import axios from 'axios'

    import String from './formelements/String'
    import Date from './formelements/Date'
    import Selectf from './formelements/Selectf'
    import File from "./formelements/File";
    import Switchf from "./formelements/Switchf";
    import money from './formelements/money';
    import period from './formelements/period';
    import Trigger from './formelements/Trigger';

    import History from '@/components/mgmt/History'

    import ContactFormLogic from '../ContractFormLogic'

    export default {
        name: 'Dataformx',
        props: ['entity'],
        components: {File, String, Date, Selectf, money, period, ContactFormLogic, Switchf, Trigger, History},
        data: function () {
            return {
                data: {properties: {}},
                paths: {url: '', redirect: ''},
                cfl: {},
                activeName: 'first'
            }
        },
        mounted() {
            var self = this;
            this.cfl = new ContactFormLogic();
            this.setPaths();
            this.getForm();
        },
        watch: {
            $route(to, from) {
                this.getForm();
            }
        },
        methods: {
            changeProperty(field) {
                this.cfl.onChange(this.data, field);
            },
            submit() {
                var self = this;

               /* for (var property in this.data.properties) {
                    if (this.data.properties[property].value == -1) {
                        console.log(this.data.properties[property]);
                    }
                } */
               console.log(self.data.properties);

                axios.post(process.env.API_URL + self.paths.url, {
                    data: {"data": self.data.properties, 'token': document.cookie},
                }, {
                    headers: {'Content-Type': 'text/plain;'}
                }).then(response => {
                    if (response.data.result == 'succes') {
                        this.$router.push({path: self.paths.redirect});
                    } else if (response.data.result == 'failure') {
                        for (var data in response.data.properties) {
                            //TODO: fix error message handling
                            self.data.properties[response.data.properties[data].field].message = response.data.properties[data].message;
                        }
                    }
                });
            },
            setPaths() {
                var self = this;
                var redirect = '/list/' + this.entity.entity;
                if (typeof (self.entity.entity) !== 'undefined' && this.entity.entity2 == 'setup') {
                    var url = 'mgmt/post/' + this.entity.entity;
                    redirect = '/setup/' + this.entity.entity;
                }
                else if (typeof (self.entity.entity2) !== 'undefined' || typeof (this.entity.entity) !== 'undefined') {
                    var url = 'mgmt/post/' + this.entity.entity;
                }

                if (typeof (self.entity.id) != "undefined") {
                    var url = 'mgmt/post/' + this.entity.entity + '/' + this.entity.id;
                }

                if (this.$route.name == 'Register') {
                    redirect = '/login';
                }
                self.paths.url = url;
                self.paths.redirect = redirect;
            },
            getForm() {
                this.setPaths();

                var self = this;
                if (typeof (this.entity.entity) !== 'undefined' && typeof (this.entity.entity2) !== 'undefined') {
                    var url = this.entity.entity;
                }
                else if (typeof (this.entity.id) !== 'undefined') {
                    var url = this.entity.entity + '/' + this.entity.id;
                }
                else {
                    var url = this.entity.entity;
                }

                var postData = {"token": document.cookie};
                axios.post(process.env.API_URL + 'mgmt/form/' + url, {data: postData}, {
                    headers: {
                        'Content-Type': 'text/plain;',
                    }
                }).then(response => {
                    self.data = response.data;
                    this.cfl.testLogic(this.data);
                });
            },
            cancel() {
                this.$router.push({path: this.paths['redirect']});
            }
        }
    }
</script>
<style>
    .el-form-item__content {
        line-height: 12px;
        position: relative;
        font-size: 12px;
    }

    .el-input__inner {
        height: 30px;
        line-height: 30px;
        font-size: 12px;
    }

</style>