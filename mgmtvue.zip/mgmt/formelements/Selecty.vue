<template>
    <div>
        <el-select v-if="property.type == 'select'" v-on:change="onSelectChange" :placeholder="property.placeholder"
                   size="mini" v-model="property.value">
            <el-option v-for="option in property.enum" :key="option.value" :label="option.label"
                       :value="option.value"></el-option>
        </el-select>
        <el-select v-if="property.type == 'multiselect'" multiple v-on:change="onSelectChange"
                   :placeholder="property.placeholder" size="mini" v-model="property.value">
            <el-option v-for="option in property.enum" :key="option.value" :label="option.label"
                       :value="option.value"></el-option>
        </el-select>
    </div>
</template>
<script>

    export default {
        name: 'Selecty',
        components: {},
        props: ['value'],
        data() {
            return {
                property: this.value,
                dialogVisible: false,
                entity: {entity: '', entity2: '', id: ''},
                formreturn: ''
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);
            }
        },
        mounted: function () {
            this.entity.entity = this.property.entity;
        },
        methods: {
            formsave(e)
            {
                this.property.enum.push({label:e.fieldname, value:e.id});
                this.property.value = e.id;
                this.dialogVisible = false;
                //     console.log(e);
            },
            cancel(e)
            {
                this.dialogVisible = false;
            },
            onSelectChange(e) {
                this.$emit('change',{key:this.property.field,value:e});
            },
            handleClose(done) {
                done();
            }
        }
    }
</script>
<style>
    .el-form-item__content tr td{
        border-bottom: 0px;
    }
    .el-button {
        font-size: 12px;
    }
</style>