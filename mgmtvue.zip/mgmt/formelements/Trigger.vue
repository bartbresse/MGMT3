<template>
    <div>
TRIGGERS
    </div>
</template>
<script>
    export default {
        name: 'Trigger',
        components: {},
        props: ['value'],
        data() {
            return {
                property: this.value,
            }
        },
        watch: {
            property(val) {
                this.$emit('input', val);

            }
        },
        mounted: function () {

        },
        methods:{
            changeHandler(e)
            {
                this.$emit('change',{key:this.property.field,value:e});
            }
        }
    }
</script>