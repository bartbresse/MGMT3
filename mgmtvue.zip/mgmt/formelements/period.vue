<template>
    <div>
        <input type="hidden" v-model="inputVal.value">
        <table style="position: relative;" class="periode">
            <tr>
                <td>
                    <el-input class="kwantiteit" placeholder="Kwantiteit" v-on:change="onChange"
                              v-model="amount"></el-input>
                </td>
                <td>
                    <el-select class="entiteit" v-model="time" placeholder="Select" v-on:change="onChange">
                        <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </td>
            </tr>
        </table>
    </div>
</template>
<script>
    export default {
        props: ['value'],
        data() {
            return {


                options: [{
                    value: 'dag',
                    label: 'Dagen'
                }, {
                    value: 'maand',
                    label: 'Maanden'
                }, {
                    value: 'jaar',
                    label: 'Jaren'
                }],
                inputVal: this.value,
                amount: '',
                time: ''
            }
        },
        mounted: function () {
            if (typeof (this.value) !== "undefined") {
                var propvalue = this.value.value.split(" ");
                this.amount = propvalue[0];
                this.time = propvalue[1];
            }
        },
        methods: {
            onChange: function (e) {
                var self = this;

                this.inputVal.value = this.amount + ' ' + this.time;
           //     this.$emit('input', this.amount + ' ' + this.time);
                if(this.time != 'undefined' && this.time != '') {
                    this.$emit('change', {key:this.inputVal.field , value: this.inputVal.value});
                }
            }
        }
    };
</script>
<style>
    .periode {
        max-width: 300px;

    }
</style>