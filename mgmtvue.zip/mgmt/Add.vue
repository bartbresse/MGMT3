<template>
    <div>
        <br/>
        <Dataformx :entity="entity"/>
    </div>
</template>
<script>
    import Dataformx from '@/components/mgmt/Dataformx'

    export default {
        name: 'Add',
        components: {Dataformx},
        data() {
            return {
                entity: {
                    entity: this.$route.params.entity,
                    entity2: this.$route.params.entity2,
                    id: this.$route.params.id
                }
            }
        }
    }
</script>