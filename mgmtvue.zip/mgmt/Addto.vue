<template>
    <div>
        <br />
        <datatable2 :selection="true" />
    </div>
</template>
<script>
    import datatable2 from '../Datatable2'

    export default {
        name: 'Addto',
        components: {datatable2},
        data() {
            return {}
        }
    }
</script>