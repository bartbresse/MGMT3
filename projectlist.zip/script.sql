-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`reportingtool`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`reportingtool` (
  `idReportingtool` INT NOT NULL AUTO_INCREMENT,
  `Marketsegment` VARCHAR(245) NULL,
  `Customer` VARCHAR(245) NULL,
  `Project` VARCHAR(245) NULL,
  `Facility` VARCHAR(245) NULL,
  `Projectname` VARCHAR(245) NULL,
  `Yearoffirstwindtunnelentry` VARCHAR(245) NULL,
  `Salesitem` VARCHAR(245) NULL,
  `Projectstatus` VARCHAR(45) NULL,
  `Personofcontact` VARCHAR(45) NULL,
  `Customerpersonofcontact` VARCHAR(45) NULL,
  `Projectadministrativestatus` VARCHAR(45) NULL,
  `Comments` TEXT NULL,
  `Lastcustomercontact` VARCHAR(45) NULL,
  `Nextdeadlineofcustomercontact` VARCHAR(45) NULL,
  PRIMARY KEY (`idReportingtool`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`windtunnelincome`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`windtunnelincome` (
  `idWindtunnelincome` INT NOT NULL AUTO_INCREMENT,
  `Windtunnelrevenues` VARCHAR(45) NULL,
  `Directcostforcustomers` VARCHAR(45) NULL,
  `Costofenergyconsumption` VARCHAR(45) NULL,
  `Consumables` VARCHAR(45) NULL,
  `Sundries` VARCHAR(45) NULL,
  `Costofusageoftariffedequipment` VARCHAR(45) NULL,
  `Maneffortcost` VARCHAR(45) NULL,
  `reportingtool_idReportingtool` INT NULL,
  PRIMARY KEY (`idWindtunnelincome`),
  INDEX `fk_windtunnelincome_reportingtool_idx` (`reportingtool_idReportingtool` ASC),
  CONSTRAINT `fk_windtunnelincome_reportingtool`
    FOREIGN KEY (`reportingtool_idReportingtool`)
    REFERENCES `mydb`.`reportingtool` (`idReportingtool`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`invoiceamount`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`invoiceamount` (
  `idInvoiceamount` INT NOT NULL AUTO_INCREMENT,
  `Amount` VARCHAR(245) NULL,
  `Planneddate` DATETIME NULL,
  `Actualdate` DATETIME NULL,
  `reportingtool_idReportingtool` INT NULL,
  PRIMARY KEY (`idInvoiceamount`),
  INDEX `fk_invoiceamount_reportingtool1_idx` (`reportingtool_idReportingtool` ASC),
  CONSTRAINT `fk_invoiceamount_reportingtool1`
    FOREIGN KEY (`reportingtool_idReportingtool`)
    REFERENCES `mydb`.`reportingtool` (`idReportingtool`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`riskfactortype`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`riskfactortype` (
  `idRiskfactortype` INT NOT NULL,
  `Name` VARCHAR(45) NULL,
  `Subtitle` VARCHAR(45) NULL,
  PRIMARY KEY (`idRiskfactortype`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`riskfactor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`riskfactor` (
  `idRiskfactor` INT(11) NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(245) NULL,
  `Subname` VARCHAR(245) NULL,
  `Slider` VARCHAR(245) NULL,
  `Remarks` TEXT NULL,
  `Potentialrisks` TEXT NULL,
  `riskfactortype_idRiskfactortype` INT NULL,
  `Leftslidername` VARCHAR(245) NULL,
  `Rightslidername` VARCHAR(245) NULL,
  PRIMARY KEY (`idRiskfactor`),
  INDEX `fk_riskfactor_riskfactortype1_idx` (`riskfactortype_idRiskfactortype` ASC),
  CONSTRAINT `fk_riskfactor_riskfactortype1`
    FOREIGN KEY (`riskfactortype_idRiskfactortype`)
    REFERENCES `mydb`.`riskfactortype` (`idRiskfactortype`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 26 aug 2019 om 11:35
-- Serverversie: 10.2.22-MariaDB
-- PHP-versie: 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `sonder_cmx15`
--

--
-- Gegevens worden ge�xporteerd voor tabel `reportingtool`
--

INSERT INTO `reportingtool` (`idReportingtool`, `Marketsegment`, `Customer`, `Project`, `Facility`, `Projectname`, `Yearoffirstwindtunnelentry`, `Salesitem`, `Projectstatus`, `Personofcontact`, `Customerpersonofcontact`, `Projectadministrativestatus`, `Comments`, `Lastcustomercontact`, `Nextdeadlineofcustomercontact`) VALUES
(1, 'Military', 'Barnworks', 'Propeller test', 'LLF', 'Test project', '2018', 'Salesitem', 'In tunnel', 'John Doe', 'John Client', 'Admin', 'Comments', NULL, NULL);

--
-- Gegevens worden ge�xporteerd voor tabel `riskfactor`
--

INSERT INTO `riskfactor` (`idRiskfactor`, `Name`, `Subname`, `Slider`, `Remarks`, `Potentialrisks`, `riskfactortype_idRiskfactortype`, `Leftslidername`, `Rightslidername`) VALUES
(1, 'Nature of the requested simulation technique', NULL, NULL, NULL, NULL, 1, 'Standard', 'New, extended or seldom used technique'),
(2, 'Riskfactor test', 'Subtitel', NULL, '[\"option a\",\"option b\",\"option c\"]', 'potential risk description ', NULL, 'left slider name', 'right slider ');

--
-- Gegevens worden ge�xporteerd voor tabel `riskfactortype`
--

INSERT INTO `riskfactortype` (`idRiskfactortype`, `Name`, `Subtitle`) VALUES
(1, 'RFP evaluation (BD, PA, CA)', NULL),
(2, 'Project Risk List', 'Technology (PrM, Proposal team)'),
(3, '', 'Requirements, timeframe and projectmanagement'),
(4, NULL, 'Capacity and facilities (PrM, Proposal team)'),
(7, NULL, 'Subcontractors and Purchases (PrM, Proposal t'),
(8, NULL, 'Finance and administration (PrM, AD)'),
(9, NULL, 'Customer (PrM, BD)'),
(10, NULL, 'QHS, processes and organisation (PRM, CAQ, SO');
COMMIT;