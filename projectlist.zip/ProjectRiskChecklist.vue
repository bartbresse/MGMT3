<template>
    <div id="projectriskchecklist">
        project risk checklist
        <div>
        <table>
            <tr>
                <td>Project:</td>
                <td>{{ response.project.project }}</td>
                <td>Proposal/Project manager</td>
                <td>{{ response.project.projectmanager }}</td>
                <td>Assessment date:</td>
                <td>{{ response.project.date }}</td>
            </tr>
            <tr>
                <td>Project number:</td>
                <td>{{ response.project.number }}</td>
                <td>Facility:</td>
                <td>{{ response.project.facility }}</td>
                <td></td>
            </tr>
        </table>
        </div>
        <div>

            <tbody v-for="rows in response.factors">
                <tr>
                    <td colspan="5"><b>{{ rows.model.Name }}</b></td>
                    <td>Adjust slider</td>
                    <td></td>
                    <td>Action/Remark</td>
                    <td>Potential Risks</td>
                </tr>
                <tr>
                    <td colspan="5">{{ rows.model.Subtitle }}</td>
                </tr>
                <tr v-for="row in rows.factors">
                    <td>{{ row.Name }}<br /><b>{{ row.Subname }}</b></td>
                    <td>{{ row.Leftslidername }}</td>
                    <td>SLIDER</td>
                    <td>{{ row.Rightslidername }}</td>
                    <td>{{ row.Remarks }}</td>
                    <td>{{ row.Potentialrisks }}</td>
                </tr>
            </tbody>
        </div>
    </div>
</template>
<script>

    export default {
        name: 'ProjectRiskChecklist',
        data() {
            return {
                response:[]
            }
        },
        mounted() {
            this.getForm();
        },
        methods: {
            getForm(){
                var self = this
                this.$store.dispatch('post', {url: 'riskassesment/get', data: {}}).then(function (response) {
                    self.response = response.data
                })
            }
        }
    }
</script>
<style lang="scss">
    #projectriskchecklist{
        table tr td{
            border: 1px solid black; 
            border-spacing: 0px;
        }
    }
</style>